(function(){const a=document.createElement("link").relList;if(a&&a.supports&&a.supports("modulepreload"))return;for(const t of document.querySelectorAll('link[rel="modulepreload"]'))i(t);new MutationObserver(t=>{for(const n of t)if(n.type==="childList")for(const r of n.addedNodes)r.tagName==="LINK"&&r.rel==="modulepreload"&&i(r)}).observe(document,{childList:!0,subtree:!0});function e(t){const n={};return t.integrity&&(n.integrity=t.integrity),t.referrerPolicy&&(n.referrerPolicy=t.referrerPolicy),t.crossOrigin==="use-credentials"?n.credentials="include":t.crossOrigin==="anonymous"?n.credentials="omit":n.credentials="same-origin",n}function i(t){if(t.ep)return;t.ep=!0;const n=e(t);fetch(t.href,n)}})();const Be=[{id:"delhi",name:"New Delhi",state:"Delhi",country:"India",lat:28.6139,lon:77.209,tz:"Asia/Kolkata",tz_offset:5.5,elevation:216},{id:"mumbai",name:"Mumbai",state:"Maharashtra",country:"India",lat:19.076,lon:72.8777,tz:"Asia/Kolkata",tz_offset:5.5,elevation:14},{id:"chennai",name:"Chennai",state:"Tamil Nadu",country:"India",lat:13.0827,lon:80.2707,tz:"Asia/Kolkata",tz_offset:5.5,elevation:6},{id:"bengaluru",name:"Bengaluru",state:"Karnataka",country:"India",lat:12.9716,lon:77.5946,tz:"Asia/Kolkata",tz_offset:5.5,elevation:920},{id:"hyderabad",name:"Hyderabad",state:"Telangana",country:"India",lat:17.385,lon:78.4867,tz:"Asia/Kolkata",tz_offset:5.5,elevation:542},{id:"kolkata",name:"Kolkata",state:"West Bengal",country:"India",lat:22.5726,lon:88.3639,tz:"Asia/Kolkata",tz_offset:5.5,elevation:9},{id:"ahmedabad",name:"Ahmedabad",state:"Gujarat",country:"India",lat:23.0225,lon:72.5714,tz:"Asia/Kolkata",tz_offset:5.5,elevation:53},{id:"varanasi",name:"Varanasi (Kashi)",state:"Uttar Pradesh",country:"India",lat:25.3176,lon:82.9739,tz:"Asia/Kolkata",tz_offset:5.5,elevation:81},{id:"tirupati",name:"Tirupati",state:"Andhra Pradesh",country:"India",lat:13.6288,lon:79.4192,tz:"Asia/Kolkata",tz_offset:5.5,elevation:182},{id:"puri",name:"Puri (Jagannath)",state:"Odisha",country:"India",lat:19.8135,lon:85.8312,tz:"Asia/Kolkata",tz_offset:5.5,elevation:10},{id:"rameswaram",name:"Rameswaram",state:"Tamil Nadu",country:"India",lat:9.2876,lon:79.3129,tz:"Asia/Kolkata",tz_offset:5.5,elevation:10},{id:"haridwar",name:"Haridwar",state:"Uttarakhand",country:"India",lat:29.9457,lon:78.1642,tz:"Asia/Kolkata",tz_offset:5.5,elevation:314},{id:"ujjain",name:"Ujjain (Mahakaleshwar)",state:"Madhya Pradesh",country:"India",lat:23.1765,lon:75.7885,tz:"Asia/Kolkata",tz_offset:5.5,elevation:491},{id:"madurai",name:"Madurai (Meenakshi)",state:"Tamil Nadu",country:"India",lat:9.9252,lon:78.1198,tz:"Asia/Kolkata",tz_offset:5.5,elevation:101},{id:"dwarka",name:"Dwarka",state:"Gujarat",country:"India",lat:22.2442,lon:68.9685,tz:"Asia/Kolkata",tz_offset:5.5,elevation:5},{id:"somnath",name:"Somnath",state:"Gujarat",country:"India",lat:20.906,lon:70.401,tz:"Asia/Kolkata",tz_offset:5.5,elevation:12},{id:"ayodhya",name:"Ayodhya",state:"Uttar Pradesh",country:"India",lat:26.7922,lon:82.1998,tz:"Asia/Kolkata",tz_offset:5.5,elevation:102},{id:"mathura",name:"Mathura / Vrindavan",state:"Uttar Pradesh",country:"India",lat:27.4924,lon:77.6737,tz:"Asia/Kolkata",tz_offset:5.5,elevation:174},{id:"bhubaneswar",name:"Bhubaneswar",state:"Odisha",country:"India",lat:20.2961,lon:85.8245,tz:"Asia/Kolkata",tz_offset:5.5,elevation:45},{id:"guruvayur",name:"Guruvayur",state:"Kerala",country:"India",lat:10.5946,lon:76.0416,tz:"Asia/Kolkata",tz_offset:5.5,elevation:12},{id:"shirdi",name:"Shirdi",state:"Maharashtra",country:"India",lat:19.7667,lon:74.4764,tz:"Asia/Kolkata",tz_offset:5.5,elevation:504},{id:"pune",name:"Pune",state:"Maharashtra",country:"India",lat:18.5204,lon:73.8567,tz:"Asia/Kolkata",tz_offset:5.5,elevation:560},{id:"jaipur",name:"Jaipur",state:"Rajasthan",country:"India",lat:26.9124,lon:75.7873,tz:"Asia/Kolkata",tz_offset:5.5,elevation:431},{id:"new-york",name:"New York",state:"NY",country:"USA",lat:40.7128,lon:-74.006,tz:"America/New_York",tz_offset:-5,elevation:10},{id:"san-jose",name:"San Jose (Silicon Valley)",state:"CA",country:"USA",lat:37.3382,lon:-121.8863,tz:"America/Los_Angeles",tz_offset:-8,elevation:26},{id:"chicago",name:"Chicago",state:"IL",country:"USA",lat:41.8781,lon:-87.6298,tz:"America/Chicago",tz_offset:-6,elevation:181},{id:"dallas",name:"Dallas",state:"TX",country:"USA",lat:32.7767,lon:-96.797,tz:"America/Chicago",tz_offset:-6,elevation:131},{id:"london",name:"London",state:"England",country:"UK",lat:51.5074,lon:-.1278,tz:"Europe/London",tz_offset:0,elevation:11},{id:"leicester",name:"Leicester",state:"England",country:"UK",lat:52.6369,lon:-1.1398,tz:"Europe/London",tz_offset:0,elevation:67},{id:"toronto",name:"Toronto",state:"ON",country:"Canada",lat:43.6532,lon:-79.3832,tz:"America/Toronto",tz_offset:-5,elevation:76},{id:"vancouver",name:"Vancouver",state:"BC",country:"Canada",lat:49.2827,lon:-123.1207,tz:"America/Vancouver",tz_offset:-8,elevation:2},{id:"sydney",name:"Sydney",state:"NSW",country:"Australia",lat:-33.8688,lon:151.2093,tz:"Australia/Sydney",tz_offset:10,elevation:19},{id:"melbourne",name:"Melbourne",state:"VIC",country:"Australia",lat:-37.8136,lon:144.9631,tz:"Australia/Melbourne",tz_offset:10,elevation:31},{id:"singapore",name:"Singapore",state:"Singapore",country:"Singapore",lat:1.3521,lon:103.8198,tz:"Asia/Singapore",tz_offset:8,elevation:15},{id:"dubai",name:"Dubai",state:"Dubai",country:"UAE",lat:25.2048,lon:55.2708,tz:"Asia/Dubai",tz_offset:4,elevation:5},{id:"kuala-lumpur",name:"Kuala Lumpur",state:"Federal Territory",country:"Malaysia",lat:3.139,lon:101.6869,tz:"Asia/Kuala_Lumpur",tz_offset:8,elevation:21},{id:"durban",name:"Durban",state:"KwaZulu-Natal",country:"South Africa",lat:-29.8587,lon:31.0218,tz:"Africa/Johannesburg",tz_offset:2,elevation:14},{id:"nairobi",name:"Nairobi",state:"Nairobi",country:"Kenya",lat:-1.2921,lon:36.8219,tz:"Africa/Nairobi",tz_offset:3,elevation:1795},{id:"mauritius",name:"Port Louis",state:"Port Louis",country:"Mauritius",lat:-20.1609,lon:57.5012,tz:"Indian/Mauritius",tz_offset:4,elevation:13},{id:"tokyo",name:"Tokyo",state:"Tokyo",country:"Japan",lat:35.6762,lon:139.6503,tz:"Asia/Tokyo",tz_offset:9,elevation:40}],ra=[{id:1,name:"Prathama",paksha:"Shukla",deity:"Agni"},{id:2,name:"Dwitiya",paksha:"Shukla",deity:"Brahma"},{id:3,name:"Tritiya",paksha:"Shukla",deity:"Gauri"},{id:4,name:"Chaturthi",paksha:"Shukla",deity:"Ganesha"},{id:5,name:"Panchami",paksha:"Shukla",deity:"Nagas"},{id:6,name:"Shashthi",paksha:"Shukla",deity:"Kartikeya"},{id:7,name:"Saptami",paksha:"Shukla",deity:"Surya"},{id:8,name:"Ashtami",paksha:"Shukla",deity:"Shiva / Durga"},{id:9,name:"Navami",paksha:"Shukla",deity:"Durga / Rama"},{id:10,name:"Dashami",paksha:"Shukla",deity:"Yama"},{id:11,name:"Ekadashi",paksha:"Shukla",deity:"Vishnu"},{id:12,name:"Dwadashi",paksha:"Shukla",deity:"Vishnu"},{id:13,name:"Trayodashi",paksha:"Shukla",deity:"Kamadeva"},{id:14,name:"Chaturdashi",paksha:"Shukla",deity:"Shiva"},{id:15,name:"Purnima",paksha:"Shukla",deity:"Chandra"},{id:16,name:"Prathama",paksha:"Krishna",deity:"Agni"},{id:17,name:"Dwitiya",paksha:"Krishna",deity:"Brahma"},{id:18,name:"Tritiya",paksha:"Krishna",deity:"Gauri"},{id:19,name:"Chaturthi",paksha:"Krishna",deity:"Ganesha"},{id:20,name:"Panchami",paksha:"Krishna",deity:"Nagas"},{id:21,name:"Shashthi",paksha:"Krishna",deity:"Kartikeya"},{id:22,name:"Saptami",paksha:"Krishna",deity:"Surya"},{id:23,name:"Ashtami",paksha:"Krishna",deity:"Shiva / Durga"},{id:24,name:"Navami",paksha:"Krishna",deity:"Durga"},{id:25,name:"Dashami",paksha:"Krishna",deity:"Yama"},{id:26,name:"Ekadashi",paksha:"Krishna",deity:"Vishnu"},{id:27,name:"Dwadashi",paksha:"Krishna",deity:"Vishnu"},{id:28,name:"Trayodashi",paksha:"Krishna",deity:"Kamadeva"},{id:29,name:"Chaturdashi",paksha:"Krishna",deity:"Shiva"},{id:30,name:"Amavasya",paksha:"Krishna",deity:"Pitrus"}],_=[{id:1,name:"Ashwini",deity:"Ashwini Kumaras",lord:"Ketu"},{id:2,name:"Bharani",deity:"Yama",lord:"Venus"},{id:3,name:"Krittika",deity:"Agni",lord:"Sun"},{id:4,name:"Rohini",deity:"Brahma",lord:"Moon"},{id:5,name:"Mrigashira",deity:"Soma",lord:"Mars"},{id:6,name:"Ardra",deity:"Rudra",lord:"Rahu"},{id:7,name:"Punarvasu",deity:"Aditi",lord:"Jupiter"},{id:8,name:"Pushya",deity:"Brihaspati",lord:"Saturn"},{id:9,name:"Ashlesha",deity:"Sarpa",lord:"Mercury"},{id:10,name:"Magha",deity:"Pitrus",lord:"Ketu"},{id:11,name:"Purva Phalguni",deity:"Bhaga",lord:"Venus"},{id:12,name:"Uttara Phalguni",deity:"Aryaman",lord:"Sun"},{id:13,name:"Hasta",deity:"Savitr",lord:"Moon"},{id:14,name:"Chitra",deity:"Vishwakarma",lord:"Mars"},{id:15,name:"Swati",deity:"Vayu",lord:"Rahu"},{id:16,name:"Vishakha",deity:"Indragni",lord:"Jupiter"},{id:17,name:"Anuradha",deity:"Mitra",lord:"Saturn"},{id:18,name:"Jyeshtha",deity:"Indra",lord:"Mercury"},{id:19,name:"Moola",deity:"Nirriti",lord:"Ketu"},{id:20,name:"Purva Ashadha",deity:"Apas",lord:"Venus"},{id:21,name:"Uttara Ashadha",deity:"Vishwedevas",lord:"Sun"},{id:22,name:"Shravana",deity:"Vishnu",lord:"Moon"},{id:23,name:"Dhanishtha",deity:"Vasus",lord:"Mars"},{id:24,name:"Shatabhisha",deity:"Varuna",lord:"Rahu"},{id:25,name:"Purva Bhadrapada",deity:"Aja Ekapada",lord:"Jupiter"},{id:26,name:"Uttara Bhadrapada",deity:"Ahirbudhnya",lord:"Saturn"},{id:27,name:"Revati",deity:"Pushan",lord:"Mercury"}],Ke=["Vishkambha","Priti","Ayushman","Saubhagya","Shobhana","Atiganda","Sukarma","Dhriti","Shula","Ganda","Vriddhi","Dhruva","Vyaghata","Harshana","Vajra","Siddhi","Vyatipata","Variyan","Parigha","Shiva","Siddha","Sadhya","Shubha","Shukla","Brahma","Indra","Vaidhriti"],W=[{id:1,name:"Mesha",english:"Aries",lord:"Mars"},{id:2,name:"Vrishabha",english:"Taurus",lord:"Venus"},{id:3,name:"Mithuna",english:"Gemini",lord:"Mercury"},{id:4,name:"Karkataka",english:"Cancer",lord:"Moon"},{id:5,name:"Simha",english:"Leo",lord:"Sun"},{id:6,name:"Kanya",english:"Virgo",lord:"Mercury"},{id:7,name:"Tula",english:"Libra",lord:"Venus"},{id:8,name:"Vrishchika",english:"Scorpio",lord:"Mars"},{id:9,name:"Dhanu",english:"Sagittarius",lord:"Jupiter"},{id:10,name:"Makara",english:"Capricorn",lord:"Saturn"},{id:11,name:"Kumbha",english:"Aquarius",lord:"Saturn"},{id:12,name:"Meena",english:"Pisces",lord:"Jupiter"}],ze=[{id:0,name:"Ravivara",english:"Sunday",lord:"Surya"},{id:1,name:"Somavara",english:"Monday",lord:"Chandra"},{id:2,name:"Mangalavara",english:"Tuesday",lord:"Mangala"},{id:3,name:"Budhavara",english:"Wednesday",lord:"Budha"},{id:4,name:"Guruvara",english:"Thursday",lord:"Brihaspati"},{id:5,name:"Shukravara",english:"Friday",lord:"Shukra"},{id:6,name:"Shanivara",english:"Saturday",lord:"Shani"}],G=Math.PI/180,J=180/Math.PI;function g(o){let a=o%360;return a<0&&(a+=360),a}function w(o){return Math.sin(o*G)}function V(o){return Math.cos(o*G)}function Pa(o){return Math.tan(o*G)}function Ia(o,a,e,i=12){a<=2&&(o-=1,a+=12);const t=Math.floor(o/100),n=2-t+Math.floor(t/4);return Math.floor(365.25*(o+4716))+Math.floor(30.6001*(a+1))+e+i/24+n-1524.5}function Ve(o){const a=(o-2451545)/36525;return 23.856+1.396042*a+308e-6*a*a}function Ea(o){const a=(o-2451545)/36525,e=g(280.46646+36000.76983*a+3032e-7*a*a),i=g(357.52911+35999.05029*a-1537e-7*a*a),t=(1.914602-.004817*a-14e-6*a*a)*w(i)+(.019993-101e-6*a)*w(2*i)+289e-6*w(3*i),n=g(e+t),r=125.04-1934.136*a,l=g(n-.00569-.00478*w(r)),h=23.439291-.0130042*a+.00256*V(r),u=g(Math.atan2(V(h)*w(l),V(l))*J),m=Math.asin(w(h)*w(l))*J;return{lon:l,ra:u,dec:m}}function Ne(o){const a=(o-2451545)/36525,e=g(218.3164477+481267.88123421*a),i=g(297.8501921+445267.1114034*a),t=g(357.5291092+35999.0502909*a),n=g(134.9633964+477198.8675055*a),r=g(93.272095+483202.0175233*a);let l=6.288774*w(n)+1.274027*w(2*i-n)+.658314*w(2*i)+.213618*w(2*n)-.185116*w(t)-.114332*w(2*r);return{lon:g(e+l)}}function Ge(o,a,e,i,t,n){const r=Ia(o,a,e,12-n),l=Ea(r),h=(V(90.8333)-w(i)*w(l.dec))/(V(i)*V(l.dec));let u=!0,m=0;h>1||h<-1?u=!1:m=Math.acos(h)*J;const x=(r-2451545)/36525,y=g(357.52911+35999.05029*x),S=g(280.46646+36000.76983*x),A=.016708634-42037e-9*x,P=Pa(23.439291/2)*Pa(23.439291/2),I=(P*w(2*S)-2*A*w(y)+4*A*P*w(y)*V(2*S)-.5*P*P*w(4*S)-1.25*A*A*w(2*y))*4,L=(720-4*t-I)/60,R=L-m*4/60,E=L+m*4/60,B=(R+n+24)%24,j=(E+n+24)%24,d=(L+n+24)%24;return{sunrise:B,sunset:j,solarNoon:d,hasSun:u}}function c(o){let a=Math.round(o*60);a=(a+1440)%1440;const e=Math.floor(a/60),i=a%60,t=e>=12?"PM":"AM",n=e%12===0?12:e%12,r=i<10?`0${i}`:i;return`${n}:${r} ${t}`}function He(o,a){const e=o.getFullYear(),i=o.getMonth()+1,t=o.getDate(),{lat:n,lon:r,tz_offset:l}=a,s=Ge(e,i,t,n,r,l),h=Ia(e,i,t,s.sunrise-l),u=Ve(h),m=Ea(h),x=Ne(h),y=g(m.lon-u),S=g(x.lon-u),A=g(x.lon-m.lon),P=Math.floor(A/12),I=A%12/12*100,L=ra[P%30],R=Math.floor(S/(360/27)),E=S%(360/27)/(360/27)*100,B=Math.floor(S%(360/27)/(360/108))+1,j=_[R%27],d=g(y+S),k=Math.floor(d/(360/27)),M=Ke[k%27],b=Math.floor(A/6);let $="";if(b===0)$="Kintughna";else if(b>=57){const v=b-57;$=["Shakuni","Chatushpada","Naga"][v]||"Kintughna"}else $=["Bava","Balava","Kaulava","Taitila","Gara","Vanija","Vishti (Bhadra)"][(b-1)%7];const D=o.getDay(),Y=ze[D],H=(s.sunset-s.sunrise+24)%24,T=H/8,N=H/15,Ba=[7,1,6,4,5,3,2],da=s.sunrise+Ba[D]*T,Ka=da+T,za=[4,3,2,1,0,6,5],la=s.sunrise+za[D]*T,Va=la+T,Na=[6,5,4,3,2,1,0],ha=s.sunrise+Na[D]*T,Ga=ha+T,ca=s.sunrise+7*N,Ha=ca+N,Oa=(s.sunrise-96/60+24)%24,Fa=(s.sunrise-48/60+24)%24,Ua=R*3.65%16,ua=(s.sunrise+2+Ua)%24,_a=(ua+1.6)%24,ma=s.sunrise+10*N,Wa=ma+N,Ja=(s.sunset-.4+24)%24,qa=(s.sunset+.4)%24,Ya=[[13],[7,11],[3,10],[4],[5,6],[3,8],[0,1]][D].map(v=>{const f=s.sunrise+v*N;return`${c(f)} – ${c(f+N)}`}).join(", "),Qa=(R*4.1+5.5)%16,ga=(s.sunrise+Qa)%24,Za=(ga+1.6)%24,pa=[{direction:"West (Pashchim)",remedy:"Consume betel leaf or cow ghee before travel"},{direction:"East (Purva)",remedy:"View face in mirror or consume kheer/milk before travel"},{direction:"North (Uttar)",remedy:"Consume organic jaggery (gud) before travel"},{direction:"North (Uttar)",remedy:"Consume green coriander or sesame before travel"},{direction:"South (Dakshin)",remedy:"Consume yellow mustard or curd before travel"},{direction:"West (Pashchim)",remedy:"Consume sweet curds or barley before travel"},{direction:"East (Purva)",remedy:"Consume fresh ginger or urad dal before travel"}][D],Xa=e+57,ae=e-78,ee=e+3101,te=y>=270||y<90?"Uttarayana (Northward Sun)":"Dakshinayana (Southward Sun)",ie=["Shishira","Vasanta","Vasanta","Grishma","Grishma","Varsha","Varsha","Sharad","Sharad","Hemanta","Hemanta","Shishira"][Math.floor(y/30)%12],ya=A/360*24,ne=c((s.sunrise+ya)%24),re=c((s.sunset+ya)%24),se=(100-I)/100*24,oe=c((s.sunrise+se)%24),fa=(P+1)%30,de=`${ra[fa].paksha} ${ra[fa].name}`,le=(100-E)/100*24,he=c((s.sunrise+le)%24),ce=(R+1)%27,ue=_[ce].name,Q=(h-2451545)/36525,me=g(280.46061837+360.98564736629*(h-2451545)+387933e-9*Q*Q),ge=g(me+a.lon),va=(23.4392911-.0130042*Q)*G,pe=a.lat*G,ka=ge*G,ye=-Math.cos(ka),fe=Math.sin(ka)*Math.cos(va)+Math.tan(pe)*Math.sin(va),ve=g(Math.atan2(ye,fe)*J),F=g(ve-u),ba=Math.floor(F/30)+1,U=F%30,Z=W[(ba-1)%12],ke=Math.floor(F/(360/27))%27,be=Math.floor(F%(360/27)/(360/108))+1,we={rashiIndex:ba,rashi:Z.name,rashiEnglish:Z.english,deg:Math.floor(U),min:Math.floor(U%1*60),formatted:`${Math.floor(U)}° ${Math.floor(U%1*60)}' in ${Z.name}`,nakshatra:_[ke].name,pada:be},Se=Math.floor(y/30),xe=Math.floor(S/30),wa=W[Se%12],Sa=W[xe%12];function K(v,f,Re,$a=!1){const O=g(Re),Aa=Math.floor(O/30)%12,Ta=W[Aa],na=O%30,Ca=Math.floor(na),La=Math.floor(na%1*60),Da=Math.round(na%1*60%1*60),je=Math.floor(O/(360/27))%27,Ie=_[je],Ee=Math.floor(O%(360/27)/(360/108))+1;return{name:v,sanskrit:f,rashiIndex:Aa+1,siderealLon:O,deg:Ca,min:La,sec:Da,degInRashi:`${Ca}° ${La}' ${Da}"`,rashi:Ta.name,rashiEnglish:Ta.english,nakshatra:Ie.name,pada:Ee,isRetrograde:$a,status:$a?"Retrograde (Vakra)":"Direct (Marga)"}}const Me=[K("Surya (Sun)","सूर्यः",y,!1),K("Chandra (Moon)","चन्द्रः",S,!1),K("Mangala (Mars)","मङ्गलः",g(y*.53+45),!1),K("Budha (Mercury)","बुधः",g(y+12),!1),K("Brihaspati (Jupiter)","बृहस्पतिः",g(y*.08+82),!1),K("Shukra (Venus)","शुक्रः",g(y-24),!1),K("Shani (Saturn)","शनिः",g(y*.03+338),!1),K("Rahu (North Node)","राहुः",g(360-(m.lon*.05+115)),!0),K("Ketu (South Node)","केतुः",g(360-(m.lon*.05+115)+180),!0)],$e=[["Uthi","Amrutha","Rogam","Labham","Visham","Sugam","Choram","Bandham"],["Amrutha","Rogam","Labham","Visham","Sugam","Choram","Bandham","Uthi"],["Rogam","Labham","Visham","Sugam","Choram","Bandham","Uthi","Amrutha"],["Labham","Visham","Sugam","Choram","Bandham","Uthi","Amrutha","Rogam"],["Sugam","Choram","Bandham","Uthi","Amrutha","Rogam","Labham","Visham"],["Bandham","Uthi","Amrutha","Rogam","Labham","Visham","Sugam","Choram"],["Choram","Bandham","Uthi","Amrutha","Rogam","Labham","Visham","Sugam"]],Ae=[["Choram","Bandham","Uthi","Amrutha","Rogam","Labham","Visham","Sugam"],["Sugam","Choram","Bandham","Uthi","Amrutha","Rogam","Labham","Visham"],["Labham","Visham","Sugam","Choram","Bandham","Uthi","Amrutha","Rogam"],["Rogam","Labham","Visham","Sugam","Choram","Bandham","Uthi","Amrutha"],["Amrutha","Rogam","Labham","Visham","Sugam","Choram","Bandham","Uthi"],["Uthi","Amrutha","Rogam","Labham","Visham","Sugam","Choram","Bandham"],["Bandham","Uthi","Amrutha","Rogam","Labham","Visham","Sugam","Choram"]],z=(24-H)/8,xa=$e[D].map((v,f)=>({name:v,nature:["Amrutha","Labham","Sugam","Uthi"].includes(v)?"Good":"Inauspicious",isGood:["Amrutha","Labham","Sugam","Uthi"].includes(v),slot:`${c(s.sunrise+f*T)} – ${c(s.sunrise+(f+1)*T)}`,start:c(s.sunrise+f*T),end:c(s.sunrise+(f+1)*T)})),Te=Ae[D].map((v,f)=>({name:v,nature:["Amrutha","Labham","Sugam","Uthi"].includes(v)?"Good":"Inauspicious",isGood:["Amrutha","Labham","Sugam","Uthi"].includes(v),slot:`${c(s.sunset+f*z)} – ${c(s.sunset+(f+1)*z)}`,start:c(s.sunset+f*z),end:c(s.sunset+(f+1)*z)})),X=[...xa];X.day=xa,X.night=Te;const Ce=[["Udveg","Char","Labh","Amrit","Kaal","Shubh","Rog","Udveg"],["Amrit","Kaal","Shubh","Rog","Udveg","Char","Labh","Amrit"],["Rog","Udveg","Char","Labh","Amrit","Kaal","Shubh","Rog"],["Labh","Amrit","Kaal","Shubh","Rog","Udveg","Char","Labh"],["Shubh","Rog","Udveg","Char","Labh","Amrit","Kaal","Shubh"],["Char","Labh","Amrit","Kaal","Shubh","Rog","Udveg","Char"],["Kaal","Shubh","Rog","Udveg","Char","Labh","Amrit","Kaal"]],Le=[["Shubh","Amrit","Char","Rog","Kaal","Labh","Udveg","Shubh"],["Char","Rog","Kaal","Labh","Udveg","Shubh","Amrit","Char"],["Kaal","Labh","Udveg","Shubh","Amrit","Char","Rog","Kaal"],["Udveg","Shubh","Amrit","Char","Rog","Kaal","Labh","Udveg"],["Amrit","Char","Rog","Kaal","Labh","Udveg","Shubh","Amrit"],["Rog","Kaal","Labh","Udveg","Shubh","Amrit","Char","Rog"],["Labh","Udveg","Shubh","Amrit","Char","Rog","Kaal","Labh"]],Ma=Ce[D].map((v,f)=>({name:v,nature:["Shubh","Labh","Amrit","Char"].includes(v)?"Auspicious":"Inauspicious",isGood:["Shubh","Labh","Amrit","Char"].includes(v),slot:`${c(s.sunrise+f*T)} – ${c(s.sunrise+(f+1)*T)}`,start:c(s.sunrise+f*T),end:c(s.sunrise+(f+1)*T)})),De=Le[D].map((v,f)=>({name:v,nature:["Shubh","Labh","Amrit","Char"].includes(v)?"Auspicious":"Inauspicious",isGood:["Shubh","Labh","Amrit","Char"].includes(v),slot:`${c(s.sunset+f*z)} – ${c(s.sunset+(f+1)*z)}`,start:c(s.sunset+f*z),end:c(s.sunset+(f+1)*z)})),aa=[...Ma];aa.day=Ma,aa.night=De;const ea=Math.floor(u),ta=Math.floor(u%1*60),ia=Math.round(u%1*60%1*60),Pe={value:parseFloat(u.toFixed(4)),degrees:ea,minutes:ta,seconds:ia,formatted:`${ea}° ${ta}' ${ia}"`,toFixed:v=>u.toFixed(v),toString:()=>`${ea}° ${ta}' ${ia}"`,valueOf:()=>u};return{date:`${e}-${String(i).padStart(2,"0")}-${String(t).padStart(2,"0")}`,city:a.name,country:a.country,coordinates:`${a.lat.toFixed(4)}° N, ${a.lon.toFixed(4)}° E`,ayanamsa:Pe,sunrise:c(s.sunrise),sunset:c(s.sunset),solarNoon:c(s.solarNoon),dayDuration:`${Math.floor(H)}h ${Math.round(H%1*60)}m`,tithi:{name:`${L.paksha} ${L.name}`,paksha:L.paksha,deity:L.deity,progress:Math.round(I)},nakshatra:{name:j.name,pada:B,deity:j.deity,lord:j.lord,progress:Math.round(E)},yoga:M,karana:$,vaar:{sanskrit:Y.name,english:Y.english,lord:Y.lord},sunRashi:`${wa.name} (${wa.english})`,moonRashi:`${Sa.name} (${Sa.english})`,moonrise:ne,moonset:re,lagna:we,calendar:{vikramSamvat:`${Xa} (Pingala / Krodhi)`,shakaSamvat:`${ae} (Krodhi)`,kaliSamvat:`${ee}`,ayana:te,ritu:ie,dishaShool:pa.direction,dishaShoolRemedy:pa.remedy},muhurtas:{rahuKalam:`${c(da)} – ${c(Ka)}`,yamagandam:`${c(la)} – ${c(Va)}`,gulikaKalam:`${c(ha)} – ${c(Ga)}`,abhijitMuhurta:D===3?"None (Wednesdays prohibited)":`${c(ca)} – ${c(Ha)}`,brahmaMuhurta:`${c(Oa)} – ${c(Fa)}`,amritKaal:`${c(ua)} – ${c(_a)}`,vijayaMuhurta:`${c(ma)} – ${c(Wa)}`,godhuliMuhurta:`${c(Ja)} – ${c(qa)}`,durMuhurtam:Ya,varjyam:`${c(ga)} – ${c(Za)}`},tithiEndTime:`${oe} (followed by ${de})`,nakshatraEndTime:`${he} (followed by ${ue})`,gowriPanchangam:X,choghadiya:aa,planets:Me}}const Oe=[{code:"sa",name:"Sanskrit",native:"संस्कृतम्",script:"Devanagari"},{code:"hi",name:"Hindi",native:"हिन्दी",script:"Devanagari"},{code:"mr",name:"Marathi",native:"मराठी",script:"Devanagari"},{code:"ta",name:"Tamil",native:"தமிழ்",script:"Tamil"},{code:"te",name:"Telugu",native:"తెలుగు",script:"Telugu"},{code:"kn",name:"Kannada",native:"ಕನ್ನಡ",script:"Kannada"},{code:"ml",name:"Malayalam",native:"മലയാളം",script:"Malayalam"},{code:"gu",name:"Gujarati",native:"ગુજરાતી",script:"Gujarati"},{code:"bn",name:"Bengali",native:"বাংলা",script:"Bengali"},{code:"or",name:"Odia",native:"ଓଡ଼ିଆ",script:"Odia"},{code:"en",name:"English (IAST)",native:"English (IAST)",script:"Latin"}];function q(o){return o?o.replace(/[\u0951\u0952\u0953\u0954\u1CD0-\u1CF9\uA8E0-\uA8F7]/g,""):""}const Fe={sa:"ॐ",hi:"ॐ",mr:"ॐ",ta:"ஓம்",te:"ఓం",kn:"ಓಂ",ml:"ഓം",gu:"ૐ",bn:"ওঁ",or:"ଓଁ",en:"Oṃ"},sa={अ:"a",आ:"ā",इ:"i",ई:"ī",उ:"u",ऊ:"ū",ऋ:"ṛ",ॠ:"ṝ",ऌ:"ḷ",ॡ:"ḹ",ए:"e",ऐ:"ai",ओ:"o",औ:"au","ा":"ā","ि":"i","ी":"ī","ु":"u","ू":"ū","ृ":"ṛ","ॄ":"ṝ","ॢ":"ḷ","ॣ":"ḹ","े":"e","ै":"ai","ो":"o","ौ":"au","ं":"ṃ","ः":"ḥ","्":"",ऽ:"'",ॐ:"Oṃ",क:"ka",ख:"kha",ग:"ga",घ:"gha",ङ:"ṅa",च:"ca",छ:"cha",ज:"ja",झ:"jha",ञ:"ña",ट:"ṭa",ठ:"ṭha",ड:"ḍa",ढ:"ḍha",ण:"ṇa",त:"ta",थ:"tha",द:"da",ध:"dha",न:"na",प:"pa",फ:"pha",ब:"ba",भ:"bha",म:"ma",य:"ya",र:"ra",ल:"la",व:"va",श:"śa",ष:"ṣa",स:"sa",ह:"ha",ळ:"ḷa",क्ष:"kṣa",ज्ञ:"jña","०":"0","१":"1","२":"2","३":"3","४":"4","५":"5","६":"6","७":"7","८":"8","९":"9","।":"|","॥":"||"};function Ue(o,a,e){let i="";const t=q(o);for(let n=0;n<t.length;n++){const r=t[n],l=t.charCodeAt(n);if(r==="ॐ"){i+=Fe[e]||"ॐ";continue}if(l===2404||l===2405){i+=r;continue}if(l>=2305&&l<=2416){if(e==="ta"){const h={ख:"க",ग:"க",घ:"க",ङ:"ங",च:"ச",छ:"ச",ज:"ஜ",झ:"ச",ञ:"ஞ",ठ:"ட",ड:"ட",ढ:"ட",थ:"த",द:"த",ध:"த",फ:"ப",ब:"ப",भ:"ப",श:"ஶ",ष:"ஷ",स:"ஸ",ह:"ஹ",क्ष:"க்ஷ",ऋ:"ரி",ॠ:"ரீ","ृ":"்ரி","ॄ":"்ரீ","ं":"ம்","ः":"ஃ"};if(h[r]){i+=h[r];continue}}if(e==="bn"){if(r==="व"){i+="ব";continue}if(r==="र"){i+="র";continue}}if(e==="or"&&r==="व"){i+="ୱ";continue}if(e==="ml"&&r==="र"&&t[n+1]==="्"){i+="ർ",n++;continue}const s=l+a;i+=String.fromCharCode(s)}else i+=r}return i}function _e(o){const a=q(o);let e="",i=0;for(;i<a.length;){const t=a[i],n=a[i+1];if(t==="्"){i++;continue}if(sa[t]){let r=sa[t];if(r.endsWith("a")){if(n&&["ा","ि","ी","ु","ू","ृ","ॄ","े","ै","ो","ौ"].includes(n)){r=r.slice(0,-1)+sa[n],i+=2,e+=r;continue}else if(n==="्"){r=r.slice(0,-1),i+=2,e+=r;continue}}e+=r,i++}else e+=t,i++}return e}function p(o,a,e=!0){if(!o)return"";if(a==="sa"||a==="hi"||a==="mr")return e?q(o):o;if(a==="en")return _e(o);const t={bn:128,gu:384,or:512,ta:640,te:768,kn:896,ml:1024}[a];return t!==void 0?Ue(o,t,a):e?q(o):o}const We=[{id:"all",name:"All Shrines",sanskrit:"सर्वदेवाः",icon:"🕉️"},{id:"ganesha",name:"Sri Ganesha",sanskrit:"श्रीगणेशः",icon:"🐘"},{id:"shiva",name:"Lord Shiva",sanskrit:"श्रीमहादेवः",icon:"🔱"},{id:"vishnu",name:"Lord Vishnu",sanskrit:"श्रीमहाविष्णुः",icon:"🪷"},{id:"krishna",name:"Sri Krishna",sanskrit:"श्रीकृष्णः",icon:"🦚"},{id:"rama",name:"Sri Rama",sanskrit:"श्रीरामचन्द्रः",icon:"🏹"},{id:"hanuman",name:"Sri Hanuman",sanskrit:"श्रीहनुमान्",icon:"🚩"},{id:"lakshmi",name:"Maa Lakshmi",sanskrit:"महालक्ष्मीः",icon:"🪙"},{id:"durga",name:"Maa Durga",sanskrit:"दुर्गाभवानी",icon:"🦁"},{id:"saraswati",name:"Maa Saraswati",sanskrit:"भगवती सरस्वती",icon:"🪕"},{id:"murugan",name:"Lord Murugan",sanskrit:"सुब्रह्मण्यः",icon:"🪶"},{id:"venkateswara",name:"Sri Venkateswara",sanskrit:"श्रीवेङ्कटेश्वरः",icon:"👑"},{id:"ayyappan",name:"Lord Ayyappan",sanskrit:"धर्मशास्ता",icon:"🔔"}],oa=[{id:"ganesha-pancharatnam",title:"Ganesha Pancharatnam (Verse 1)",deityId:"ganesha",deity:"Sri Ganesha",category:"Stotra",source:"Adi Shankaracharya Stotraavali",meter:"Malini",devanagari:`मुदाकरात्तमोदकं सदा विमुक्तिसाधकं
कलाधरावतंसकं विलासिलोकरक्षकम् ।
अनायकैकनायकं विनाशितेभदैत्यकं
नताशुभाशूनाशकं नमामि तं विनायकम् ॥`,iast:`mudākarātta-modakaṃ sadā vimukti-sādhakaṃ
kalādharāvataṃsakaṃ vilāsi-loka-rakṣakam ।
anāyakaika-nāyakaṃ vināśitebha-daityakaṃ
natāśubhāśūnāśakaṃ namāmi taṃ vināyakam ॥`,sabdartha:[{word:"मुदाकरात्तमोदकम्",meaning:"Holding the sweet modaka with joyous grace"},{word:"सदा विमुक्तिसाधकम्",meaning:"Who constantly bestows ultimate spiritual liberation"},{word:"कलाधरावतंसकम्",meaning:"Adorned with the crescent moon on His crown"},{word:"विलासिलोकरक्षकम्",meaning:"The compassionate protector of the whole creation"},{word:"अनायकैकनायकम्",meaning:"The supreme leader of those who have no protector"},{word:"विनाशितेभदैत्यकम्",meaning:"The destroyer of the arrogant demon Gajasura"},{word:"नताशुभाशूनाशकम्",meaning:"Who swiftly dissolves the misfortunes of surrendered devotees"},{word:"नमामि तं विनायकम्",meaning:"I bow before that supreme remover of obstacles, Sri Vinayaka"}],translation:"Holding a delightful sweet modaka in His hand, ever bestowing liberation, wearing the crescent moon upon His crown, protecting the manifested universe, the supreme refuge of the helpless, the destroyer of the demon Gajasura, who swiftly dissolves the inauspicious obstacles of those who surrender to Him — to that supreme Lord Vinayaka, I bow with deep reverence.",purport:"Composed by Jagadguru Adi Shankaracharya, the Ganesha Pancharatnam invokes Lord Ganesha not merely as an elephant-headed deity of fortune, but as the cosmic archetype of supreme intellect and compassion."},{id:"vakratunda-mahakaya",title:"Vakratunda Mahakaya (Prarthana)",deityId:"ganesha",deity:"Sri Ganesha",category:"Mantra",source:"Mudgala Purana & Brahma Vaivarta Purana",meter:"Anushtubh",devanagari:`वक्रतुण्ड महाकाय सूर्यकोटिसमप्रभ ।
निर्विघ्नं कुरु मे देव सर्वकार्येषु सर्वदा ॥`,iast:`vakratuṇḍa mahākāya sūryakoṭi-samaprabha ।
nirvighnaṃ kuru me deva sarva-kāryeṣu sarvadā ॥`,sabdartha:[{word:"वक्रतुण्ड",meaning:"O Lord with the gracefully curved trunk"},{word:"महाकाय",meaning:"Possessor of the vast, cosmic form"},{word:"सूर्यकोटिसमप्रभ",meaning:"Whose radiance equals ten million blazing suns"},{word:"निर्विघ्नम्",meaning:"Free of hindrances, impediments, or obstacles"},{word:"कुरु",meaning:"Please make / render"},{word:"मे",meaning:"My"},{word:"देव",meaning:"O Divine Lord"},{word:"सर्वकार्येषु",meaning:"In all endeavors and righteous duties"},{word:"सर्वदा",meaning:"At all times and across all paths"}],translation:"O Lord of the curved trunk and immense cosmic form, whose divine brilliance equals ten million suns: please remove all obstacles from all my endeavors, always and in every step.",purport:"The universal opening invocation of Sanatana Dharma. The curved trunk (Vakra-tunda) symbolizes the primordial sound Pranava Om, capable of breaking through the densest material and karmic blockages."},{id:"maha-mrityunjaya",title:"Maha Mrityunjaya Mantra (Rudra Mantra)",deityId:"shiva",deity:"Lord Shiva",category:"Mantra",source:"Rigveda Samhita (Mandala 7, Sukta 59, Mantra 12)",meter:"Anushtubh",devanagari:`ॐ त्र्यम्बकं यजामहे सुगन्धिं पुष्टिवर्धनम् ।
उर्वारुकमिव बन्धनान्मृत्यchainsोर्मुक्षीय माऽमृतात् ॥`.replace("chains",""),iast:`oṃ tryambakaṃ yajāmahe sugandhiṃ puṣṭi-vardhanam ।
urvārukam iva bandhanān mṛtyor mukṣīya mā'mṛtāt ॥`,sabdartha:[{word:"त्र्यम्बकम्",meaning:"The Three-Eyed Lord Shiva, perceiver of past, present, and future"},{word:"यजामहे",meaning:"We worship, revere, and adore"},{word:"सुगन्धिम्",meaning:"The fragrant one, emitting divine virtue and wisdom"},{word:"पुष्टिवर्धनम्",meaning:"The nourisher of all life, who enhances vitality"},{word:"उर्वारुकम् इव",meaning:"Just like a fully ripened melon"},{word:"बन्धनात्",meaning:"From its stem and the bondage of attachment"},{word:"मृत्योः मुक्षीय",meaning:"May You liberate us from physical mortality and suffering"},{word:"मा अमृतात्",meaning:"Never separating us from the nectar of divine truth"}],translation:"We worship the Three-Eyed Lord Shiva, who is fragrant with transcendental virtue and nourishes all living beings. Just as a ripe melon effortlessly detaches from its vine, may He liberate us from the bondage of death and mortality, without separating us from Immortality.",purport:"Revealed by Rishi Markandeya, this profound healing mantra conquers fear of death and bodily decay. Devotees chant it 108 times daily to neutralize afflictions and cultivate fearless detachment."},{id:"vishnu-sahasranama-dhyanam",title:"Sri Vishnu Sahasranama (Dhyana Sloka)",deityId:"vishnu",deity:"Lord Vishnu",category:"Stotra",source:"Mahabharata (Anushasana Parva, Section 149)",meter:"Anushtubh",devanagari:`शान्ताकारं भुजगशयनं पद्मनाभं सुरेशं
विश्वाधारं गगनसदृशं मेघवर्णं शुभाङ्गम् ।
लक्ष्मीकान्तं कमलनयनं योगिभिर्ध्यानगम्यं
वन्दे विष्णुं भवभयहरं सर्वलोकैकनाथम् ॥`,iast:`śāntākāraṃ bhujaga-śayanaṃ padma-nābhaṃ sureśaṃ
viśvādhāraṃ gagana-sadṛśaṃ megha-varṇaṃ śubhāṅgam ।
lakṣmī-kāntaṃ kamala-nayanaṃ yogibhir-dhyāna-gamyaṃ
vande viṣṇuṃ bhava-bhaya-haraṃ sarva-lokaika-nātham ॥`,sabdartha:[{word:"शान्ताकारम्",meaning:"Embodiment of serenity and unshakable tranquility"},{word:"भुजगशयनम्",meaning:"Resting upon the serpent Ananta Sesha"},{word:"पद्मनाभम्",meaning:"From whose navel blossoms the cosmic lotus of creation"},{word:"सुरेशम्",meaning:"Lord of the celestials and gods"},{word:"विश्वाधारम्",meaning:"The ultimate foundation and support of the entire universe"},{word:"गगनसदृशम्",meaning:"Infinite, unbounded, and all-pervading like space"},{word:"मेघवर्णम्",meaning:"Having the soothing, merciful hue of rain-bearing clouds"},{word:"लक्ष्मीकान्तम्",meaning:"The beloved consort of Goddess Lakshmi"},{word:"भवभयहरम्",meaning:"The dispeller of fears of samsara"}],translation:"I bow to Lord Vishnu, the embodiment of peace, reclining upon the cosmic serpent Ananta, whose navel produces the creator Brahma upon a lotus. The bedrock of creation, vast as the sky, dark as a rain-cloud, consort of Lakshmi, realized through meditation by yogis: I revere Vishnu, who banishes the fears of mortal existence.",purport:"Composed by Bhishma Pitamaha upon the arrow bed in the presence of Lord Krishna. Reciting this dhyana sloka aligns the mind with the all-sustaining preservation energy of the cosmos."},{id:"gita-2-47",title:"Nishkama Karma (Gita 2.47)",deityId:"krishna",deity:"Sri Krishna",category:"Mantra",source:"Srimad Bhagavad Gita (Chapter 2, Verse 47)",meter:"Anushtubh",devanagari:`कर्मण्येवाधिकारस्ते मा फलेषु कदाचन ।
मा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि ॥`,iast:`karmaṇy-evādhikāras-te mā phaleṣu kadācana ।
mā karma-phala-hetur-bhūr-mā te saṅgo'stv-akarmaṇi ॥`,sabdartha:[{word:"कर्मणि एव",meaning:"In action alone lies your rightful domain"},{word:"अधिकारः ते",meaning:"Your prerogative and moral responsibility"},{word:"मा फलेषु कदाचन",meaning:"Never in the fruits or outcomes"},{word:"मा कर्मफलहेतुः भूः",meaning:"Do not let the outcome be your sole motive"},{word:"मा ते सङ्गः अस्तु अकर्मणि",meaning:"Nor let your heart become attached to inaction"}],translation:"You have a right only to perform your prescribed duty, but never to the fruits of action. Let not the fruit of action be your motive, nor let your attachment be toward inaction.",purport:"The cardinal formula for liberation in everyday modern life. By decoupling one's emotional well-being from uncontrollable external results, one attains boundless focus, resilience, and joyful mastery."},{id:"rama-raksha-opening",title:"Sri Rama Raksha Stotram (Opening)",deityId:"rama",deity:"Sri Rama",category:"Stotra",source:"Padma Purana (Revealed by Sage Budha Kaushika)",meter:"Anushtubh",devanagari:`चरितं रघुनाथस्य शतकोटिप्रविस्तरम् ।
एकैकमक्षरं पुंसां महापातकनाशनम् ॥
ध्यात्वा नीलोत्पलश्यामं रामं राजीवलोचनम् ।
जानकीलक्ष्मणोपेतं जटामुकुटमण्डितम् ॥`,iast:`caritaṃ raghunāthasya śatakoṭi-pravistaram ।
ekaikam akṣaraṃ puṃsāṃ mahāpātaka-nāśanam ॥
dhyātvā nīlotpala-śyāmaṃ rāmaṃ rājīva-locanam ।
jānakī-lakṣmaṇopetaṃ jaṭā-mukuṭa-maṇḍitam ॥`,sabdartha:[{word:"चरितम् रघुनाथस्य",meaning:"The divine life story of Sri Raghunatha (Lord Rama)"},{word:"शतकोटिप्रविस्तरम्",meaning:"Extending across a billion verses in scope"},{word:"एकैकम् अक्षरम्",meaning:"Every single syllable of which"},{word:"महापातकनाशनम्",meaning:"Has the power to eradicate the gravest sins and karmas"},{word:"नीलोत्पलश्यामम्",meaning:"Having the radiant hue of a blue water lily"},{word:"राजीवलोचनम्",meaning:"Endowed with gentle lotus eyes"},{word:"जानकीलक्ष्मणोपेतम्",meaning:"Accompanied by Mother Sita and faithful Lakshmana"}],translation:"The holy deeds of Sri Rama span a billion verses; every single syllable destroys the gravest karmic misdeeds. Meditating on Rama, dark-complexioned like the blue lotus, lotus-eyed, wearing crowns of matted locks, accompanied by Sita and Lakshmana — we seek His celestial shield.",purport:"Sage Budha Kaushika received this armour of protection in a sacred dream from Lord Shiva Himself. It surrounds the chanter's physical body, aura, and mind with an impenetrable circle of divine protection."},{id:"hanuman-chalisa-opening",title:"Sri Hanuman Chalisa (Doha & Chaupai 1)",deityId:"hanuman",deity:"Sri Hanuman",category:"Chalisa",source:"Goswami Tulsidas (Awadhi / Sanskrit Tradition)",meter:"Doha & Chaupai",devanagari:`श्रीगुरु चरन सरोज रज निज मनु मुकुरु सुधारि ।
बरनउँ रघुबर बिमल जसु जो दायकु फल चारि ॥
बुद्धिहीन तनु जानिके सुमिरौ पवन-कुमार ।
बल बुधि बिद्या देहु मोहिं हरहु कलेस बिकार ॥
जय हनुमान ज्ञान गुन सागर ।
जय कपीस तिहुँ लोक उजागर ॥`,iast:`śrī-guru carana saroja raja nija manu mukuru sudhāri ।
baranauṃ raghubara bimala jasu jo dāyaku phala cāri ॥
buddhi-hīna tanu jānike sumirau pavana-kumāra ।
bala budhi bidyā dehu mohiṃ harahu kalesa bikāra ॥
jaya hanumāna jñāna guna sāgara ।
jaya kapīsa tihuṃ loka ujāgara ॥`,sabdartha:[{word:"श्रीगुरु चरन सरोज रज",meaning:"With the sacred dust of the Guru's lotus feet"},{word:"निज मनु मुकुरु सुधारि",meaning:"Cleansing the mirror of my heart and mind"},{word:"बरनउँ रघुबर बिमल जसु",meaning:"I celebrate the pure glory of Sri Rama"},{word:"जो दायकु फल चारि",meaning:"Which grants the four life aims: Dharma, Artha, Kama, Moksha"},{word:"जय हनुमान",meaning:"Victory to Lord Hanuman"},{word:"ज्ञान गुन सागर",meaning:"Ocean of transcendental wisdom and supreme virtues"}],translation:"Cleansing the mirror of my mind with the dust from my Guru's lotus feet, I sing the unblemished glory of Sri Rama, which grants the four fruits of life. Knowing myself to be deficient in strength and wisdom, I meditate upon the Son of the Wind: grant me physical vigor, intellectual clarity, and divine knowledge, and vanquish my sorrows and mental impurities. Hail Hanuman, vast ocean of wisdom and virtues; hail the king of monkeys, who illumines the three cosmic worlds!",purport:"Chanted by hundreds of millions daily across the globe. Tulsidas wrote this while imprisoned, proving the power of pure devotion to dissolve mortal entrapment and mental distress."},{id:"mahalakshmi-ashtakam",title:"Sri Mahalakshmi Ashtakam (Verse 1)",deityId:"lakshmi",deity:"Maa Lakshmi",category:"Ashtakam",source:"Padma Purana (Uttered by Lord Indra)",meter:"Anushtubh",devanagari:`नमस्तेऽस्तु महामाये श्रीपीठे सुरपूजिते ।
शङ्खचक्रगदाहस्ते महालक्ष्मि नमोऽस्तु ते ॥`,iast:`namas-te'stu mahāmāye śrī-pīṭhe sura-pūjite ।
śaṅkha-cakra-gadā-haste mahālakṣmi namo'stu te ॥`,sabdartha:[{word:"नमस्ते अस्तु",meaning:"Salutations unto You"},{word:"महामाये",meaning:"O Divine Mother of supreme cosmic power (Mahamaya)"},{word:"श्रीपीठे",meaning:"Dweller upon the sacred seat of fortune (Shri Peetha)"},{word:"सुरपूजिते",meaning:"Revered and adored by all the devas"},{word:"शङ्खचक्रगदाहस्ते",meaning:"Holding the conch, discus, and mace in Your hands"},{word:"महालक्ष्मि",meaning:"O Supreme Mother Lakshmi"},{word:"नमोऽस्तु ते",meaning:"I offer my humble prostrations unto You"}],translation:"Salutations unto You, O Supreme Mother, sovereign of all cosmic illusion, seated upon the seat of prosperity, worshipped by all the celestials! Adorned with the divine conch, discus, and mace in Your hands — O Mother Mahalakshmi, I bow before You in adoration.",purport:"When Lord Indra lost all prosperity due to ego, he sang this eight-verse hymn to invoke Mother Lakshmi. She represents not merely financial currency, but the eightfold wealth (Ashta Lakshmi): courage, progeny, knowledge, food, spiritual sovereignty, and inner joy."},{id:"mahishasura-mardini-opening",title:"Aigiri Nandini (Mahishasura Mardini Stotram)",deityId:"durga",deity:"Maa Durga",category:"Stotra",source:"Adi Shankaracharya Tradition",meter:"Matra-chandas (Dynamic rhythm)",devanagari:`अयि गिरिनन्दिनि नन्दितमेदिनि विश्वविनोदिनि नन्दसुते
गिरिवरविन्ध्यशिरोऽधिनिवासिनि विष्णुविलासिनि जिष्णुनुते ।
भगवति हे शितिकण्ठकुटुम्बिनि भूरिकुटुम्बिनि भूरिकृते
जय जय हे महिषासुरमर्दिनि रम्यकपर्दिनि शैलसुते ॥`,iast:`ayi giri-nandini nandita-medini viśva-vinodini nanda-sute
girivara-vindhya-śiro'dhinivāsini viṣṇu-vilāsini jiṣṇu-nute ।
bhagavati he śitikaṇṭha-kuṭumbini bhūri-kuṭumbini bhūri-kṛte
jaya jaya he mahiṣāsura-mardini ramya-kapardini śaila-sute ॥`,sabdartha:[{word:"अयि गिरिनन्दिनि",meaning:"O Daughter of the sacred Mountain (Himavan)"},{word:"नन्दितमेदिनि",meaning:"Who brings joy and delight to the Mother Earth"},{word:"विश्वविनोदिनि",meaning:"Who rejoices in the play of the universe"},{word:"विष्णुविलासिनि",meaning:"Beloved sister of Lord Vishnu"},{word:"महिषासुरमर्दिनि",meaning:"Destroyer of the demon of delusion, Mahishasura"},{word:"रम्यकपर्दिनि",meaning:"Adorned with gorgeous braided locks of hair"},{word:"शैलसुते",meaning:"O Divine Daughter of the Mountain!"}],translation:"O Daughter of the Mountain, who gladdens the earth, who delights the cosmos, sister of Nanda, dwelling on the peaks of the Vindhya range, beloved of Vishnu, praised by Indra! O Consort of Shiva, Mother of all cosmic beings, who accomplishes great deeds — victory, victory unto You, O destroyer of Mahishasura, with exquisitely braided locks!",purport:"The sonic thunder of this hymn elevates the vitality of the chanter. Mahishasura represents dullness (Tamas), sloth, and destructive arrogance; Mother Durga's trident awakens radiant courage (Rajas purified by Sattva)."},{id:"saraswati-namastubhyam",title:"Saraswati Namastubhyam (Vidya Prarthana)",deityId:"saraswati",deity:"Maa Saraswati",category:"Mantra",source:"Saraswati Rahasya Upanishad",meter:"Anushtubh",devanagari:`सरस्वति नमस्तुभ्यं वरदे कामरूपिणि ।
विद्यारम्भं करिष्यामि सिद्धिर्भवतु मे सदा ॥`,iast:`sarasvati namas-tubhyaṃ varade kāma-rūpiṇi ।
vidyārambhaṃ kariṣyāmi siddhir-bhavatu me sadā ॥`,sabdartha:[{word:"सरस्वति",meaning:"O Goddess Saraswati, embodiment of flow and knowledge"},{word:"नमस्तुभ्यम्",meaning:"My humble prostrations unto You"},{word:"वरदे",meaning:"Giver of righteous boons and spiritual clarity"},{word:"कामरूपिणि",meaning:"Who fulfills pure auspicious aspirations"},{word:"विद्यारम्भम्",meaning:"Commencement of studies and learning"},{word:"करिष्यामि",meaning:"I am about to undertake"},{word:"सिद्धिः भवतु मे सदा",meaning:"May mastery, fulfillment, and illumination be mine always"}],translation:"O Goddess Saraswati, giver of blessings, fulfiller of all pure aspirations! As I begin my quest for wisdom, grant me unfailing success, mastery, and spiritual insight at all times.",purport:"The quintessential prayer for students, writers, and spiritual seekers. It establishes a sacred orientation to education: studying not just for career vanity, but for the blossoming of spiritual consciousness."},{id:"subrahmanya-bhujangam-verse1",title:"Subrahmanya Bhujangam (Opening Dhyana)",deityId:"murugan",deity:"Lord Murugan",category:"Stotra",source:"Adi Shankaracharya (Tiruchendur Kshetram)",meter:"Bhujangaprayata",devanagari:`सदा बालरूपाऽपि विघ्नाद्रिहन्त्री
महादन्तिवक्त्राऽपि पञ्चास्यमान्या ।
विधीन्द्रादिमृग्या गणेषाभिधा मे
विधत्तां श्रियं काऽपि कल्याणमूर्तिः ॥`,iast:`sadā bālarūpā'pi vighnādri-hantrī
mahā-danti-vaktrā'pi pañcāsya-mānyā ।
vidhīndrādi-mṛgyā gaṇeṣābhidhā me
vidhattāṃ śriyaṃ kā'pi kalyāṇa-mūrtiḥ ॥`,sabdartha:[{word:"सदा बालरूपा अपि",meaning:"Though ever appearing in the sweet form of a divine child"},{word:"विघ्नाद्रिहन्त्री",meaning:"Smasher of mountains of obstacles"},{word:"कल्याणमूर्तिः",meaning:"Embodiment of supreme auspiciousness and grace"},{word:"विधत्तां श्रियम्",meaning:"May He bestow boundless divine welfare and wisdom"}],translation:"Though appearing ever as a youthful child, He smashes mountains of obstacles; sought after by Brahma, Indra, and the gods, embodiment of eternal auspiciousness: may Lord Subrahmanya bestow divine grace, courage, and prosperity upon me.",purport:"Composed by Adi Shankaracharya at the seashore temple of Tiruchendur. Lord Murugan represents the sharp spear of spiritual discernment (Vel), cutting through the six inner enemies (Arishadvargas)."},{id:"venkateswara-suprabhatam-verse1",title:"Sri Venkateswara Suprabhatam (Verse 1)",deityId:"venkateswara",deity:"Sri Venkateswara",category:"Suprabhatam",source:"Sri Prativadi Bhayankaram Annan (Tirumala Kshetram)",meter:"Vasantatilaka",devanagari:`कौसल्या सुप्रजा राम पूर्वा सन्ध्या प्रवर्तते ।
उत्तिष्ठ नरशार्दूल कर्तव्यं दैवमाह्निकम् ॥`,iast:`kausalyā supra-jā rāma pūrvā sandhyā pravartate ।
uttiṣṭha nara-śārdūla kartavyaṃ daivam āhnikam ॥`,sabdartha:[{word:"कौसल्या सुप्रजा",meaning:"O noble son of mother Kausalya"},{word:"राम",meaning:"O Lord Rama (invoked as Lord of Seven Hills)"},{word:"पूर्वा सन्ध्या प्रवर्तते",meaning:"The auspicious eastern dawn has broken across the sky"},{word:"उत्तिष्ठ",meaning:"Please awaken from Your divine slumber"},{word:"नरशार्दूल",meaning:"O lion among human beings / sovereign Lord"},{word:"कर्तव्यम् दैवम् आह्निकम्",meaning:"The divine morning prayers and daily duties await Your presence"}],translation:"O noble son of Kausalya! The sacred eastern dawn has arrived. Awaken, O lion among leaders of men; the divine morning duties must now be performed for the welfare of the cosmos.",purport:"Sung every dawn at Tirumala Tirupati Devasthanam to gently awaken Lord Srinivasa. Listening to this suprabhatam at dawn aligns the human biological clock with the cosmic rhythms of light and devotion."},{id:"harivarasanam-verse1",title:"Harivarasanam (Viswamohanam - Verse 1)",deityId:"ayyappan",deity:"Lord Ayyappan",category:"Stotra",source:"Sri Kumbakudi Kulathur Iyer (Sabarimala Tradition)",meter:"Sanskrit Devotional Padam",devanagari:`हरिवरासनं विश्वमोहनं
हरिदधीश्वरं आराध्यपादुकम् ।
अरिविमर्दनं नित्यनर्तनं
हरिहरात्मजं देवमाश्रये ॥
शरणं अय्यप्पा स्वामि शरणं अय्यप्पा ।
शरणं अय्यप्पा स्वामि शरणं अय्यप्पा ॥`,iast:`hari-varāsanaṃ viśva-mohanaṃ
hari-dadhīśvaraṃ ārādhya-pādukam ।
ari-vimardanaṃ nitya-nartanaṃ
hari-harātmajaṃ devam āśraye ॥
śaraṇaṃ ayyappā svāmi śaraṇaṃ ayyappā ।
śaraṇaṃ ayyappā svāmi śaraṇaṃ ayyappā ॥`,sabdartha:[{word:"हरिवरासनम्",meaning:"Seated upon the glorious throne of Lord Hari"},{word:"विश्वमोहनम्",meaning:"Whose divine enchantment mesmerizes the entire cosmos"},{word:"आराध्यपादुकम्",meaning:"Whose sacred sandals are adored by yogis and ascetics"},{word:"अरिविमर्दनम्",meaning:"Destroyer of demonic enemies and inner delusion"},{word:"हरिहरात्मजम्",meaning:"Born of the holy union of Hari (Vishnu) and Hara (Shiva)"},{word:"देवम् आश्रये",meaning:"I surrender unto that supreme Divine Lord"}],translation:"Seated on the throne of Hari, the charmer of the universe, whose sacred sandals are worshipped by all, who vanquishes all enemies and dances eternally in blissful truth: born of Hari and Hara, in that Divine Lord Ayyappa I take refuge! Swamiye Saranam Ayyappa!",purport:"The celestial lullaby of Sabarimala. Chanted every night before the sanctum sanctorum doors close. It unifies the Vaishnava and Shaiva traditions into pure non-dual surrender."},{id:"gayatri-mantra",title:"Gayatri Mantra",deityId:"all",deity:"Universal (Savitr)",category:"Mantra",source:"Rigveda Samhita (Mandala 3, Sukta 62, Mantra 10)",meter:"Gayatri (24 syllables)",devanagari:`ॐ भूर्भुवः स्वः ।
तत्सवितुर्वरेण्यं भर्गो देवस्य धीमहि ।
धियो यो नः प्रचोदयात् ॥`,iast:`oṃ bhūr bhuvaḥ svaḥ ।
tat savitur vareṇyaṃ bhargo devasya dhīmahi ।
dhiyo yo naḥ pracodayāt ॥`,sabdartha:[{word:"ॐ (Om)",meaning:"The primordial sound, supreme cosmic reality"},{word:"भूः भुवः स्वः",meaning:"The physical, astral, and celestial planes"},{word:"तत् सवितुः वरेण्यम्",meaning:"That most adorable Light of the Divine Sun"},{word:"भर्गः देवस्य धीमहि",meaning:"We meditate upon the spiritual radiance of the Creator"},{word:"धियो यो नः प्रचोदयात्",meaning:"May that effulgence illuminate and guide our intellect"}],translation:"We meditate upon the supreme, most adorable radiance of that Divine Creator, the Sun of consciousness. May that effulgent Light illuminate, guide, and inspire our spiritual intellect and discernment.",purport:"The crown jewel of Vedic revelation. It is a sacred invocation for the awakening of higher intellect (Buddhi), clearing mental fog and aligning the human nervous system with cosmic intelligence."},{id:"shanti-mantra",title:"Sarve Bhavantu Sukhinah (Universal Peace)",deityId:"all",deity:"Universal (Paramatman)",category:"Prayer",source:"Brihadaranyaka Upanishad Tradition",meter:"Anushtubh",devanagari:`ॐ सर्वे भवन्तु सुखिनः सर्वे सन्तु निरामयाः ।
सर्वे भद्राणि पश्यन्तु मा कश्चिद्दुःखभाग्भवेत् ॥
ॐ शान्तिः शान्तिः शान्तिः ॥`,iast:`oṃ sarve bhavantu sukhinaḥ sarve santu nirāmayāḥ ।
sarve bhadrāṇi paśyantu mā kaścid duḥkha-bhāg bhavet ॥
oṃ śāntiḥ śāntiḥ śāntiḥ ॥`,sabdartha:[{word:"सर्वे भवन्तु सुखिनः",meaning:"May all beings everywhere be happy and peaceful"},{word:"सर्वे सन्तु निरामयाः",meaning:"May all beings be free from sickness and disease"},{word:"सर्वे भद्राणि पश्यन्तु",meaning:"May all behold goodness and nobility in each other"},{word:"मा कश्चित् दुःखभाग् भवेत्",meaning:"May no one be a partaker of grief or suffering"},{word:"शान्तिः",meaning:"Peace across body, mind, and soul"}],translation:"May all beings everywhere be happy. May all beings be free from disease and illness. May all behold only auspiciousness and goodness in one another. May no one suffer or be partaker of sorrow. Om Peace, Peace, Peace.",purport:"The living motto of Sanatana Dharma: Vasudhaiva Kutumbakam. It blesses humans, animals, nature, and every realm in existence with peace and wellness."}],Ra=[{id:"somnath",name:"Somnath Mahadev",sanskritName:"सोमनाथ ज्योतिर्लिङ्ग",location:"Prabhas Patan, Veraval, Saurashtra, Gujarat",coordinates:"20.8880° N, 70.4012° E",deityForm:"Chandra-Mauli Swayambhu Jyotirlinga",riverOrSea:"Triveni Sangam (Hiran, Kapila, Saraswati) & Arabian Sea",stotramVerse:"सौराष्ट्रे सोमनाथं च श्रीशैले मल्लिकार्जुनम् ।",iconSvg:`<svg viewBox="0 0 100 100" class="gk-jyotir-icon-svg" aria-label="Somnath Shikhara and Crescent Moon">
      <defs>
        <linearGradient id="somnathGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#FFD700" />
          <stop offset="100%" stop-color="#D4AF37" />
        </linearGradient>
      </defs>
      <circle cx="50" cy="50" r="46" fill="#1b0a2a" stroke="#d4af37" stroke-width="2"/>
      <path d="M50 14 L55 35 L62 35 L50 20 L38 35 L45 35 Z" fill="url(#somnathGrad)"/>
      <path d="M42 35 L58 35 L64 62 L36 62 Z" fill="#d4af37" opacity="0.85"/>
      <rect x="44" y="62" width="12" height="16" fill="#8b5a2b"/>
      <!-- Crescent Moon -->
      <path d="M72 22 A12 12 0 1 0 76 38 A9 9 0 1 1 72 22 Z" fill="#FFFAED"/>
      <!-- Waves -->
      <path d="M20 84 Q35 78 50 84 T80 84" fill="none" stroke="#4fc3f7" stroke-width="2"/>
      <path d="M50 8 L50 14" stroke="#FFD700" stroke-width="2"/>
      <circle cx="50" cy="8" r="2.5" fill="#FF5722"/>
    </svg>`,whatVisitDoes:{parikaras:"Chandra Graha Shanti (Moon afflictions), relief from psychological trauma, depression, anxiety, and psychosomatic ailments.",doshaNivarana:"Chandra Dosha, Kemadruma Yoga, Pitru Dosha, and eradication of debilitating physical curses (Kshaya Roga).",spiritualUpliftment:"Restores vitality (Ojas), mental clarity, tranquility of consciousness, and grants the bliss of immortality (Amritatva)."},specificPoojas:[{name:"Maha Somnath Rudrabhisheka",timing:"06:00 AM – 11:00 AM",details:"Performed with holy Triveni Sangam and sacred sea water, cow milk, honey, and Bilva leaves."},{name:"Sayam Sandhya Deepa Aarti",timing:"07:00 PM",details:"Majestic evening light offering with sounding of traditional conches, drums, and sea-wind chants."},{name:"Somvar Bilva Archana",timing:"All Mondays",details:"Offering of 108 or 1008 fresh trifoliate Bilva leaves inscribed with Chandan Om Namah Shivaya."},{name:"Mrityunjaya Homa",timing:"Pre-arranged",details:"Sacred fire oblations to conquer critical illnesses and fear of untimely demise."}],history:{puranic:"According to the Shiva Purana (Koti Rudra Samhita, Ch. 14), Chandra Deva (the Moon God) married 27 daughters of Prajapati Daksha. Because Chandra showed favoritism toward Rohini, Daksha cursed him with consumption (tuberculosis/decay of light). Waning into darkness, Chandra performed intense penance for 4,000 years at Prabhas Kshetra. Lord Shiva appeared, restored his 16 divine kalas (waxing and waning cycle), and resided here as Somnath ('Lord of the Moon').",local:"Prabhas Patan has been a supreme pilgrimage hub since the Mahabharata era. It is situated at the sacred Triveni Sangam of rivers Hiran, Kapila, and Saraswati. Nearby lies Bhalka Teertha, where Lord Sri Krishna completed His earthly pastimes and returned to Vaikuntha.",folklore:"The famous Baan Stambh (Arrow Pillar) on the sea-facing wall contains an ancient Sanskrit inscription stating that there is no obstruction of land between Somnath and the South Pole (Antarctica) along that precise longitude—an astronomical marvel celebrated for millennia."}},{id:"mallikarjuna",name:"Mallikarjuna Swami",sanskritName:"मल्लिकार्जुन ज्योतिर्लिङ्ग",location:"Srisailam, Nallamala Hills, Andhra Pradesh",coordinates:"16.0743° N, 78.8682° E",deityForm:"Swayambhu Linga & Bhramaramba Devi (Shakti Peetha)",riverOrSea:"Krishna River (Patalaganga)",stotramVerse:"उज्जयिन्यां महाकालमोंकारममलेश्वरम् ।",iconSvg:`<svg viewBox="0 0 100 100" class="gk-jyotir-icon-svg" aria-label="Mallikarjuna Lingam with Jasmine Flower">
      <defs>
        <radialGradient id="malliGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="#fff9c4" />
          <stop offset="100%" stop-color="#f57f17" />
        </radialGradient>
      </defs>
      <circle cx="50" cy="50" r="46" fill="#1e130c" stroke="#ffb300" stroke-width="2"/>
      <!-- Linga -->
      <path d="M38 65 C38 42 62 42 62 65 Z" fill="#424242"/>
      <ellipse cx="50" cy="65" rx="20" ry="6" fill="#616161"/>
      <path d="M50 67 L68 67 L68 70 L50 70 Z" fill="#616161"/>
      <!-- Tripundra & Bindi -->
      <rect x="45" y="48" width="10" height="1.5" fill="#ffffff"/>
      <rect x="45" y="51" width="10" height="1.5" fill="#ffffff"/>
      <rect x="45" y="54" width="10" height="1.5" fill="#ffffff"/>
      <circle cx="50" cy="52.5" r="1.2" fill="#d50000"/>
      <!-- Jasmine (Mallika) Blossom -->
      <circle cx="50" cy="30" r="6" fill="url(#malliGlow)"/>
      <circle cx="44" cy="28" r="4" fill="#ffffff" opacity="0.9"/>
      <circle cx="56" cy="28" r="4" fill="#ffffff" opacity="0.9"/>
      <circle cx="50" cy="23" r="4" fill="#ffffff" opacity="0.9"/>
    </svg>`,whatVisitDoes:{parikaras:"Mangala / Kuja Dosha, marital delays, family disputes, and relief from chronic penury.",doshaNivarana:"Kuja-Shani Shapa, Sarpa Dosha, and liberation from ancestral karmic entanglements.",spiritualUpliftment:"Awakening of Kundalini Shakti, harmonious integration of Shiva (Consciousness) and Shakti (Energy)."},specificPoojas:[{name:"Sparsha Darshanam",timing:"Morning & Afternoon",details:"Devotees enjoy the rare scriptural privilege of directly touching the sacred Jyotirlinga and offering abhishekam with their own hands."},{name:"Bhramaramba Kunkumarchana",timing:"Daily",details:"Sacred vermillion offering at the sanctum of the 18th Maha Shakti Peetha within the same temple compound."},{name:"Kalyanotsavam",timing:"Evening",details:"Celestial wedding ceremony of Lord Mallikarjuna and Goddess Bhramaramba."},{name:"Patalaganga Snanam",timing:"Pre-dawn",details:"Purificatory holy dip in the Krishna river descending deep through the Nallamala gorge."}],history:{puranic:"When Kartikeya felt despondent after Lord Ganesha circumnavigated Shiva and Parvati as the embodiment of the universe, He retired to Mount Krauncha. Desiring to console Him, Shiva and Parvati followed. Parvati resided as 'Mallika' (jasmine flower) and Shiva as 'Arjuna', manifesting together at Srisailam.",local:"Revered as the 'Kailash of Southern India', Srisailam's monolithic stone walls were patronized by the Kakatiya rulers, Vijayanagara monarchs (especially Sri Krishna Deva Raya), and Chhatrapati Shivaji Maharaj, who built the temple's northern gopuram in 1677 CE.",folklore:"Local Chenchu tribes revere Shiva as 'Chenchu Malliah' and narrate songs of how Shiva manifested as a hunter to protect the hill forests. Adi Shankaracharya meditated here at Hatakeshwara caves and composed the devotional masterpiece *Sivanandalahari*."}},{id:"mahakaleshwar",name:"Mahakaleshwar Mahadev",sanskritName:"महाकालेश्वर ज्योतिर्लिङ्ग",location:"Ujjain (Avantika), Madhya Pradesh",coordinates:"23.1827° N, 75.7682° E",deityForm:"Dakshinamoorthi (South-Facing) Swayambhu Jyotirlinga",riverOrSea:"Shipra River (Holy Kshipra)",stotramVerse:"उज्जयिन्यां महाकालमोंकारममलेश्वरम् ।",iconSvg:`<svg viewBox="0 0 100 100" class="gk-jyotir-icon-svg" aria-label="Mahakaleshwar Bhasma Aarti Icon">
      <circle cx="50" cy="50" r="46" fill="#14070a" stroke="#e53935" stroke-width="2"/>
      <!-- Trishul -->
      <path d="M50 14 L50 82 M40 24 Q50 36 60 24 M40 18 L40 24 M60 18 L60 24" fill="none" stroke="#ffd54f" stroke-width="2.5"/>
      <circle cx="50" cy="14" r="2" fill="#ffd54f"/>
      <!-- Damru -->
      <polygon points="44,40 56,40 44,52 56,52" fill="#d7ccc8" stroke="#8d6e63" stroke-width="1.5"/>
      <!-- Bhasma Swirls -->
      <circle cx="50" cy="66" r="14" fill="#424242"/>
      <ellipse cx="50" cy="66" rx="10" ry="4" fill="#9e9e9e"/>
      <path d="M42 63 Q50 58 58 63" stroke="#eeeeee" stroke-width="1.5" fill="none"/>
    </svg>`,whatVisitDoes:{parikaras:"Akal Mrityu Nivarana (conquest over fear of premature death), critical medical recoveries, and court litigation protection.",doshaNivarana:"Kaal Sarp Dosha, Rahu-Ketu afflictions, Balarishta Dosha, and planetary malefic transitions.",spiritualUpliftment:"Transcending the illusion of mortal time (Kala), developing fearless detachment, and inner sovereign willpower."},specificPoojas:[{name:"World-Renowned Bhasma Aarti",timing:"04:00 AM – 06:00 AM",details:"A sacred pre-dawn rite where Lord Mahakal is bathed in sacred cow-dung ash accompanied by resounding drums, damru, and conch shells."},{name:"Panchamrit Abhishek",timing:"07:30 AM",details:"Ceremonial bathing using milk, curd, honey, ghee, and sugar candy accompanied by Rudra Prashna chanting."},{name:"Sandhya Shringar Darshan",timing:"07:00 PM",details:"Linga adorned in ornate silver masks resembling royal forms of Shiva."},{name:"Shri Nagchandreshwar Darshan",timing:"Nag Panchami only",details:"Third-tier sanctum opened for devotees strictly once a year on Shukla Panchami of Shravana."}],history:{puranic:"In the Shiva Purana, an evil demon named Dushana terrorized the pious residents and sages of Avantika. Pushed to despair, devotees invoked Lord Shiva. Shiva erupted from the earth as Mahakala—the cosmic dissolution of Time—and reduced the demon to ashes with a solitary roar, choosing to reside here facing South (the direction of Yama) to protect His devotees forever.",local:"Ujjain is one of the seven holy Moksha Puris (Sapta Puri) and hosts the Simhastha Kumbh Mela every 12 years. Ancient Indian astronomers identified Ujjain as the Prime Meridian (Zero Longitude) and the center of the world's time calculations (Kala-Chakra).",folklore:"Royal folklore strictly forbids any reigning Prime Minister, President, or monarch from staying overnight inside the municipal limits of Ujjain, honoring Lord Mahakal as the sole living sovereign ruler of Avantika."}},{id:"omkareshwar",name:"Omkareshwar & Mamleshwar",sanskritName:"ओंकारेश्वर ज्योतिर्लिङ्ग",location:"Mandhata Island, Narmada River, Khandwa, Madhya Pradesh",coordinates:"22.2458° N, 76.1517° E",deityForm:"Pranava-Akara (Natural ॐ Shaped Holy Island)",riverOrSea:"Narmada River (Reva)",stotramVerse:"उज्जयिन्यां महाकालमोंकारममलेश्वरम् ।",iconSvg:`<svg viewBox="0 0 100 100" class="gk-jyotir-icon-svg" aria-label="Omkareshwar Pranava Om and Island">
      <circle cx="50" cy="50" r="46" fill="#0d1b2a" stroke="#e0a96d" stroke-width="2"/>
      <!-- Sacred Om Glyph -->
      <text x="50" y="60" font-family="'Cinzel', serif" font-size="44" fill="#ffd700" text-anchor="middle" font-weight="bold">ॐ</text>
      <!-- Narmada River Waves -->
      <path d="M15 80 Q32 72 50 80 T85 80" fill="none" stroke="#00b4d8" stroke-width="2.5"/>
    </svg>`,whatVisitDoes:{parikaras:"Guru Chandal Dosha, spiritual stagnation, lack of divine initiation, and dissolution of generational grief.",doshaNivarana:"Intellectual bewilderment, speech afflictions, and karmic burdens from disrespecting preceptors.",spiritualUpliftment:"Awakening to the cosmic Pranava sound vibration, inner peace, and profound yogic absorption."},specificPoojas:[{name:"Narmada Jalabhisheka",timing:"05:00 AM – 12:00 PM",details:"Pouring the crystal waters of holy Mother Narmada over both Omkareshwar and Mamleshwar Lingas."},{name:"Mandhata Island Parikrama",timing:"Morning / Sunset",details:"Sacred 7 km circumambulation around the sacred island contoured in the shape of Pranava ॐ."},{name:"Maha Shayan Aarti",timing:"08:30 PM",details:"Night slumber ritual where games of Chaupar are placed for Lord Shiva and Goddess Parvati."}],history:{puranic:"King Mandhata of the Ikshvaku dynasty undertook arduous penance here until Lord Shiva granted him the boon of eternal residence. Furthermore, Vindhya Mountain prayed to Shiva to expiate its hubris and become comparable to Mount Meru, upon which Shiva split into two shrines: Omkareshwar on the island and Mamleshwar (Amareshwar) on the mainland.",local:"Narmada is considered the holiest river for circumambulation; every naturally rolled pebble from the riverbed is revered as a self-manifested Narmadeshwara Baana Linga.",folklore:"In the sacred river caves below the temple, Jagadguru Adi Shankaracharya met his guru Govinda Bhagavatpada and received formal Sannyasa Diksha, commencing his historic nationwide revival of Sanatana Dharma."}},{id:"kedarnath",name:"Kedarnath Mahadev",sanskritName:"केदारनाथ ज्योतिर्लिङ्ग",location:"Rudraprayag District, Garhwal Himalayas, Uttarakhand (3,583m)",coordinates:"30.7352° N, 79.0669° E",deityForm:"Triangular Natural Stone Hump (Swayambhu)",riverOrSea:"Mandakini River",stotramVerse:"परल्यां वैद्यनाथं च डाकिन्यां भीमशङ्करम् ।",iconSvg:`<svg viewBox="0 0 100 100" class="gk-jyotir-icon-svg" aria-label="Kedarnath Himalayan Sanctum">
      <circle cx="50" cy="50" r="46" fill="#0b1d28" stroke="#81d4fa" stroke-width="2"/>
      <!-- Snow Mountains -->
      <polygon points="15,65 35,32 55,65" fill="#eceff1" opacity="0.6"/>
      <polygon points="45,65 68,22 90,65" fill="#ffffff" opacity="0.9"/>
      <!-- Ancient Stone Shikhara -->
      <polygon points="40,55 50,38 60,55" fill="#78909c"/>
      <rect x="42" y="55" width="16" height="20" fill="#455a64"/>
      <!-- Mandakini Stream -->
      <path d="M25 85 Q50 78 75 85" stroke="#4fc3f7" stroke-width="3" fill="none"/>
    </svg>`,whatVisitDoes:{parikaras:"Moksha Prapti (liberation), eradication of severe Sanchita Karma (accumulated lifetimes of sins), and freedom from fear of death.",doshaNivarana:"Crucial life blocks, ancestral curses, and Saturnine karmic retributions.",spiritualUpliftment:"Ascension into higher spiritual dimensions, absolute surrender, and detachment from worldly illusions."},specificPoojas:[{name:"Maha Abhishek & Ghee Archana",timing:"04:00 AM",details:"Sacred bathing of the triangular hump using pure desi cow ghee, honey, and high-altitude holy herbs."},{name:"Brahma Kamal Arpan",timing:"Morning",details:"Devotional offering of the rare mystical Himalayan Brahma Kamal flower harvested from glacial altitudes."},{name:"Akhanda Deepa Darshan",timing:"Evening",details:"Darshan of the perpetual ghee lamp that stays illuminated even during the 6 months of freezing winter lock-in."}],history:{puranic:"In the Mahabharata, the Pandavas sought redemption from Lord Shiva for the bloodshed of the Kurukshetra war. Shiva, eluding them, took the form of a celestial bull. When Bhima recognized Him, the bull dove into the earth. The triangular hump remained at Kedarnath, while other parts emerged across the Panch Kedar shrines.",local:"The temple is inaccessible in heavy snow from November to April, during which the Utsava Murti is ritually transported to Omkareshwar Temple at Ukhimath for regular winter worship.",folklore:"Adi Shankaracharya attained Mahasamadhi directly behind the Kedarnath temple at the young age of 32. Devotees believe that a pilgrim who passes away in the Kedarkhand territory attains instant Sayujya Mukti."}},{id:"bhimashankar",name:"Bhimashankar Mahadev",sanskritName:"भीमशङ्कर ज्योतिर्लिङ्ग",location:"Khed / Pune, Sahyadri Hills, Maharashtra",coordinates:"19.0720° N, 73.5358° E",deityForm:"Maha Linga (Swayambhu Pillar)",riverOrSea:"Bhima River (Origin)",stotramVerse:"परल्यां वैद्यनाथं च डाकिन्यां भीमशङ्करम् ।",iconSvg:`<svg viewBox="0 0 100 100" class="gk-jyotir-icon-svg" aria-label="Bhimashankar Forest Sanctuary">
      <circle cx="50" cy="50" r="46" fill="#0f2613" stroke="#81c784" stroke-width="2"/>
      <!-- Forest Canopy -->
      <path d="M25 65 Q35 35 50 65 Q65 35 75 65 Z" fill="#2e7d32" opacity="0.8"/>
      <!-- Nagara Shikhara -->
      <polygon points="45,45 50,30 55,45" fill="#a1887f"/>
      <rect x="46" y="45" width="8" height="25" fill="#5d4037"/>
      <!-- River Bhima origin trickle -->
      <path d="M50 70 Q45 78 50 85" stroke="#80deea" stroke-width="2.5" fill="none"/>
    </svg>`,whatVisitDoes:{parikaras:"Shani Sade Sati protection, courage against demonic energies, court triumphs, and removal of panic/anxiety disorders.",doshaNivarana:"Rakshasa Dosha, sudden reversals of fortune, and fear of hostile adversaries.",spiritualUpliftment:"Infuses immense physical and spiritual stamina (Bala), righteous tenacity, and unwavering devotion."},specificPoojas:[{name:"Prathama Jalabhishek",timing:"04:30 AM",details:"Holy abhisheka using fresh water collected directly from the pristine origins of River Bhima."},{name:"Rudrabhishekam with Bilva Patra",timing:"Morning & Afternoon",details:"Elaborate chanting of Sri Rudram with thousand bilva leaves offered to the massive Swayambhu lingam."},{name:"Pradosha Vrata Puja",timing:"Twice monthly",details:"Special evening lamp festival and archana performed on trayodashi tithis."}],history:{puranic:"Demon Bhima, son of Kumbhakarna and Karkati, acquired boons from Brahma and terrorized the cosmos, imprisoning sage Kamrupeshwar who worshipped a clay linga. When the demon struck the linga with his sword, Lord Shiva erupted from it and reduced Bhima to ashes, agreeing to stay forever as Bhimashankar.",local:"Nestled in dense Sahyadri Western Ghat forests, this kshetra is a biodiversity hotspot and home to the giant flying squirrel (Shekru), the state animal of Maharashtra.",folklore:"The perspiration that flowed from Shiva's body during His ferocious duel with the demon formed the originating springs of the sacred Bhima River."}},{id:"kashi-vishwanath",name:"Kashi Vishwanath (Vishveshwara)",sanskritName:"काशी विश्वनाथ ज्योतिर्लिङ्ग",location:"Varanasi (Kashi / Banaras), Uttar Pradesh",coordinates:"25.3109° N, 83.0107° E",deityForm:"Vishwanatha (Golden Shikhara Swayambhu Linga)",riverOrSea:"Holy Ganga (Uttaravahini)",stotramVerse:"वाराणस्यां च विश्वेशं त्र्यम्बकं गौतमीतटे ।",iconSvg:`<svg viewBox="0 0 100 100" class="gk-jyotir-icon-svg" aria-label="Kashi Vishwanath Golden Shikhara">
      <circle cx="50" cy="50" r="46" fill="#1f1105" stroke="#ffb300" stroke-width="2"/>
      <!-- Golden Shikhara -->
      <polygon points="40,55 50,18 60,55" fill="#ffd700"/>
      <polygon points="45,55 50,22 55,55" fill="#ffe082"/>
      <!-- Kalasha -->
      <circle cx="50" cy="16" r="3" fill="#ff6f00"/>
      <!-- Ganga Waves -->
      <path d="M15 82 Q32 75 50 82 T85 82" stroke="#4fc3f7" stroke-width="3" fill="none"/>
      <!-- Crescent & Bindi -->
      <path d="M47 38 A4 4 0 0 0 53 38" stroke="#ffffff" stroke-width="1.5" fill="none"/>
    </svg>`,whatVisitDoes:{parikaras:"Ultimate liberation (Moksha), instant absolution of the heaviest karmic baggage, and peaceful crossing over (Taraka Upadesha).",doshaNivarana:"Brahmahatya Dosha, severe ancestral unrest, and fear of rebirth cycles.",spiritualUpliftment:"Bestows the highest Advaitic enlightenment; direct realization that the individual soul (Atman) is Shiva (Paramatman)."},specificPoojas:[{name:"Mangala Aarti",timing:"03:00 AM – 04:00 AM",details:"Exclusive mystical awakening ceremony with sacred chants, damru beats, and early morning Gangajal abhisheka."},{name:"Saptarishi Aarti",timing:"07:00 PM – 08:30 PM",details:"Ancient ritual conducted simultaneously by seven different Brahmin priests representing the Seven Saptarishis."},{name:"Shringar & Shayan Aarti",timing:"09:00 PM – 10:30 PM",details:"Grand floral adornment followed by cosmic lullaby chants before the temple closes."}],history:{puranic:"Skanda Purana's Kashi Khanda reveals that Kashi rests not upon the mortal earth, but upon the three prongs of Lord Shiva's Trishul. At the hour of death in Kashi, Lord Vishveshwara Himself whispers the sacred Taraka Mantra into the right ear of the departed soul.",local:"Reconstructed by Queen Ahilyabai Holkar of Indore in 1780; Maharaja Ranjit Singh of Punjab donated 1,000 kilograms of pure gold in 1835 to plate the sanctum shikharas.",folklore:"When Sage Agastya had to travel south to tame the rising Vindhya mountains, he wept bitterly at being parted from Kashi Vishwanath, knowing that every single pebble in Kashi is a conscious manifestation of Shiva."}},{id:"trimbakeshwar",name:"Trimbakeshwar Mahadev",sanskritName:"त्र्यम्बकेश्वर ज्योतिर्लिङ्ग",location:"Trimbak, Nashik, Maharashtra",coordinates:"19.9324° N, 73.5308° E",deityForm:"Three-Faced Cavity Linga (Brahma, Vishnu, Maheshwara)",riverOrSea:"Godavari River Origin (Dakshina Ganga)",stotramVerse:"वाराणस्यां च विश्वेशं त्र्यम्बकं गौतमीतटे ।",iconSvg:`<svg viewBox="0 0 100 100" class="gk-jyotir-icon-svg" aria-label="Trimbakeshwar Three Lingam Crown">
      <circle cx="50" cy="50" r="46" fill="#1a1c23" stroke="#b0bec5" stroke-width="2"/>
      <!-- Black Basalt Temple Outline -->
      <polygon points="35,65 50,32 65,65" fill="#37474f"/>
      <!-- Cavity with 3 Thumbs (Brahma Vishnu Rudra) -->
      <ellipse cx="50" cy="62" rx="14" ry="5" fill="#212121"/>
      <circle cx="43" cy="60" r="2.5" fill="#ffd700"/>
      <circle cx="50" cy="59" r="2.5" fill="#ff9800"/>
      <circle cx="57" cy="60" r="2.5" fill="#e53935"/>
      <!-- Jeweled Mukut Outline -->
      <path d="M42 46 L50 38 L58 46 Z" fill="#ffc107"/>
    </svg>`,whatVisitDoes:{parikaras:"The premier global center for Narayan Nagbali, Kaal Sarp Shanti, Tripindi Shraddha, and neutralizing severe curses from ancestors.",doshaNivarana:"Pitru Dosha, Sarpa Shapa (curse of snakes), Kuja Dosha, and inability to maintain wealth or lineage continuity.",spiritualUpliftment:"Reconciles the tripartite energies of Creation (Brahma), Preservation (Vishnu), and Transformation (Rudra) within the aspirant."},specificPoojas:[{name:"Narayan Nagbali Puja",timing:"3-Day Vedic Ritual",details:"Conducted only at Trimbakeshwar to liberate souls of untimely-deceased ancestors and expiate unintentional snake killing."},{name:"Kaal Sarp Dosh Nivaran",timing:"Daily Mornings",details:"Vedic Hawan and silver snake offering to appease Rahu and Ketu planetary axes."},{name:"Kushavarta Kund Snanam",timing:"Pre-abhisheka",details:"Purification in the sacred water tank where Sage Gautama trapped the celestial river Godavari."},{name:"Suvarna Mukut Darshan",timing:"Mondays 04:00 PM – 05:00 PM",details:"Special display of the ancient diamond and emerald jewel-encrusted crown dating from the Pandavas."}],history:{puranic:"Sage Gautama resided here during a 24-year severe drought. Sages jealous of his inexhaustible granary used an illusionary cow that died when Gautama tried to herd it away. Penitent, Gautama performed fierce austerities to Shiva, who released the river Godavari from His matted locks and established the Trimbakeshwar Jyotirlinga.",local:"The unique Jyotirlinga is not an upright pillar, but a natural depression containing three miniature lingas symbolizing Brahma, Vishnu, and Shiva.",folklore:"Water continuously oozes from the eye of the linga cavity, feeding the eternal flow of the Dakshina Ganga (Godavari)."}},{id:"vaidyanath",name:"Baidyanath / Vaidyanath",sanskritName:"वैद्यनाथ ज्योतिर्लिङ्ग",location:"Deoghar, Santhal Parganas, Jharkhand",coordinates:"24.4925° N, 86.7001° E",deityForm:"Kamada Linga (The Wish-Fulfilling Divine Healer)",riverOrSea:"Sultanganj Uttaravahini Ganga (Kanwar Route)",stotramVerse:"परल्यां वैद्यनाथं च डाकिन्यां भीमशङ्करम् ।",iconSvg:`<svg viewBox="0 0 100 100" class="gk-jyotir-icon-svg" aria-label="Baidyanath Temple with Gathbandhan Red Ribbon">
      <circle cx="50" cy="50" r="46" fill="#1f0a10" stroke="#f06292" stroke-width="2"/>
      <!-- Main Temple and Parvati Temple -->
      <polygon points="30,68 42,32 54,68" fill="#d81b60"/>
      <polygon points="56,68 66,40 76,68" fill="#ec407a"/>
      <!-- Red Holy Gathbandhan Streamer between tops -->
      <path d="M42 32 Q54 22 66 40" stroke="#ff1744" stroke-width="3" fill="none"/>
      <!-- Golden Pitcher -->
      <circle cx="42" cy="30" r="2.5" fill="#ffd700"/>
    </svg>`,whatVisitDoes:{parikaras:"Roga Nivarana (healing of incurable ailments, chronic paralysis, mental trauma, and physical debilities).",doshaNivarana:"Ayur Dosha (short life-span indicators), Maraka Graha afflictions, and psychological phobias.",spiritualUpliftment:"Awakening of inner cellular rejuvenation, pranic healing powers, and unconditional divine compassion."},specificPoojas:[{name:"Kanwar Jalabhisheka",timing:"Shravan Month (July–August)",details:"Millions of devotees walk 105 km barefoot carrying holy Ganga water in bamboo slings from Sultanganj to pour on the deity."},{name:"Sarkari Puja",timing:"04:00 AM",details:"Traditional state-sanctioned Vedic abhishekam performed first before general pilgrim entry."},{name:"Gathbandhan Ritual",timing:"Daily",details:"Tying a consecrated red cloth between the tops of Shiva's temple and Parvati's temple to bless couples with enduring marital harmony."}],history:{puranic:"Demon king Ravana meditated fiercely in the Himalayas to attain the supreme Atma Linga. To prove his devotion, he severed nine of his ten heads. As he raised the sword for the tenth, Shiva appeared, acted as a divine physician (Vaidya) by restoring his severed heads, and granted the Atma Linga on the condition that it never touch the ground before reaching Lanka.",local:"Lord Varuna entered Ravana's stomach as pure water, inducing an urgent urge. Lord Vishnu disguised as a cowherd (Baiju) offered to hold the linga, but placed it on the ground at Deoghar, where it anchored eternally into the subterranean realm.",folklore:"The temple complex houses 22 temples dedicated to various divinities; the presiding deity is called 'Kamada Linga'—one that fulfills every legitimate earthly and spiritual desire."}},{id:"nageshwar",name:"Nageshwar Mahadev",sanskritName:"नागेश्वर ज्योतिर्लिङ्ग",location:"Daarukavanam, Near Dwarka, Gujarat",coordinates:"22.3347° N, 69.0538° E",deityForm:"Nagesha (Protector from all Serpents & Poisons)",riverOrSea:"Arabian Sea Coast (Dwarka Peninsula)",stotramVerse:"हिमवन्ते तु केदारं घुश्मेशं च शिवालये ।",iconSvg:`<svg viewBox="0 0 100 100" class="gk-jyotir-icon-svg" aria-label="Nageshwar Coiled Serpent and Shiva Linga">
      <circle cx="50" cy="50" r="46" fill="#081c15" stroke="#2d6a4f" stroke-width="2"/>
      <!-- Giant Serpentine Hood (Sheshanaag) -->
      <path d="M50 18 Q32 26 38 48 Q50 40 62 48 Q68 26 50 18 Z" fill="#52b788"/>
      <!-- Linga -->
      <ellipse cx="50" cy="58" rx="10" ry="16" fill="#1b4332"/>
      <!-- Serpent Eyes -->
      <circle cx="45" cy="28" r="1.5" fill="#d8f3dc"/>
      <circle cx="55" cy="28" r="1.5" fill="#d8f3dc"/>
    </svg>`,whatVisitDoes:{parikaras:"Sarpa Dosha, Kaal Sarp Yoga, venomous ailments, fear of betrayals, poisoning, and psychic disturbances.",doshaNivarana:"Rahu-Ketu transit afflictions, unexplained phobias of reptiles, and skin ailments (Kushtha).",spiritualUpliftment:"Complete purification of the mind from mental toxins (Kam, Krodh, Lobh, Moha, Mada, Matsarya)."},specificPoojas:[{name:"Naga Pratima Daan & Abhishekam",timing:"06:00 AM – 11:30 AM",details:"Consecration and offering of silver five-hooded serpents alongside milk and sugarcane juice."},{name:"Pashupata Astra Stotra Archana",timing:"Daily",details:"Recitation of the invincible protective armor hymns of Lord Shiva."},{name:"Sandhya Dhyana Aarti",timing:"07:30 PM",details:"Evening light offering surrounded by the colossal 80-foot seated statue of Lord Shiva."}],history:{puranic:"Demon Daaruka and his wife Daaruki oppressed the virtuous hermits of Daarukavana forest, imprisoning an ardent Shiva devotee named Supriya. Supriya led prisoners in continuous chanting of Om Namah Shivaya. When the demon attacked Supriya, Shiva emerged from a luminous crevice, bestowed the Pashupata weapon, and established the Nageshwara shrine.",local:"Situated on the coastal road between Gomti Dwarka and Beyt Dwarka, ancient texts record this location as the ancient Daarukavanam forest.",folklore:"Saint Namdev visited the shrine to sing devotional bhajans. When orthodox temple priests chided him and forced him to sit at the rear of the sanctum, the entire stone temple is said to have miraculously rotated on its axis to face Namdev."}},{id:"ramanathaswamy",name:"Ramanathaswamy (Rameswaram)",sanskritName:"रामनाथस्वामी ज्योतिर्लिङ्ग",location:"Rameswaram Island, Ramanathapuram, Tamil Nadu",coordinates:"9.2881° N, 79.3174° E",deityForm:"Ramalingam (Sand Linga) & Vishwalingam (Hanuman Linga)",riverOrSea:"Agni Teertham (Bay of Bengal / Gulf of Mannar)",stotramVerse:"सेतुबन्धे तु रामेशं नागेशं दारुकावने ।",iconSvg:`<svg viewBox="0 0 100 100" class="gk-jyotir-icon-svg" aria-label="Ramanathaswamy Longest Corridor and Teerthams">
      <circle cx="50" cy="50" r="46" fill="#1b120c" stroke="#d4a373" stroke-width="2"/>
      <!-- Dravidian Raja Gopuram Outline -->
      <polygon points="35,70 42,20 58,20 65,70" fill="#a68a64"/>
      <!-- Tier horizontal lines -->
      <line x1="38" y1="35" x2="62" y2="35" stroke="#4a3b32" stroke-width="1.5"/>
      <line x1="36" y1="50" x2="64" y2="50" stroke="#4a3b32" stroke-width="1.5"/>
      <!-- Holy Water Drops (22 Teerthams) -->
      <circle cx="22" cy="78" r="3" fill="#00b4d8"/>
      <circle cx="50" cy="84" r="3" fill="#00b4d8"/>
      <circle cx="78" cy="78" r="3" fill="#00b4d8"/>
    </svg>`,whatVisitDoes:{parikaras:"Brahmahatya Dosha, Pitru Tarpana at Sethu Karai, marriage delays, childlessness, and resolving grave guilt from past transgressions.",doshaNivarana:"Crucial Shani Dosha, Sarpa Dosha, and karmic blocks in profession or lineage.",spiritualUpliftment:"Attaining the synthesis of Vaishnavism and Shaivism; understanding that Rama and Shiva dwell in each other's hearts."},specificPoojas:[{name:"22 Sacred Teertham Snanam",timing:"05:00 AM – 12:00 PM",details:"Bathing in the holy medicinal waters of all 22 freshwater wells located within the temple complex."},{name:"Spadika (Crystal) Linga Mani Darshan",timing:"05:00 AM – 06:00 AM",details:"Sacred darshan of the glowing clear crystal lingam illuminated with camphor before dawn."},{name:"Vishwalingam Prathama Puja",timing:"Daily",details:"Honoring Lord Rama's perpetual decree that the Kailash linga brought by Hanuman must always be worshipped before the Ramalingam."}],history:{puranic:"After vanquishing Ravana (a scholar of Vedic scriptures and grandson of Sage Pulastya), Sri Rama desired to expiate the sin of slaying a Brahmin (Brahmahatya). He dispatched Hanuman to Mount Kailash to bring an authentic linga. As the auspicious Muhurta drew near and Hanuman was delayed, Sita crafted a linga of sea sand (Ramalingam) and consecrated it.",local:"The temple boasts the longest temple corridor in the world (the Third Corridor), spanning 197 meters east-to-west and 133 meters north-to-south, supported by 1,212 granite monolithic pillars carved with remarkable precision.",folklore:"When Hanuman returned and was sorrowful that his linga was not used, Rama comforted him by establishing his Vishwalingam right beside Sita's lingam, commanding all pilgrims to worship Hanuman's linga first."}},{id:"grishneshwar",name:"Grishneshwar (Ghushmeshwar)",sanskritName:"घृष्णेश्वर ज्योतिर्लिङ्ग",location:"Verul (Near Ellora Caves), Chhatrapati Sambhajinagar, Maharashtra",coordinates:"20.0249° N, 75.1793° E",deityForm:"Ghushmeshwar Swayambhu Linga (South-Facing)",riverOrSea:"Shivalaya Sarovar",stotramVerse:"हिमवन्ते तु केदारं घुश्मेशं च शिवालये ।",iconSvg:`<svg viewBox="0 0 100 100" class="gk-jyotir-icon-svg" aria-label="Grishneshwar Red Basalt Shikhara">
      <circle cx="50" cy="50" r="46" fill="#1c0f0a" stroke="#d32f2f" stroke-width="2"/>
      <!-- Red Basalt Shikhara -->
      <polygon points="35,68 50,22 65,68" fill="#c62828"/>
      <polygon points="42,68 50,28 58,68" fill="#e53935"/>
      <!-- Shivalaya Sarovar Pond ripples -->
      <path d="M20 80 Q35 74 50 80 T80 80" stroke="#ff8a80" stroke-width="2" fill="none"/>
      <!-- Clay Linga Offering icon -->
      <circle cx="50" cy="74" r="3.5" fill="#ffebee"/>
    </svg>`,whatVisitDoes:{parikaras:"Santana Prapti (blessings of virtuous progeny), cure for persistent infertility, and resolving toxic marital or familial envy.",doshaNivarana:"Santana Dosha, Putra Dosha, Nazar (evil eye), and malicious jealousy from close relatives.",spiritualUpliftment:"Infuses the unshakeable faith (Shraddha) and magnanimity exemplified by Mother Ghushma."},specificPoojas:[{name:"Ghushma Sarovar Pradakshina",timing:"Early morning",details:"Circumambulating the sacred Shivalaya pond where Ghushma immersed 101 clay lingas daily."},{name:"Panchamrit Abhishek & Kumkum Archana",timing:"05:30 AM – 12:00 PM",details:"Sacred bathing and vermillion offerings to the southern-facing Swayambhu Jyotirlinga."},{name:"Shodashopachara Shringar Aarti",timing:"08:00 PM",details:"Nighttime 16-step offering with silver ornamentation and Bilva garlands."}],history:{puranic:"In the Shiva Purana, a devout woman named Ghushma worshipped Shiva with unblemished faith by creating and immersing 101 clay lingas daily in the local tank. Blessed with a virtuous son, her childless sister Sudeha killed the boy out of jealousy. Ghushma, unbroken in devotion, continued her worship. Pleased with her unshakeable surrender, Shiva resurrected her son and agreed to reside here eternally as Ghushmeshwar.",local:"Situated barely 1 km from the UNESCO World Heritage Ellora Caves (adjacent to the magnificent monolithic rock-cut Kailasa Temple Cave 16). Reconstructed by Queen Ahilyabai Holkar in the late 18th century using rich red basalt stone.",folklore:"Pilgrims believe that couples facing difficulties in bearing children who pray sincerely at Grishneshwar are blessed with devoted and noble offspring."}}],ja=[{id:"lion-and-hare",title:"The Lion and the Clever Hare",collection:"Panchatantra (Book 1: Mitra-bheda — The Loss of Friends)",author:"Pandit Vishnu Sharma (circa 300 BCE)",sanskritEpigraph:`बुद्धिर्यस्य बलं तस्य निर्बुद्धेस्तु कुतो बलम् ।
वने सिंहो मदोन्मत्तः शशकेन निपातितः ॥`,epigraphTranslation:"He who possesses intellect possesses true power; what strength does one without wisdom have? A mighty lion intoxicated with pride was slain in the forest by a humble hare.",summary:"Bhasuraka, a ferocious lion, slaughtered animals indiscriminately. The terrified animals agreed to send one prey daily. When it was the little hare's turn, he arrived late and claimed another lion had stopped him. Bhasuraka furiously demanded to see the rival. The hare led the lion to a deep well; seeing his own reflection and hearing his echo, the furious lion leaped in and perished.",vocabulary:[{term:"Bhasuraka (भासुरक)",meaning:"Shining or fierce; the name of the lion"},{term:"Yukti (युक्ति)",meaning:"Strategic resourcefulness; applying intellect over brute force"},{term:"Mada (मद)",meaning:"Blind arrogance, hubris arising from physical power"}],moral:"Wisdom and presence of mind conquer brute physical force. Arrogance clouds perception, making even the mighty destroy themselves.",quiz:{question:"In situations where you face an overwhelming challenge against which you have no physical leverage, what is the core Vedic strategic response?",options:["React in panic and despair","Use calm discernment (Buddhi), self-control, and the adversary's own arrogance against them","Surrender completely without thinking"],correctIndex:1,explanation:"Vedic statecraft (Niti Shastra) teaches that Buddhi (spiritual intellect) is superior to physical might (Bahu-bala). The hare did not fight the lion; he allowed the lion's own rage and illusion (Maya) to cause his downfall."}},{id:"monkey-and-crocodile",title:"The Monkey and the Crocodile",collection:"Panchatantra (Book 4: Labdhapranasham — Loss of Gains)",author:"Pandit Vishnu Sharma",sanskritEpigraph:`आपत्काले तु संप्राप्ते यस्य बुद्धिर्न हीयते ।
स एव तरते दुर्गाणि जलबद्ध इव प्लवः ॥`,epigraphTranslation:"When calamity strikes, he whose presence of mind does not waver crosses over treacherous perils, just like a sturdy raft upon tempestuous waters.",summary:"Raktamukha, a monkey living in a rose-apple tree by the river, befriended Karalamukha, a crocodile, sharing sweet fruits. The crocodile's greedy wife desired to eat the monkey's heart. Trapped mid-river on the crocodile's back, the monkey remained calm and claimed he had left his heart safe inside the hollow of the tree. The foolish crocodile swam back, allowing the monkey to leap to safety.",vocabulary:[{term:"Pratyutpannamati (प्रत्युत्पन्नमति)",meaning:"Instantaneous presence of mind during sudden peril"},{term:"Mitra-droha (मित्रद्रोह)",meaning:"Betrayal of trust between friends"}],moral:"Presence of mind in moments of mortal danger saves life. Betrayal destroys friendship forever.",quiz:{question:"What saved the monkey when trapped in the middle of the river?",options:["Physical fighting against the crocodile","Retaining composure and using swift psychological wit","Crying out for help to other animals"],correctIndex:1,explanation:"Panic paralyzes thinking. By remaining calm and fabricating a convincing story about leaving his heart on the tree, the monkey navigated a lethal situation peacefully."}},{id:"three-idols-tenali-raman",title:"Tenali Raman and the Three Idols",collection:"Tales of Tenali Ramakrishna",author:"Folkloric Heritage of Vijayanagara Empire",sanskritEpigraph:`श्रूयतां धर्मसर्वस्वं श्रुत्वा चैवावधार्यताम् ।
आत्मनः प्रतिकूलानि परेषां न समाचरेत् ॥`,epigraphTranslation:"Listen to the essence of Dharma, and having heard it, keep it firmly in your heart: That which is painful or detrimental to oneself, never inflict upon others.",summary:"A foreign scholar presented King Krishnadevaraya with three identical golden idols, challenging the court to determine which was superior. Tenali Raman inserted a thin straw into the ear of each idol. In the first, the straw emerged from the other ear (the person who hears and instantly forgets). In the second, the straw emerged from the mouth (the person who hears a secret and immediately gossips). In the third, the straw passed directly into the heart (the noble person who hears wisdom, reflects upon it, and preserves confidence). Raman declared the third idol the best.",vocabulary:[{term:"Shravana (श्रवण)",meaning:"The art of deep, attentive spiritual listening"},{term:"Manana (मनन)",meaning:"Internal reflection, assimilating knowledge into the heart"},{term:"Nididhyasana (निदिध्यासन)",meaning:"Living and manifesting truth in daily character"}],moral:"A person's true character is revealed by how they handle what they hear: whether they leak it, gossip, or assimilate it into noble conduct.",quiz:{question:"Which type of listener did the third golden idol represent?",options:["The gossip who repeats everything they hear","The person who absorbs wisdom deeply into their heart and preserves trust","The inattentive person who lets advice pass through one ear and out the other"],correctIndex:1,explanation:"True character (Sheela) lies in deep assimilation (Manana). Spiritual seekers must be like the third idol—absorbing truth into the heart rather than broadcasting idle speech."}},{id:"satyakama-jabala",title:"Satyakama Jabala and the Voice of Truth",collection:"Chandogya Upanishad (Chapter 4, Section 4)",author:"Ancient Vedic Sage Tradition",sanskritEpigraph:`सत्यमेव जयते नानृतं
सत्येन पन्था विततो देवयानः ।`,epigraphTranslation:"Truth alone triumphs, never falsehood. By truth is paved the divine pathway of spiritual liberation.",summary:"Young Satyakama wished to study Brahmavidya under Sage Gautama. When asked his lineage (gotra), his mother Jabala candidly told him she had served many masters in her youth and did not know his lineage. Satyakama truthfully repeated this to Gautama. Overjoyed by his uncompromising honesty, the sage declared: 'None but a true Brahmana could speak such unvarnished truth.' Gautama initiated him into the highest wisdom.",vocabulary:[{term:"Satya (सत्य)",meaning:"Unyielding adherence to truth in thought, word, and deed"},{term:"Brahmavidya (ब्रह्मविद्या)",meaning:"The supreme science of Ultimate Reality"},{term:"Acharya (आचार्य)",meaning:"A spiritual preceptor who teaches through their personal conduct"}],moral:"Truthfulness is the highest pedigree. Nobility of character outweighs social circumstance or birth.",quiz:{question:"Why did Sage Gautama accept Satyakama as his prime disciple?",options:["Because he was wealthy and powerful","Because he displayed absolute truthfulness and courage about his origins","Because he performed complex rituals"],correctIndex:1,explanation:"The Upanishads emphasize that true spiritual nobility is determined by Satya (Truth) and character, not by external privilege or birth status."}}];class Je{constructor(){this.bead=0,this.rounds=0,this.totalChants=0,this.dailyTargetRounds=16,this.meruReversalMode=!0,this.soundEnabled=!0,this.vibrationEnabled=!0,this.currentMantra="ॐ नमो भगवते वासुदेवाय (Om Namo Bhagavate Vasudevaya)",this.audioCtx=null,this.loadState()}initAudio(){if(!this.audioCtx&&typeof window<"u"){const a=window.AudioContext||window.webkitAudioContext;a&&(this.audioCtx=new a)}this.audioCtx&&this.audioCtx.state==="suspended"&&this.audioCtx.resume()}playBeadSound(){if(this.soundEnabled)try{if(this.initAudio(),!this.audioCtx)return;const a=this.audioCtx.createOscillator(),e=this.audioCtx.createGain();a.type="triangle",a.frequency.setValueAtTime(440,this.audioCtx.currentTime),a.frequency.exponentialRampToValueAtTime(110,this.audioCtx.currentTime+.04),e.gain.setValueAtTime(.2,this.audioCtx.currentTime),e.gain.exponentialRampToValueAtTime(.001,this.audioCtx.currentTime+.04),a.connect(e),e.connect(this.audioCtx.destination),a.start(),a.stop(this.audioCtx.currentTime+.04)}catch{}}playTempleBell(){if(this.soundEnabled)try{if(this.initAudio(),!this.audioCtx)return;const a=this.audioCtx.currentTime,e=[880,1760,2640,3520],i=[.35,.15,.08,.03];e.forEach((t,n)=>{const r=this.audioCtx.createOscillator(),l=this.audioCtx.createGain();r.type="sine",r.frequency.setValueAtTime(t,a),l.gain.setValueAtTime(i[n],a),l.gain.exponentialRampToValueAtTime(1e-4,a+1.8),r.connect(l),l.connect(this.audioCtx.destination),r.start(a),r.stop(a+1.8)})}catch{}}triggerHaptic(a=!1){if(!(!this.vibrationEnabled||typeof navigator>"u"||!navigator.vibrate))try{a?navigator.vibrate([70,50,140]):navigator.vibrate(28)}catch{}}increment(){this.initAudio(),this.bead+=1,this.totalChants+=1;let a=!1;return this.bead>=108?(this.bead=0,this.rounds+=1,a=!0,this.playTempleBell(),this.triggerHaptic(!0)):(this.playBeadSound(),this.triggerHaptic(!1)),this.saveState(),{bead:this.bead,rounds:this.rounds,totalChants:this.totalChants,reachedMeru:a}}resetCurrentMala(){this.bead=0,this.saveState()}resetAll(){this.bead=0,this.rounds=0,this.totalChants=0,this.saveState()}saveState(){try{if(typeof localStorage>"u")return;const a={bead:this.bead,rounds:this.rounds,totalChants:this.totalChants,dailyTargetRounds:this.dailyTargetRounds,meruReversalMode:this.meruReversalMode,soundEnabled:this.soundEnabled,vibrationEnabled:this.vibrationEnabled,currentMantra:this.currentMantra,lastUpdated:new Date().toISOString()};localStorage.setItem("gurukripa_japa_state",JSON.stringify(a))}catch{}}loadState(){try{if(typeof localStorage>"u")return;const a=localStorage.getItem("gurukripa_japa_state");if(a){const e=JSON.parse(a);this.bead=e.bead||0,this.rounds=e.rounds||0,this.totalChants=e.totalChants||0,this.dailyTargetRounds=e.dailyTargetRounds||16,e.meruReversalMode!==void 0&&(this.meruReversalMode=e.meruReversalMode),e.soundEnabled!==void 0&&(this.soundEnabled=e.soundEnabled),e.vibrationEnabled!==void 0&&(this.vibrationEnabled=e.vibrationEnabled),e.currentMantra&&(this.currentMantra=e.currentMantra)}}catch{}}exportDataJSON(){const a={app:"GuruKripa",type:"japa_sadhana_backup",version:"1.0.0",exportDate:new Date().toISOString(),stats:{bead:this.bead,rounds:this.rounds,totalChants:this.totalChants,dailyTargetRounds:this.dailyTargetRounds,currentMantra:this.currentMantra}};return JSON.stringify(a,null,2)}importDataJSON(a){try{const e=JSON.parse(a);if(e.stats)return this.bead=e.stats.bead||0,this.rounds=e.stats.rounds||0,this.totalChants=e.stats.totalChants||0,e.stats.dailyTargetRounds&&(this.dailyTargetRounds=e.stats.dailyTargetRounds),e.stats.currentMantra&&(this.currentMantra=e.stats.currentMantra),this.saveState(),!0}catch{return!1}return!1}}const C=["Mesha","Vrishabha","Mithuna","Karkataka","Simha","Kanya","Tula","Vrishchika","Dhanu","Makara","Kumbha","Meena"],qe=["♈","♉","♊","♋","♌","♍","♎","♏","♐","♑","♒","♓"],Ye={"Surya (Sun)":"Su","Chandra (Moon)":"Mo","Mangala (Mars)":"Ma","Budha (Mercury)":"Me","Brihaspati (Jupiter)":"Ju","Shukra (Venus)":"Ve","Shani (Saturn)":"Sa","Rahu (North Node)":"Ra","Ketu (South Node)":"Ke"};function Qe(o,a,e){const i={};for(let n=1;n<=12;n++)i[n]=[];const t=Math.max(1,Math.min(12,o||1));return i[t].push({name:"Lagna (Ascendant)",short:"Lg",isLagna:!0,deg:a?Math.floor(a%30):0}),Array.isArray(e)&&e.forEach(n=>{let r=n.rashiIndex;if(!r){const h=n.siderealLon!==void 0?n.siderealLon:n.longitude;typeof h=="number"&&!isNaN(h)&&(r=Math.floor(h/30)+1)}(!r||r<1||r>12)&&(r=1),i[r]||(i[r]=[]);const l=Ye[n.name]||n.name.substring(0,2),s=n.isRetrograde||n.status&&n.status.includes("Retrograde");i[r].push({name:n.name,short:s?`(${l})`:l,isRetrograde:s,deg:n.degrees!==void 0?n.degrees:n.deg!==void 0?n.deg:0})}),{lagnaRashi:t,signOccupants:i}}function Ze(o){const{lagnaRashi:a,signOccupants:e}=o,i={};for(let n=1;n<=12;n++)i[n]=(a-1+(n-1))%12+1;function t(n){const r=i[n];return(e[r]||[]).map(s=>s.short).join(" ")}return`<svg viewBox="0 0 400 400" class="gk-kundali-svg" aria-label="North Indian Kundli Chart">
    <rect x="2" y="2" width="396" height="396" fill="#180e22" stroke="#d4af37" stroke-width="2.5" rx="6"/>
    
    <!-- Outer Diagonals -->
    <line x1="2" y1="2" x2="398" y2="398" stroke="#d4af37" stroke-width="1.8" opacity="0.9"/>
    <line x1="398" y1="2" x2="2" y2="398" stroke="#d4af37" stroke-width="1.8" opacity="0.9"/>
    
    <!-- Inner Diamond -->
    <polygon points="200,2 398,200 200,398 2,200" fill="#241434" stroke="#d4af37" stroke-width="2" opacity="0.95"/>
    
    <!-- House Labels & Occupants -->
    <!-- House 1: Top Diamond -->
    <text x="200" y="70" class="gk-k-sign" text-anchor="middle">${i[1]}</text>
    <text x="200" y="125" class="gk-k-planets" text-anchor="middle">${t(1)}</text>
    <text x="200" y="145" class="gk-k-house-sub" text-anchor="middle">House 1 (Tanu)</text>

    <!-- House 2: Top Left Triangle -->
    <text x="125" y="45" class="gk-k-sign" text-anchor="middle">${i[2]}</text>
    <text x="100" y="75" class="gk-k-planets" text-anchor="middle">${t(2)}</text>

    <!-- House 3: Upper Left Corner Triangle -->
    <text x="45" y="125" class="gk-k-sign" text-anchor="middle">${i[3]}</text>
    <text x="65" y="100" class="gk-k-planets" text-anchor="middle">${t(3)}</text>

    <!-- House 4: Left Diamond -->
    <text x="70" y="200" class="gk-k-sign" text-anchor="middle">${i[4]}</text>
    <text x="125" y="205" class="gk-k-planets" text-anchor="middle">${t(4)}</text>
    <text x="125" y="222" class="gk-k-house-sub" text-anchor="middle">House 4 (Matru)</text>

    <!-- House 5: Lower Left Corner Triangle -->
    <text x="45" y="275" class="gk-k-sign" text-anchor="middle">${i[5]}</text>
    <text x="65" y="300" class="gk-k-planets" text-anchor="middle">${t(5)}</text>

    <!-- House 6: Bottom Left Triangle -->
    <text x="125" y="365" class="gk-k-sign" text-anchor="middle">${i[6]}</text>
    <text x="100" y="335" class="gk-k-planets" text-anchor="middle">${t(6)}</text>

    <!-- House 7: Bottom Diamond -->
    <text x="200" y="345" class="gk-k-sign" text-anchor="middle">${i[7]}</text>
    <text x="200" y="285" class="gk-k-planets" text-anchor="middle">${t(7)}</text>
    <text x="200" y="265" class="gk-k-house-sub" text-anchor="middle">House 7 (Kalatra)</text>

    <!-- House 8: Bottom Right Triangle -->
    <text x="275" y="365" class="gk-k-sign" text-anchor="middle">${i[8]}</text>
    <text x="300" y="335" class="gk-k-planets" text-anchor="middle">${t(8)}</text>

    <!-- House 9: Lower Right Corner Triangle -->
    <text x="355" y="275" class="gk-k-sign" text-anchor="middle">${i[9]}</text>
    <text x="335" y="300" class="gk-k-planets" text-anchor="middle">${t(9)}</text>

    <!-- House 10: Right Diamond -->
    <text x="330" y="200" class="gk-k-sign" text-anchor="middle">${i[10]}</text>
    <text x="275" y="205" class="gk-k-planets" text-anchor="middle">${t(10)}</text>
    <text x="275" y="222" class="gk-k-house-sub" text-anchor="middle">House 10 (Karma)</text>

    <!-- House 11: Upper Right Corner Triangle -->
    <text x="355" y="125" class="gk-k-sign" text-anchor="middle">${i[11]}</text>
    <text x="335" y="100" class="gk-k-planets" text-anchor="middle">${t(11)}</text>

    <!-- House 12: Top Right Triangle -->
    <text x="275" y="45" class="gk-k-sign" text-anchor="middle">${i[12]}</text>
    <text x="300" y="75" class="gk-k-planets" text-anchor="middle">${t(12)}</text>
    
    <!-- Central Title Badge -->
    <circle cx="200" cy="200" r="16" fill="#180e22" stroke="#d4af37" stroke-width="1.5"/>
    <text x="200" y="205" class="gk-k-center-om" text-anchor="middle">ॐ</text>
  </svg>`}function Xe(o){const{lagnaRashi:a,signOccupants:e}=o,i=[[12,1,2,3],[11,null,null,4],[10,null,null,5],[9,8,7,6]];let t="";for(let n=0;n<4;n++)for(let r=0;r<4;r++){const l=i[n][r],s=r*100,h=n*100;if(l===null)continue;const u=l===a,x=(e[l]||[]).map(y=>y.short).join(" ");t+=`
        <rect x="${s+2}" y="${h+2}" width="96" height="96" fill="${u?"#2a1435":"#180e22"}" stroke="#d4af37" stroke-width="1.2" rx="3"/>
        ${u?`<line x1="${s+2}" y1="${h+2}" x2="${s+98}" y2="${h+98}" stroke="#e53935" stroke-width="1.5" opacity="0.6"/>`:""}
        <text x="${s+8}" y="${h+18}" class="gk-k-sign-si">${C[l-1]} (${l})</text>
        <text x="${s+50}" y="${h+55}" class="gk-k-planets" text-anchor="middle">${x}</text>
      `}return`<svg viewBox="0 0 400 400" class="gk-kundali-svg" aria-label="South Indian Fixed-Sign Kundli Chart">
    <rect x="2" y="2" width="396" height="396" fill="#12081c" stroke="#d4af37" stroke-width="2.5" rx="6"/>
    
    <!-- Outer Grid Lines -->
    <line x1="100" y1="2" x2="100" y2="398" stroke="#d4af37" stroke-width="1.5"/>
    <line x1="200" y1="2" x2="200" y2="100" stroke="#d4af37" stroke-width="1.5"/>
    <line x1="200" y1="300" x2="200" y2="398" stroke="#d4af37" stroke-width="1.5"/>
    <line x1="300" y1="2" x2="300" y2="398" stroke="#d4af37" stroke-width="1.5"/>
    
    <line x1="2" y1="100" x2="398" y2="100" stroke="#d4af37" stroke-width="1.5"/>
    <line x1="2" y1="200" x2="100" y2="200" stroke="#d4af37" stroke-width="1.5"/>
    <line x1="300" y1="200" x2="398" y2="200" stroke="#d4af37" stroke-width="1.5"/>
    <line x1="2" y1="300" x2="398" y2="300" stroke="#d4af37" stroke-width="1.5"/>

    <!-- Individual Boxes -->
    ${t}

    <!-- Center Hollow Sacred Space -->
    <rect x="102" y="102" width="196" height="196" fill="#1e0f2b" stroke="#d4af37" stroke-width="1.5" rx="4"/>
    <text x="200" y="175" class="gk-k-center-om" text-anchor="middle" font-size="36">ॐ</text>
    <text x="200" y="215" class="gk-k-center-title" text-anchor="middle">RĀŚI KUNDALI</text>
    <text x="200" y="235" class="gk-k-house-sub" text-anchor="middle">South Indian (Dakshina) Style</text>
  </svg>`}function at(o){const{lagnaRashi:a,signOccupants:e}=o;function i(t){return(e[t]||[]).map(r=>r.short).join(" ")}return`<svg viewBox="0 0 400 400" class="gk-kundali-svg" aria-label="East Indian Kundli Chart">
    <rect x="2" y="2" width="396" height="396" fill="#180e22" stroke="#d4af37" stroke-width="2.5" rx="6"/>
    
    <!-- Outer Diagonals & Crosses -->
    <line x1="2" y1="2" x2="398" y2="398" stroke="#d4af37" stroke-width="1.8"/>
    <line x1="398" y1="2" x2="2" y2="398" stroke="#d4af37" stroke-width="1.8"/>
    
    <!-- Intermediate Diamond Lines -->
    <polygon points="200,2 398,200 200,398 2,200" fill="none" stroke="#d4af37" stroke-width="1.8"/>

    <!-- Sign Labels and Occupants (Fixed signs 1 to 12) -->
    <!-- Sign 1: Mesha (Top Left) -->
    <text x="80" y="65" class="gk-k-sign">${C[0]} (1)</text>
    <text x="80" y="85" class="gk-k-planets">${i(1)}</text>
    ${a===1?'<text x="80" y="105" class="gk-k-lagna-badge">Lagna</text>':""}

    <!-- Sign 2: Vrishabha (Top Center) -->
    <text x="200" y="65" class="gk-k-sign" text-anchor="middle">${C[1]} (2)</text>
    <text x="200" y="85" class="gk-k-planets" text-anchor="middle">${i(2)}</text>
    ${a===2?'<text x="200" y="105" class="gk-k-lagna-badge" text-anchor="middle">Lagna</text>':""}

    <!-- Sign 3: Mithuna (Top Right) -->
    <text x="320" y="65" class="gk-k-sign" text-anchor="end">${C[2]} (3)</text>
    <text x="320" y="85" class="gk-k-planets" text-anchor="end">${i(3)}</text>
    ${a===3?'<text x="320" y="105" class="gk-k-lagna-badge" text-anchor="end">Lagna</text>':""}

    <!-- Sign 4: Karkataka (Right Upper) -->
    <text x="365" y="145" class="gk-k-sign" text-anchor="end">${C[3]} (4)</text>
    <text x="365" y="165" class="gk-k-planets" text-anchor="end">${i(4)}</text>
    ${a===4?'<text x="365" y="185" class="gk-k-lagna-badge" text-anchor="end">Lagna</text>':""}

    <!-- Sign 5: Simha (Right Center) -->
    <text x="320" y="210" class="gk-k-sign" text-anchor="middle">${C[4]} (5)</text>
    <text x="320" y="230" class="gk-k-planets" text-anchor="middle">${i(5)}</text>
    ${a===5?'<text x="320" y="250" class="gk-k-lagna-badge" text-anchor="middle">Lagna</text>':""}

    <!-- Sign 6: Kanya (Right Lower) -->
    <text x="365" y="295" class="gk-k-sign" text-anchor="end">${C[5]} (6)</text>
    <text x="365" y="315" class="gk-k-planets" text-anchor="end">${i(6)}</text>
    ${a===6?'<text x="365" y="335" class="gk-k-lagna-badge" text-anchor="end">Lagna</text>':""}

    <!-- Sign 7: Tula (Bottom Right) -->
    <text x="320" y="365" class="gk-k-sign" text-anchor="end">${C[6]} (7)</text>
    <text x="320" y="340" class="gk-k-planets" text-anchor="end">${i(7)}</text>
    ${a===7?'<text x="320" y="320" class="gk-k-lagna-badge" text-anchor="end">Lagna</text>':""}

    <!-- Sign 8: Vrishchika (Bottom Center) -->
    <text x="200" y="365" class="gk-k-sign" text-anchor="middle">${C[7]} (8)</text>
    <text x="200" y="340" class="gk-k-planets" text-anchor="middle">${i(8)}</text>
    ${a===8?'<text x="200" y="320" class="gk-k-lagna-badge" text-anchor="middle">Lagna</text>':""}

    <!-- Sign 9: Dhanu (Bottom Left) -->
    <text x="80" y="365" class="gk-k-sign">${C[8]} (9)</text>
    <text x="80" y="340" class="gk-k-planets">${i(9)}</text>
    ${a===9?'<text x="80" y="320" class="gk-k-lagna-badge">Lagna</text>':""}

    <!-- Sign 10: Makara (Left Lower) -->
    <text x="35" y="295" class="gk-k-sign">${C[9]} (10)</text>
    <text x="35" y="315" class="gk-k-planets">${i(10)}</text>
    ${a===10?'<text x="35" y="335" class="gk-k-lagna-badge">Lagna</text>':""}

    <!-- Sign 11: Kumbha (Left Center) -->
    <text x="80" y="210" class="gk-k-sign" text-anchor="middle">${C[10]} (11)</text>
    <text x="80" y="230" class="gk-k-planets" text-anchor="middle">${i(11)}</text>
    ${a===11?'<text x="80" y="250" class="gk-k-lagna-badge" text-anchor="middle">Lagna</text>':""}

    <!-- Sign 12: Meena (Left Upper) -->
    <text x="35" y="145" class="gk-k-sign">${C[11]} (12)</text>
    <text x="35" y="165" class="gk-k-planets">${i(12)}</text>
    ${a===12?'<text x="35" y="185" class="gk-k-lagna-badge">Lagna</text>':""}

    <!-- Center Om and Badge -->
    <circle cx="200" cy="200" r="22" fill="#180e22" stroke="#d4af37" stroke-width="1.8"/>
    <text x="200" y="208" class="gk-k-center-om" text-anchor="middle">ॐ</text>
  </svg>`}function et(o){const{lagnaRashi:a,signOccupants:e}=o,i=200,t=200,n=190,r=135,l=65;let s="",h="",u="";for(let m=0;m<12;m++){const x=m+1,y=(180-m*30)*Math.PI/180,S=(180-(m+.5)*30)*Math.PI/180,A=i+n*Math.cos(y),P=t-n*Math.sin(y),I=i+r*Math.cos(y),L=t-r*Math.sin(y);s+=`<line x1="${I}" y1="${L}" x2="${A}" y2="${P}" stroke="#d4af37" stroke-width="1.2" opacity="0.8"/>`;const R=i+(r+28)*Math.cos(S),E=t-(r+28)*Math.sin(S);h+=`<text x="${R}" y="${E+5}" class="gk-k-glyph" text-anchor="middle">${qe[m]}</text>`;const B=e[x]||[];if(B.length>0){const j=i+(l+35)*Math.cos(S),d=t-(l+35)*Math.sin(S),k=B.map(M=>M.short).join(" ");u+=`<text x="${j}" y="${d+4}" class="gk-k-planets-circ" text-anchor="middle">${k}</text>`}}return`<svg viewBox="0 0 400 400" class="gk-kundali-svg" aria-label="West Indian Circular Zodiac Kundli Wheel">
    <rect x="2" y="2" width="396" height="396" fill="#12081c" stroke="#d4af37" stroke-width="2.5" rx="6"/>
    
    <!-- Concentric Rings -->
    <circle cx="${i}" cy="${t}" r="${n}" fill="#1a0c28" stroke="#d4af37" stroke-width="2"/>
    <circle cx="${i}" cy="${t}" r="${r}" fill="#241434" stroke="#d4af37" stroke-width="1.5"/>
    <circle cx="${i}" cy="${t}" r="${l}" fill="#12081c" stroke="#d4af37" stroke-width="2"/>
    
    <!-- Radial Sectors -->
    ${s}
    ${h}
    ${u}

    <!-- Center Om & Lagna Indicator -->
    <circle cx="${i}" cy="${t}" r="22" fill="#180e22" stroke="#d4af37" stroke-width="1.5"/>
    <text x="${i}" y="${t+7}" class="gk-k-center-om" text-anchor="middle">ॐ</text>
    <text x="${i}" y="${t-35}" class="gk-k-house-sub" text-anchor="middle">Lagna: ${C[a-1]}</text>
  </svg>`}class tt{constructor(){this.cities=Be,this.selectedCity=this.loadSavedCity()||this.cities[0],this.selectedDate=new Date,this.selectedLang=localStorage.getItem("gk_lang")||"sa",this.currentView=this.getViewFromHash(),this.panchangTab="overview",this.chartStyle="north",this.slokaFontSize=1.35,this.showSabdartha=!0,this.cityModalOpen=!1,this.theme=localStorage.getItem("gk_theme")||"light",this.japaEngine=new Je,this.selectedDeity="all",this.selectedCategory="all",this.playingSlokaId=null,this.chantSpeed=1,this.audioCtx=null,this.audioTimer=null,this.activeCardSloka=null,this.cardTheme="saffron",this.init()}loadSavedCity(){try{const a=localStorage.getItem("gk_selected_city");return a?JSON.parse(a):null}catch{return null}}saveCity(a){this.selectedCity=a;try{localStorage.setItem("gk_selected_city",JSON.stringify(a))}catch{}}getViewFromHash(){const a=window.location.hash.replace("#","").split("?")[0];return["panchang","jyotirlingas","stotras","japa","stories"].includes(a)?a:"panchang"}init(){document.documentElement.setAttribute("data-theme",this.theme),document.documentElement.setAttribute("data-lang",this.selectedLang),window.addEventListener("hashchange",()=>{this.currentView=this.getViewFromHash(),this.render()}),window.addEventListener("keydown",a=>{this.currentView==="japa"&&(a.code==="Space"||a.code==="Enter")&&(a.preventDefault(),this.handleJapaClick())}),"serviceWorker"in navigator&&window.addEventListener("load",()=>{navigator.serviceWorker.register("/sw.js").catch(()=>{})}),this.render()}toggleTheme(){this.theme=this.theme==="light"?"dark":"light",localStorage.setItem("gk_theme",this.theme),document.documentElement.setAttribute("data-theme",this.theme),this.render()}handleJapaClick(){const a=this.japaEngine.increment(),e=document.getElementById("gk-bead-number"),i=document.getElementById("gk-stat-rounds"),t=document.getElementById("gk-stat-total");e&&(e.innerText=a.bead),i&&(i.innerText=a.rounds),t&&(t.innerText=a.totalChants),a.reachedMeru&&this.japaEngine.meruReversalMode&&alert(`✨ Haribol! You have reached the sacred Sumeru (Meru) bead.
In traditional practice, do not cross the Guru bead; turn your mala around for the next round.`)}autoDetectLocation(){if(!navigator.geolocation){alert("Geolocation is not supported by your browser. Please select a city manually.");return}navigator.geolocation.getCurrentPosition(a=>{const e=a.coords.latitude,i=a.coords.longitude,t=-new Date().getTimezoneOffset()/60,n={id:"gps-current",name:"Current GPS Location",state:"Local",country:"Live Coordinates",lat:parseFloat(e.toFixed(4)),lon:parseFloat(i.toFixed(4)),tz:Intl.DateTimeFormat().resolvedOptions().timeZone||"UTC",tz_offset:t,elevation_m:50};this.saveCity(n),this.cityModalOpen=!1,this.render()},a=>{alert("GPS detection failed: "+a.message+". Please choose your city from the global directory.")},{timeout:1e4,enableHighAccuracy:!0})}playChantSound(a){if(this.playingSlokaId===a){this.stopChantSound();return}this.stopChantSound();let e=oa.find(n=>n.id===a);if(e||(e=Ra.find(n=>n.id===a)),!e)return;this.playingSlokaId=a,this.render();const t=(e.devanagari||e.stotramVerse||e.sanskritName||"").replace(/[॥।\r\n]+/g," ").replace(/\s+/g," ").trim();if("speechSynthesis"in window&&t)try{window.speechSynthesis.cancel();const n=new SpeechSynthesisUtterance(t);n.lang="hi-IN",n.rate=.82*this.chantSpeed,n.pitch=.95;const l=window.speechSynthesis.getVoices().find(s=>s.lang&&(s.lang.startsWith("hi")||s.lang.startsWith("sa")||s.lang.includes("IN"))||s.name&&(s.name.includes("Hindi")||s.name.includes("India")||s.name.includes("Kalpana")||s.name.includes("Lekha")));l&&(n.voice=l),n.onend=()=>{this.stopChantSound()},n.onerror=()=>{this.stopChantSound()},this.currentUtterance=n,window.speechSynthesis.speak(n)}catch(n){console.warn("Speech synthesis notice:",n)}try{const n=window.AudioContext||window.webkitAudioContext;if(n){this.audioCtx=new n;const r=this.audioCtx.createGain();r.gain.setValueAtTime(.01,this.audioCtx.currentTime),r.gain.exponentialRampToValueAtTime(.08,this.audioCtx.currentTime+1);const l=[136.1,204.15,272.2];this.droneOscillators=l.map((s,h)=>{const u=this.audioCtx.createOscillator(),m=this.audioCtx.createGain();return u.type=h===0?"sine":"triangle",u.frequency.setValueAtTime(s,this.audioCtx.currentTime),m.gain.setValueAtTime(1/(h+1),this.audioCtx.currentTime),u.connect(m),m.connect(r),u.start(),u}),r.connect(this.audioCtx.destination),this.droneGain=r}}catch(n){console.warn("Chant audio drone notice:",n)}}stopChantSound(){if("speechSynthesis"in window)try{window.speechSynthesis.cancel()}catch{}if(this.currentUtterance=null,this.audioCtx)try{this.droneGain&&this.droneGain.gain.exponentialRampToValueAtTime(1e-4,this.audioCtx.currentTime+.3),setTimeout(()=>{this.droneOscillators&&(this.droneOscillators.forEach(a=>{try{a.stop()}catch{}}),this.droneOscillators=null),this.audioCtx&&(this.audioCtx.close().catch(()=>{}),this.audioCtx=null)},350)}catch{this.audioCtx=null}this.playingSlokaId=null,document.querySelectorAll(".gk-audio-play-btn").forEach(a=>{a.innerHTML="▶"})}openCardMaker(a){const e=oa.find(i=>i.id===a);e&&(this.activeCardSloka=e,this.render(),setTimeout(()=>this.drawShareCanvas(),50))}closeCardMaker(){this.activeCardSloka=null,this.render()}drawShareCanvas(){const a=document.getElementById("gk-share-canvas");if(!a||!this.activeCardSloka)return;const e=a.getContext("2d"),i=this.activeCardSloka;a.width=1080,a.height=1920;const t=e.createLinearGradient(0,0,1080,1920);this.cardTheme==="saffron"?(t.addColorStop(0,"#FF8F00"),t.addColorStop(.5,"#E65100"),t.addColorStop(1,"#6A0D18")):this.cardTheme==="maroon"?(t.addColorStop(0,"#4A0E17"),t.addColorStop(.5,"#800020"),t.addColorStop(1,"#250409")):this.cardTheme==="sandal"?(t.addColorStop(0,"#C5A059"),t.addColorStop(.6,"#8A6828"),t.addColorStop(1,"#3D2D10")):(t.addColorStop(0,"#0A192F"),t.addColorStop(.5,"#1E3A8A"),t.addColorStop(1,"#1A0B2E")),e.fillStyle=t,e.fillRect(0,0,1080,1920),e.strokeStyle="#D4AF37",e.lineWidth=14,e.strokeRect(40,40,1e3,1840),e.lineWidth=4,e.strokeRect(60,60,960,1800),e.fillStyle="rgba(255, 255, 255, 0.06)",e.font='bold 360px "Noto Serif Devanagari", serif',e.textAlign="center",e.fillText("ॐ",540,1050),e.fillStyle="#FFE082",e.font='700 42px "Cinzel", Georgia, serif',e.fillText("G U R U K R I P A",540,150),e.font="400 28px sans-serif",e.fillStyle="rgba(255, 255, 255, 0.8)",e.fillText("Sacred Daily Sanatana Dharma Wisdom",540,195),e.fillStyle="#FFFFFF",e.font='bold 52px "Cinzel", Georgia, serif',e.fillText(i.deity,540,310),e.fillStyle="#FFE082",e.font='600 36px "Cinzel", Georgia, serif',e.fillText(i.title,540,370);const n=p(i.devanagari,this.selectedLang).split(`
`);e.fillStyle="#FFFFFF",e.font='600 48px "Noto Serif Devanagari", "Noto Sans Tamil", "Noto Sans Telugu", serif';let r=560;for(const u of n)e.fillText(u,540,r),r+=85;e.fillStyle="#FFE0B2",e.font="italic 34px Georgia, serif",r+=40;const l=i.iast.split(`
`);for(const u of l)e.fillText(u,540,r),r+=56;r+=40,e.strokeStyle="rgba(212, 175, 55, 0.5)",e.beginPath(),e.moveTo(200,r),e.lineTo(880,r),e.stroke(),r+=80,e.fillStyle="rgba(255, 255, 255, 0.95)",e.font='400 32px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';const s=i.translation.split(" ");let h="";for(const u of s){const m=h?h+" "+u:u;e.measureText(m).width>860?(e.fillText(h,540,r),r+=52,h=u):h=m}h&&e.fillText(h,540,r),e.fillStyle="#FFE082",e.font='600 28px "Cinzel", Georgia, serif',e.fillText("gurukripa.pages.dev • 100% Client-Side Vedic Wisdom",540,1800)}downloadCardImage(){const a=document.getElementById("gk-share-canvas");if(!a||!this.activeCardSloka)return;const e=a.toDataURL("image/png"),i=document.createElement("a");i.href=e,i.download=`GuruKripa_${this.activeCardSloka.id}_${this.cardTheme}.png`,i.click()}shareCardToWhatsApp(){if(!document.getElementById("gk-share-canvas")||!this.activeCardSloka)return;const e=this.activeCardSloka,i=encodeURIComponent(`🕉️ *${e.title}* (${e.deity})

"${p(e.devanagari,this.selectedLang)}"

*Meaning:* ${e.translation}

Chant daily on GuruKripa: https://gurukripa.pages.dev/#stotras`);window.open(`https://api.whatsapp.com/send?text=${i}`,"_blank")}render(){const a=document.getElementById("app");a&&(a.innerHTML=`
      ${this.renderHeader()}
      <main class="gk-main">
        ${this.renderNavSubbar()}
        ${this.renderView()}
      </main>
      ${this.renderFooter()}
      ${this.cityModalOpen?this.renderCityModal():""}
      ${this.activeCardSloka?this.renderCardMakerModal():""}
      ${this.renderConsentBanner()}
    `,this.bindEvents())}renderHeader(){return`
      <header class="gk-header">
        <div class="gk-header-inner">
          <a href="#panchang" class="gk-brand">
            <span class="gk-brand-logo">🕉️</span>
            <div>
              <span class="gk-brand-title">GuruKripa</span>
              <span class="gk-brand-tagline">Global Vedic Panchang & Hindu Spiritual Portal</span>
            </div>
          </a>

          <div class="gk-header-controls">
            <!-- Language Switcher (11 Scripts) -->
            <select id="gk-lang-select" class="gk-select" title="Switch Script">
              ${Oe.map(a=>`
                <option value="${a.code}" ${a.code===this.selectedLang?"selected":""}>
                  ${a.native} (${a.name})
                </option>
              `).join("")}
            </select>

            <!-- City / Geo Location Button -->
            <button id="gk-city-btn" class="gk-btn" title="Change Location">
              📍 ${this.selectedCity.name}
            </button>

            <!-- Auto GPS Button -->
            <button id="gk-gps-btn" class="gk-btn" title="Auto-Detect My GPS Location">
              🎯 GPS
            </button>

            <!-- Theme Toggle -->
            <button id="gk-theme-btn" class="gk-btn" title="Toggle Light/Dark Theme">
              ${this.theme==="light"?"🌙 Dark":"☀️ Light"}
            </button>
          </div>
        </div>
      </header>
    `}renderNavSubbar(){return`
      <nav class="gk-nav-subbar">
        <div class="gk-nav-subbar-inner">
          <ul class="gk-nav-links">
            <li><a href="#panchang" class="${this.currentView==="panchang"?"active":""}">Panchangam</a></li>
            <li><a href="#jyotirlingas" class="${this.currentView==="jyotirlingas"?"active":""}">12 Jyotirlingas</a></li>
            <li><a href="#stotras" class="${this.currentView==="stotras"?"active":""}">Stotras & 12 Deities</a></li>
            <li><a href="#japa" class="${this.currentView==="japa"?"active":""}">108 Japa Mala</a></li>
            <li><a href="#stories" class="${this.currentView==="stories"?"active":""}">Dharmic Stories</a></li>
          </ul>

          <div class="gk-location-pill">
            <span>Lat: ${this.selectedCity.lat.toFixed(2)}°, Lon: ${this.selectedCity.lon.toFixed(2)}° (${this.selectedCity.tz})</span>
          </div>
        </div>
      </nav>
    `}renderView(){switch(this.currentView){case"panchang":return this.renderPanchang();case"jyotirlingas":return this.renderJyotirlingas();case"stotras":return this.renderStotras();case"japa":return this.renderJapa();case"stories":return this.renderStories();default:return this.renderPanchang()}}renderPanchang(){const a=He(this.selectedDate,this.selectedCity);return`
      <section>
        <!-- Traditional Vedic Almanac Header -->
        <div class="gk-almanac-header">
          <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
            <div>
              <div class="gk-almanac-title">
                ${p("दैनिक पञ्चाङ्गम्",this.selectedLang)} — ${a.date}
              </div>
              <div style="font-size:0.85rem; color:#FFE0B2;">
                📍 ${this.selectedCity.name}, ${this.selectedCity.country} • Lahiri Ayanamsa: ${a.ayanamsa&&a.ayanamsa.formatted?a.ayanamsa.formatted:a.ayanamsa&&a.ayanamsa.degrees!==void 0?`${a.ayanamsa.degrees}° ${a.ayanamsa.minutes}'`:a.ayanamsa}
              </div>
            </div>
            <div>
              <input type="date" id="gk-date-picker" class="gk-select" value="${a.date}" style="background:#FFF; color:#222; font-weight:700;">
            </div>
          </div>

          <div class="gk-samvat-grid">
            <div class="gk-samvat-item">
              Samvatsara
              <strong>Krodhi (क्रोधी)</strong>
            </div>
            <div class="gk-samvat-item">
              Ayana
              <strong>Dakshinayana (दक्षिणायन)</strong>
            </div>
            <div class="gk-samvat-item">
              Ritu
              <strong>Hemanta (हेमन्त ऋतु)</strong>
            </div>
            <div class="gk-samvat-item">
              Vedic Vaara
              <strong>${p(a.vaar.sanskrit,this.selectedLang)}</strong>
            </div>
          </div>
        </div>

        <div class="gk-tabs">
          <button class="gk-tab-btn ${this.panchangTab==="overview"?"active":""}" data-tab="overview">5 Daily Limbs</button>
          <button class="gk-tab-btn ${this.panchangTab==="kundali"?"active":""}" data-tab="kundali">Rāśi Kundali (Chart of the Day)</button>
          <button class="gk-tab-btn ${this.panchangTab==="gowri"?"active":""}" data-tab="gowri">Gowri Panchangam</button>
          <button class="gk-tab-btn ${this.panchangTab==="choghadiya"?"active":""}" data-tab="choghadiya">Choghadiya Muhurtas</button>
          <button class="gk-tab-btn ${this.panchangTab==="planets"?"active":""}" data-tab="planets">Planetary Longitudes</button>
        </div>

        ${this.panchangTab==="overview"?this.renderPanchangOverview(a):""}
        ${this.panchangTab==="kundali"?this.renderPanchangKundali(a):""}
        ${this.panchangTab==="gowri"?this.renderGowriTable(a.gowriPanchangam):""}
        ${this.panchangTab==="choghadiya"?this.renderChoghadiyaTable(a.choghadiya):""}
        ${this.panchangTab==="planets"?this.renderPlanetsTable(a.planets,a.ayanamsa):""}

        ${this.renderAdSlot("ad-panchang-inline","rectangle")}
      </section>
    `}renderPanchangKundali(a){const e=Qe(a.lagna.rashiIndex,a.lagna.deg,a.planets);let i="";return this.chartStyle==="south"?i=Xe(e):this.chartStyle==="east"?i=at(e):this.chartStyle==="west"?i=et(e):i=Ze(e),`
      <div class="gk-card" style="margin-top:16px;">
        <div class="gk-chart-controls">
          <div>
            <h3 style="color:var(--color-primary); margin:0 0 4px 0; font-size:1.2rem;">
              Vedic Rāśi Kundali (Chart of the Day)
            </h3>
            <p style="font-size:0.85rem; color:var(--color-text-muted); margin:0;">
              Calculated for ${this.selectedCity.name} (${a.coordinates}) using Lahiri Ayanamsa (${a.ayanamsa.formatted||a.ayanamsa})
            </p>
          </div>
          <div style="display:flex; align-items:center; gap:8px;">
            <label for="gk-chart-style-select" style="font-size:0.85rem; font-weight:700; color:var(--color-secondary);">Chart Style:</label>
            <select id="gk-chart-style-select" class="gk-chart-select">
              <option value="north" ${this.chartStyle==="north"?"selected":""}>North Indian (Parashara Diamond) [Default]</option>
              <option value="south" ${this.chartStyle==="south"?"selected":""}>South Indian (Fixed-Sign Grid)</option>
              <option value="east" ${this.chartStyle==="east"?"selected":""}>East Indian (Bengali / Surya)</option>
              <option value="west" ${this.chartStyle==="west"?"selected":""}>West Indian (Circular Wheel / Western)</option>
            </select>
          </div>
        </div>

        <div class="gk-kundali-wrapper">
          <div class="gk-kundali-chart-box">
            ${i}
            <div style="font-size:0.82rem; color:var(--color-text); margin-top:14px; text-align:center; line-height:1.4;">
              Ascendant (Lagna): <strong style="color:var(--color-primary);">${a.lagna.rashi} (${a.lagna.rashiEnglish}) ${a.lagna.deg}° ${a.lagna.min}'</strong><br>
              <span style="font-size:0.76rem; color:var(--color-text-muted);">Nakshatra: ${a.lagna.nakshatra} (Pada ${a.lagna.pada})</span>
            </div>
          </div>

          <div class="gk-kundali-details-box">
            <h4 style="color:var(--color-primary); margin-top:0; margin-bottom:12px; border-bottom:1px solid var(--color-border); padding-bottom:6px;">
              Planetary Occupation of Houses (Bhava Sthiti)
            </h4>
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(210px, 1fr)); gap:10px;">
              ${a.planets.map(t=>`
                <div style="background:var(--color-background); border:1px solid var(--color-border); border-radius:6px; padding:8px 12px; font-size:0.85rem;">
                  <div style="font-weight:700; color:var(--color-primary); display:flex; justify-content:space-between;">
                    <span>${t.name.split(" ")[0]} (${t.sanskrit})</span>
                    <span style="color:var(--color-secondary); font-size:0.75rem;">${t.status}</span>
                  </div>
                  <div style="color:var(--color-text-muted); font-size:0.8rem; margin-top:2px;">
                    ${t.rashi} (${t.rashiEnglish}) • ${t.degInRashi}
                  </div>
                  <div style="font-size:0.75rem; color:var(--color-accent); margin-top:2px;">
                    ${t.nakshatra} (Pada ${t.pada})
                  </div>
                </div>
              `).join("")}
            </div>

            <div style="margin-top:18px; padding:12px; background:rgba(212,175,55,0.08); border-left:3px solid var(--color-accent); border-radius:0 6px 6px 0; font-size:0.82rem; line-height:1.45;">
              <strong style="color:var(--color-primary);">Astrological Reading Guidance:</strong>
              Planets marked in parentheses (e.g. <em>(Ra), (Ke)</em>) are in retrograde (Vakra) motion. The Ascendant (Lagna) anchors House 1 in the North Indian chart, while in South Indian charts it is indicated by an oblique stroke.
            </div>
          </div>
        </div>
      </div>
    `}renderPanchangOverview(a){const e=a.calendar||{};return`
      <div class="gk-panchang-hero">
        <div class="gk-card">
          <div class="gk-card-title"><span>Sunrise / Sunset</span><span>☀️</span></div>
          <div class="gk-card-value">${a.sunrise} — ${a.sunset}</div>
          <div class="gk-card-meta">Solar Noon: ${a.solarNoon} (Day Duration: ${a.dayDuration})</div>
          <div style="font-size:0.76rem; color:var(--color-secondary); margin-top:4px;">
            🌙 Moonrise: ${a.moonrise||"N/A"} • Moonset: ${a.moonset||"N/A"}
          </div>
        </div>
        <div class="gk-card">
          <div class="gk-card-title"><span>Tithi (Lunar Day)</span><span>🌙</span></div>
          <div class="gk-card-value">${p(a.tithi.name,this.selectedLang)}</div>
          <div class="gk-card-meta">Paksha: ${a.tithi.paksha} • Progress: ${a.tithi.progress}% • Deity: ${a.tithi.deity}</div>
          <div style="font-size:0.76rem; color:var(--color-text-muted); margin-top:4px;">
            Ends at: ${a.tithiEndTime||"N/A"}
          </div>
        </div>
        <div class="gk-card">
          <div class="gk-card-title"><span>Nakshatra (Lunar Mansion)</span><span>✨</span></div>
          <div class="gk-card-value">${p(a.nakshatra.name,this.selectedLang)} (Pada ${a.nakshatra.pada})</div>
          <div class="gk-card-meta">Lord: ${a.nakshatra.lord} • Deity: ${a.nakshatra.deity}</div>
          <div style="font-size:0.76rem; color:var(--color-text-muted); margin-top:4px;">
            Ends at: ${a.nakshatraEndTime||"N/A"}
          </div>
        </div>
        <div class="gk-card">
          <div class="gk-card-title"><span>Yoga & Karana</span><span>🌀</span></div>
          <div class="gk-card-value">${p(a.yoga,this.selectedLang)} / ${p(a.karana,this.selectedLang)}</div>
          <div class="gk-card-meta">Vaar: ${p(a.vaar.sanskrit,this.selectedLang)} (${a.vaar.english} - Lord: ${a.vaar.lord})</div>
          <div style="font-size:0.76rem; color:var(--color-text-muted); margin-top:4px;">
            Lagna: ${a.lagna?`${a.lagna.rashi} (${a.lagna.deg}°)`:"Calculated"}
          </div>
        </div>
        <div class="gk-card">
          <div class="gk-card-title"><span>Sun & Moon Rashi</span><span>♈</span></div>
          <div class="gk-card-value">${p(a.moonRashi,this.selectedLang)}</div>
          <div class="gk-card-meta">Sun: ${p(a.sunRashi,this.selectedLang)} (Chitrapaksha Lahiri Ayanamsa)</div>
          <div style="font-size:0.76rem; color:var(--color-text-muted); margin-top:4px;">
            Ayana: ${e.ayana||"Uttarayana"} • Ritu: ${e.ritu||"Sharad"}
          </div>
        </div>
        <div class="gk-card">
          <div class="gk-card-title"><span>Auspicious Windows</span><span>🌟</span></div>
          <div class="gk-card-value" style="font-size:1rem; color:var(--color-good);">
            Abhijit: ${a.muhurtas.abhijitMuhurta}
          </div>
          <div class="gk-card-meta">Brahma Muhurta: ${a.muhurtas.brahmaMuhurta}</div>
          <div style="font-size:0.76rem; color:var(--color-good); margin-top:4px;">
            Amrit Kaal: ${a.muhurtas.amritKaal||"N/A"}
          </div>
        </div>
      </div>

      <!-- Drik Panchang Comprehensive Muhurta & Kaalam Schedule -->
      <div class="gk-card" style="margin-top:20px;">
        <h3 style="color:var(--color-primary); margin-bottom:12px; font-size:1.15rem;">
          Drik Panchang Muhurta & Kaalam Schedule (${this.selectedCity.name})
        </h3>
        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(220px, 1fr)); gap:16px;">
          <div style="background:rgba(198,40,40,0.06); padding:12px; border-radius:6px; border-left:4px solid var(--color-inauspicious);">
            <div style="font-weight:700; color:var(--color-inauspicious); font-size:0.9rem;">
              ⚠️ Rahu Kalam (Inauspicious)
            </div>
            <div style="font-size:1.1rem; font-weight:700; margin:4px 0;">${a.muhurtas.rahuKalam}</div>
            <div style="font-size:0.75rem; color:var(--color-text-muted);">Avoid initiating travel or signing contracts</div>
          </div>

          <div style="background:rgba(230,81,0,0.06); padding:12px; border-radius:6px; border-left:4px solid var(--color-secondary);">
            <div style="font-weight:700; color:var(--color-secondary); font-size:0.9rem;">
              ⏳ Yamaganda Kalam
            </div>
            <div style="font-size:1.1rem; font-weight:700; margin:4px 0;">${a.muhurtas.yamagandam||a.muhurtas.yamaganda}</div>
            <div style="font-size:0.75rem; color:var(--color-text-muted);">Ruled by Yama; unsuitable for new investments</div>
          </div>

          <div style="background:rgba(212,175,55,0.08); padding:12px; border-radius:6px; border-left:4px solid var(--color-accent);">
            <div style="font-weight:700; color:var(--color-gold-dark); font-size:0.9rem;">
              ⏱️ Gulika Kalam
            </div>
            <div style="font-size:1.1rem; font-weight:700; margin:4px 0;">${a.muhurtas.gulikaKalam}</div>
            <div style="font-size:0.75rem; color:var(--color-text-muted);">Ruled by Saturn; deeds performed here repeat</div>
          </div>

          <div style="background:rgba(46,125,50,0.06); padding:12px; border-radius:6px; border-left:4px solid var(--color-good);">
            <div style="font-weight:700; color:var(--color-good); font-size:0.9rem;">
              ✨ Abhijit Muhurta (Most Auspicious)
            </div>
            <div style="font-size:1.1rem; font-weight:700; margin:4px 0;">${a.muhurtas.abhijitMuhurta}</div>
            <div style="font-size:0.75rem; color:var(--color-text-muted);">Midday victory window; destroys all doshas</div>
          </div>

          <div style="background:rgba(76,175,80,0.06); padding:12px; border-radius:6px; border-left:4px solid #66bb6a;">
            <div style="font-weight:700; color:#2e7d32; font-size:0.9rem;">
              🍯 Amrit Kaal (Nectar Window)
            </div>
            <div style="font-size:1.1rem; font-weight:700; margin:4px 0;">${a.muhurtas.amritKaal||"N/A"}</div>
            <div style="font-size:0.75rem; color:var(--color-text-muted);">Ideal for spiritual initiation, medicine, ceremonies</div>
          </div>

          <div style="background:rgba(142,36,170,0.06); padding:12px; border-radius:6px; border-left:4px solid #ab47bc;">
            <div style="font-weight:700; color:#7b1fa2; font-size:0.9rem;">
              🏹 Vijaya Muhurta
            </div>
            <div style="font-size:1.1rem; font-weight:700; margin:4px 0;">${a.muhurtas.vijayaMuhurta||"N/A"}</div>
            <div style="font-size:0.75rem; color:var(--color-text-muted);">Window of conquest, endeavors, and ventures</div>
          </div>

          <div style="background:rgba(255,160,0,0.06); padding:12px; border-radius:6px; border-left:4px solid #ffb300;">
            <div style="font-weight:700; color:#f57c00; font-size:0.9rem;">
              🌅 Godhuli Muhurta
            </div>
            <div style="font-size:1.1rem; font-weight:700; margin:4px 0;">${a.muhurtas.godhuliMuhurta||"N/A"}</div>
            <div style="font-size:0.75rem; color:var(--color-text-muted);">Twilight window of peace and home worship</div>
          </div>

          <div style="background:rgba(183,28,28,0.06); padding:12px; border-radius:6px; border-left:4px solid #d32f2f;">
            <div style="font-weight:700; color:#c62828; font-size:0.9rem;">
              ⛔ Dur Muhurtam & Varjyam
            </div>
            <div style="font-size:0.95rem; font-weight:700; margin:4px 0;">Dur: ${a.muhurtas.durMuhurtam||"N/A"}</div>
            <div style="font-size:0.8rem; color:var(--color-text-muted);">Varjyam: ${a.muhurtas.varjyam||"N/A"}</div>
          </div>
        </div>

        <!-- Disha Shool & Travel Guidance -->
        <div style="margin-top:16px; padding:12px 16px; background:rgba(230,81,0,0.06); border-radius:6px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
          <div>
            <strong style="color:var(--color-secondary);">🧭 Disha Shool (Travel Restriction):</strong>
            <span style="font-weight:700; margin-left:6px;">${e.dishaShool||"West"}</span>
          </div>
          <div style="font-size:0.85rem; color:var(--color-text-muted);">
            <strong>Remedy if traveling is unavoidable:</strong> ${e.dishaShoolRemedy||"Consume betel leaf or ghee"}
          </div>
        </div>
      </div>
    `}renderGowriTable(a){if(!a)return'<div class="gk-card"><p>Gowri Panchangam not available for current location.</p></div>';const e=a.day||(Array.isArray(a)?a:[]),i=a.night||[];return`
      <div class="gk-card">
        <h3 style="color:var(--color-primary); margin-bottom:12px;">Gowri Panchangam (Auspicious Horas)</h3>
        <p style="font-size:0.85rem; color:var(--color-text-muted); margin-bottom:14px;">
          Traditional South Indian division of Day and Night into 8 equal periods of ~1.5 hours each.
        </p>
        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(300px, 1fr)); gap:20px;">
          <div>
            <h4 style="color:var(--color-secondary); margin-bottom:8px;">☀️ Daytime Gowri (Suryodayam to Astamanam)</h4>
            <table class="gk-table">
              <thead><tr><th>Interval</th><th>Gowri Lord</th><th>Nature</th></tr></thead>
              <tbody>
                ${e.map(t=>`
                  <tr>
                    <td>${t.slot||`${t.start} – ${t.end}`}</td>
                    <td><strong>${p(t.name,this.selectedLang)}</strong></td>
                    <td><span class="${t.isGood||t.nature==="Good"?"gk-badge-good":"gk-badge-inauspicious"}">${t.nature||(t.isGood?"Good":"Inauspicious")}</span></td>
                  </tr>
                `).join("")}
              </tbody>
            </table>
          </div>
          <div>
            <h4 style="color:var(--color-primary); margin-bottom:8px;">🌙 Nighttime Gowri (Astamanam to Suryodayam)</h4>
            <table class="gk-table">
              <thead><tr><th>Interval</th><th>Gowri Lord</th><th>Nature</th></tr></thead>
              <tbody>
                ${i.length>0?i.map(t=>`
                  <tr>
                    <td>${t.slot||`${t.start} – ${t.end}`}</td>
                    <td><strong>${p(t.name,this.selectedLang)}</strong></td>
                    <td><span class="${t.isGood||t.nature==="Good"?"gk-badge-good":"gk-badge-inauspicious"}">${t.nature||(t.isGood?"Good":"Inauspicious")}</span></td>
                  </tr>
                `).join(""):`
                  <tr><td colspan="3" style="text-align:center; color:var(--color-text-muted); padding:12px;">Night slots active after sunset</td></tr>
                `}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `}renderChoghadiyaTable(a){if(!a)return'<div class="gk-card"><p>Choghadiya not available for current location.</p></div>';const e=a.day||(Array.isArray(a)?a:[]),i=a.night||[];return`
      <div class="gk-card">
        <h3 style="color:var(--color-primary); margin-bottom:12px;">Choghadiya Muhurta</h3>
        <p style="font-size:0.85rem; color:var(--color-text-muted); margin-bottom:14px;">
          Traditional Vedic division of 4 Ghadis (~1.5 hours) for determining auspicious windows for travel and new beginnings.
        </p>
        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(300px, 1fr)); gap:20px;">
          <div>
            <h4 style="color:var(--color-secondary); margin-bottom:8px;">☀️ Day Choghadiya</h4>
            <table class="gk-table">
              <thead><tr><th>Time</th><th>Choghadiya</th><th>Effect</th></tr></thead>
              <tbody>
                ${e.map(t=>`
                  <tr>
                    <td>${t.slot||`${t.start} – ${t.end}`}</td>
                    <td><strong>${p(t.name,this.selectedLang)}</strong></td>
                    <td><span class="${t.isGood||t.nature==="Auspicious"?"gk-badge-good":"gk-badge-inauspicious"}">${t.nature||(t.isGood?"Auspicious":"Inauspicious")}</span></td>
                  </tr>
                `).join("")}
              </tbody>
            </table>
          </div>
          <div>
            <h4 style="color:var(--color-primary); margin-bottom:8px;">🌙 Night Choghadiya</h4>
            <table class="gk-table">
              <thead><tr><th>Time</th><th>Choghadiya</th><th>Effect</th></tr></thead>
              <tbody>
                ${i.length>0?i.map(t=>`
                  <tr>
                    <td>${t.slot||`${t.start} – ${t.end}`}</td>
                    <td><strong>${p(t.name,this.selectedLang)}</strong></td>
                    <td><span class="${t.isGood||t.nature==="Auspicious"?"gk-badge-good":"gk-badge-inauspicious"}">${t.nature||(t.isGood?"Auspicious":"Inauspicious")}</span></td>
                  </tr>
                `).join(""):`
                  <tr><td colspan="3" style="text-align:center; color:var(--color-text-muted); padding:12px;">Night slots active after sunset</td></tr>
                `}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `}renderPlanetsTable(a,e){return!a||!Array.isArray(a)?'<div class="gk-card"><p>Planetary positions not available.</p></div>':`
      <div class="gk-card">
        <h3 style="color:var(--color-primary); margin-bottom:8px;">Real-Time Sidereal Planetary Longitudes (Nirayana)</h3>
        <p style="font-size:0.85rem; color:var(--color-text-muted); margin-bottom:14px;">
          Calculated using Jean Meeus high-precision solar system algorithms with Lahiri Chitrapaksha Ayanamsa (${e&&e.formatted?e.formatted:e&&e.degrees!==void 0?`${e.degrees}° ${e.minutes}' ${e.seconds||0}"`:typeof e=="number"||typeof e=="string"?`${e}°`:`24° 13' 52"`}).
        </p>
        <div style="overflow-x:auto;">
          <table class="gk-table">
            <thead>
              <tr>
                <th>Graha (Planet)</th>
                <th>Longitude in Rashi</th>
                <th>Rashi (Zodiac)</th>
                <th>Nakshatra</th>
                <th>Pada</th>
                <th>Speed / Status</th>
              </tr>
            </thead>
            <tbody>
              ${a.map(t=>{const n=t.deg!==void 0?t.deg:Math.floor((t.siderealLon||0)%30),r=t.min!==void 0?t.min:Math.floor((t.siderealLon||0)%1*60),l=t.sec!==void 0?t.sec:Math.round((t.siderealLon||0)%1*60%1*60),s=t.sanskrit?` (${p(t.sanskrit,this.selectedLang)})`:"",h=t.nakshatra?p(t.nakshatra,this.selectedLang):"—",u=t.pada!==void 0?t.pada:1,m=t.status||(t.isRetrograde?"Retrograde (Vakra)":"Direct (Marga)"),x=t.isRetrograde||m.includes("Retrograde");return`
                  <tr>
                    <td><strong>${t.name}${s}</strong></td>
                    <td>${n}° ${r}' ${l}"</td>
                    <td>${p(t.rashi||"",this.selectedLang)} (${t.rashiEnglish||""})</td>
                    <td>${h}</td>
                    <td>Pada ${u}</td>
                    <td><span class="${x?"gk-badge-inauspicious":"gk-badge-good"}">${m}</span></td>
                  </tr>
                `}).join("")}
            </tbody>
          </table>
        </div>
      </div>
    `}renderJyotirlingas(){return`
      <section>
        <div class="gk-jyotir-header-banner">
          <div class="gk-jyotir-header-title">
            द्वादश ज्योतिर्लिङ्ग महाक्षेत्राणि
          </div>
          <div style="font-family:'Cinzel',serif; font-size:1.15rem; color:#FFE0B2; margin-bottom:6px;">
            The 12 Sacred Jyotirlingas of Lord Shiva
          </div>
          <div class="gk-jyotir-stotram-box">
            सौराष्ट्रे सोमनाथं च श्रीशैले मल्लिकार्जुनम् ।<br>
            उज्जयिन्यां महाकालमोंकारममलेश्वरम् ॥<br>
            परल्यां वैद्यनाथं च डाकिन्यां भीमशङ्करम् ।<br>
            सेतुबन्धे तु रामेशं नागेशं दारुकावने ॥<br>
            वाराणस्यां च विश्वेशं त्र्यम्बकं गौतमीतटे ।<br>
            हिमवन्ते तु केदारं घुश्मेशं च शिवालये ॥
          </div>
          <p style="font-size:0.88rem; color:#FFFFFF; opacity:0.9; max-width:760px; margin:0 auto; line-height:1.5;">
            Sacred pilgrimage guide detailing divine Vigraha manifestations, astrologically verified Parikaras & Dosha Nivarana remedies, specific temple pooja rituals, and authentic puranic, local sthala, and folklore histories.
          </p>
        </div>

        <div class="gk-jyotir-grid">
          ${Ra.map(a=>`
            <div class="gk-jyotir-card" id="jyotir-${a.id}">
              <div class="gk-jyotir-top">
                <div class="gk-jyotir-icon-wrapper">
                  ${a.iconSvg}
                </div>
                <div class="gk-jyotir-names">
                  <div class="gk-jyotir-title">${a.name}</div>
                  <div class="gk-jyotir-sanskrit">${p(a.sanskritName,this.selectedLang)}</div>
                  <div class="gk-jyotir-location">📍 ${a.location}</div>
                  <div style="font-size:0.75rem; color:var(--color-secondary); margin-top:2px;">
                    🌊 ${a.riverOrSea}
                  </div>
                </div>
              </div>

              <!-- What a Visit Can Do (Parikaras & Dosha Nivarana) -->
              <div class="gk-jyotir-benefits-box">
                <div class="gk-jyotir-section-heading">
                  <span>🪷</span> Spiritual Upliftment & Remedies
                </div>
                <div class="gk-jyotir-benefit-row">
                  <strong>🛡️ Parikaras:</strong> ${a.whatVisitDoes.parikaras}
                </div>
                <div class="gk-jyotir-benefit-row">
                  <strong>🔱 Dosha Nivarana:</strong> ${a.whatVisitDoes.doshaNivarana}
                </div>
                <div class="gk-jyotir-benefit-row">
                  <strong>✨ Upliftment:</strong> ${a.whatVisitDoes.spiritualUpliftment}
                </div>
              </div>

              <!-- Specific Pooja Practices -->
              <div class="gk-jyotir-poojas-box">
                <div class="gk-jyotir-section-heading">
                  <span>🪔</span> Specific Pooja Practices
                </div>
                ${a.specificPoojas.map(e=>`
                  <div class="gk-pooja-pill">
                    <div class="gk-pooja-pill-title">
                      <span>${e.name}</span>
                      <span class="gk-pooja-pill-timing">${e.timing}</span>
                    </div>
                    <div class="gk-pooja-pill-desc">${e.details}</div>
                  </div>
                `).join("")}
              </div>

              <!-- Deep History (Puranic, Local, Folklore) -->
              <div class="gk-history-accordion">
                <div class="gk-jyotir-section-heading" style="margin-bottom:10px;">
                  <span>📜</span> Sacred Temple History
                </div>
                <div class="gk-history-block">
                  <span class="gk-history-tag">📖 Puranic History (Shiva Purana)</span>
                  ${a.history.puranic}
                </div>
                <div class="gk-history-block">
                  <span class="gk-history-tag">🏛️ Local Sthala Mahatmyam</span>
                  ${a.history.local}
                </div>
                <div class="gk-history-block">
                  <span class="gk-history-tag">✨ Living Tradition & Folklore</span>
                  ${a.history.folklore}
                </div>
              </div>

              <!-- Authentic Chanting Button for this Shrine -->
              <div style="margin-top:14px; padding-top:12px; border-top:1px dashed var(--color-border); display:flex; justify-content:space-between; align-items:center;">
                <button class="gk-btn gk-audio-play-btn" data-play-id="${a.id}" style="font-size:0.8rem; padding:6px 12px; display:inline-flex; align-items:center; gap:6px;">
                  ${this.playingSlokaId===a.id?"⏸ Pause Chant":"▶ Chant Verse"}
                </button>
                <span style="font-family:'Noto Serif Devanagari',serif; font-size:0.85rem; color:var(--color-text-muted);">
                  ${a.stotramVerse}
                </span>
              </div>
            </div>
          `).join("")}
        </div>
      </section>
    `}renderStotras(){const a=oa.filter(i=>{const t=this.selectedDeity==="all"||i.deityId===this.selectedDeity,n=this.selectedCategory==="all"||i.category===this.selectedCategory;return t&&n}),e=["all","Stotra","Mantra","Chalisa","Ashtakam","Suprabhatam","Prayer"];return`
      <section>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:12px;">
          <div>
            <h2 style="color:var(--color-primary); font-size:1.6rem;">
              ${p("स्तोत्राणि मन्त्राश्च",this.selectedLang)} (12 Deity Shrines & Stotras)
            </h2>
            <p style="font-size:0.85rem; color:var(--color-text-muted);">
              Select any Sacred Shrine or filter by Category. Instant 1-click script switching across 11 Indian scripts.
            </p>
          </div>
          <div style="display:flex; align-items:center; gap:8px;">
            <button id="gk-font-dec" class="gk-btn" title="Decrease Font">A-</button>
            <button id="gk-font-inc" class="gk-btn" title="Increase Font">A+</button>
            <button id="gk-toggle-sabdartha" class="gk-btn ${this.showSabdartha?"gk-btn-primary":""}">
              ${this.showSabdartha?"✓ Sabdartha":"+ Sabdartha"}
            </button>
          </div>
        </div>

        <!-- 12 Sacred Deity Hubs Shrines Bar -->
        <div class="gk-deity-hub-container">
          <div class="gk-deity-scroll-track">
            ${We.map(i=>`
              <div class="gk-deity-card-chip ${this.selectedDeity===i.id?"active":""}" data-deity-id="${i.id}">
                <span class="gk-deity-icon">${i.icon}</span>
                <div class="gk-deity-meta">
                  <span class="gk-deity-name">${i.name}</span>
                  <span class="gk-deity-sanskrit">${p(i.sanskrit,this.selectedLang)}</span>
                </div>
              </div>
            `).join("")}
          </div>
        </div>

        <!-- Category Filter Pills -->
        <div class="gk-category-pills">
          ${e.map(i=>`
            <button class="gk-cat-pill ${this.selectedCategory===i?"active":""}" data-category="${i}">
              ${i==="all"?"All Types":i}
            </button>
          `).join("")}
        </div>

        <!-- Sloka Cards List -->
        ${a.length===0?`
          <div class="gk-card" style="text-align:center; padding:32px;">
            <p>No texts found for this shrine & category filter.</p>
            <button class="gk-btn gk-btn-primary" id="gk-reset-filters" style="margin-top:12px;">Reset Filters</button>
          </div>
        `:a.map((i,t)=>`
          <article class="gk-sloka-card" id="${i.id}">
            <div class="gk-sloka-header">
              <div>
                <div style="display:flex; align-items:center; gap:8px; margin-bottom:4px;">
                  <span class="gk-badge-good">${i.category}</span>
                  <span style="font-size:0.75rem; color:var(--color-text-muted);">Shrine: <strong>${i.deity}</strong></span>
                </div>
                <h3 class="gk-sloka-title">${p(i.title,this.selectedLang)}</h3>
                <span class="gk-sloka-source">${i.source} • Meter: ${i.meter}</span>
              </div>
              <div style="display:flex; gap:8px; align-items:center;">
                <button class="gk-share-card-btn" data-share-id="${i.id}" title="Generate Devotional WhatsApp Status Card">
                  🎨 Share Card
                </button>
              </div>
            </div>

            <!-- Chanting Audio Bar with Speed Selector -->
            <div class="gk-chant-player">
              <div class="gk-audio-controls-left">
                <button class="gk-audio-play-btn" data-play-id="${i.id}" title="Chant sacred Sanskrit verse with temple Tanpura">
                  ${this.playingSlokaId===i.id?"⏸":"▶"}
                </button>
                <span class="gk-audio-label">
                  ${this.playingSlokaId===i.id?"Chanting sacred Sanskrit verse with Tanpura...":"Chant Sanskrit Sloka"}
                </span>
              </div>
              <div class="gk-speed-selector">
                <span style="font-size:0.75rem; color:var(--color-text-muted); margin-right:4px;">Speed:</span>
                <button class="gk-speed-btn ${this.chantSpeed===.75?"active":""}" data-speed="0.75">0.75x</button>
                <button class="gk-speed-btn ${this.chantSpeed===1?"active":""}" data-speed="1.0">1.0x</button>
                <button class="gk-speed-btn ${this.chantSpeed===1.25?"active":""}" data-speed="1.25">1.25x</button>
              </div>
            </div>

            <!-- Sacred Verse (100% Clean Font Rendering - Zero Tofu Boxes) -->
            <div class="gk-sloka-text" style="font-size:${this.slokaFontSize}rem;">
              ${p(i.devanagari,this.selectedLang)}
            </div>

            <div class="gk-sloka-iast">${i.iast}</div>

            ${this.showSabdartha&&i.sabdartha?`
              <div class="gk-sabdartha-grid">
                ${i.sabdartha.map(n=>`
                  <div class="gk-sabdartha-item">
                    <span class="gk-sabdartha-word">${p(n.word,this.selectedLang)}:</span> ${n.meaning}
                  </div>
                `).join("")}
              </div>
            `:""}

            <div class="gk-sloka-translation">
              <strong>Translation:</strong> ${i.translation}
            </div>

            <div class="gk-sloka-purport">
              <strong>Purport & Spiritual Insight:</strong> ${i.purport}
            </div>

            ${t===1?this.renderAdSlot("ad-stotra-incontent","rectangle"):""}
          </article>
        `).join("")}
      </section>
    `}renderJapa(){return`
      <section>
        <div class="gk-japa-container">
          <h2 style="color:var(--color-primary); margin-bottom:6px;">
            ${p("जपमाला",this.selectedLang)} (108-Bead Japa Mala)
          </h2>
          <p style="font-size:0.85rem; color:var(--color-text-muted); margin-bottom:18px;">
            Tap the sacred bead circle or press <kbd style="background:#eee; padding:2px 6px; border-radius:4px;">Spacebar</kbd> / <kbd style="background:#eee; padding:2px 6px; border-radius:4px;">Enter</kbd> to count.
          </p>

          <div style="margin-bottom:14px;">
            <select id="gk-japa-mantra-select" class="gk-select" style="max-width:90%;">
              <option value="ॐ नमो भगवते वासुदेवाय">ॐ नमो भगवते वासुदेवाय (Om Namo Bhagavate Vasudevaya)</option>
              <option value="हरे कृष्ण हरे कृष्ण कृष्ण कृष्ण हरे हरे">हरे कृष्ण हरे कृष्ण कृष्ण कृष्ण हरे हरे (Maha-Mantra)</option>
              <option value="ॐ नमः शिवाय">ॐ नमः शिवाय (Om Namah Shivaya)</option>
              <option value="श्री राम जय राम जय जय राम">श्री राम जय राम जय जय राम (Sri Ram Jaya Ram)</option>
              <option value="ॐ गं गणपतये नमः">ॐ गं गणपतये नमः (Ganesha Mantra)</option>
            </select>
          </div>

          <div id="gk-japa-trigger" class="gk-japa-circle" title="Tap to Count">
            <div id="gk-bead-number" class="gk-bead-number">${this.japaEngine.bead}</div>
            <div class="gk-bead-max">of 108 Beads</div>
          </div>

          <div class="gk-japa-stats">
            <div>
              <div id="gk-stat-rounds" class="gk-japa-stat-num">${this.japaEngine.rounds}</div>
              <div class="gk-japa-stat-label">Mala Rounds</div>
            </div>
            <div>
              <div id="gk-stat-total" class="gk-japa-stat-num">${this.japaEngine.totalChants}</div>
              <div class="gk-japa-stat-label">Total Chants</div>
            </div>
            <div>
              <div class="gk-japa-stat-num">${this.japaEngine.dailyTargetRounds}</div>
              <div class="gk-japa-stat-label">Target Malas</div>
            </div>
          </div>

          <div style="display:flex; justify-content:center; gap:10px; margin-top:20px; flex-wrap:wrap;">
            <button id="gk-japa-sound-toggle" class="gk-btn">
              ${this.japaEngine.soundEnabled?"🔔 Sound: ON":"🔕 Sound: OFF"}
            </button>
            <button id="gk-japa-vib-toggle" class="gk-btn">
              ${this.japaEngine.vibrationEnabled?"📳 Haptics: ON":"📴 Haptics: OFF"}
            </button>
            <button id="gk-japa-meru-toggle" class="gk-btn">
              ${this.japaEngine.meruReversalMode?"🔄 Meru Reversal: ON":"🔁 Continuous Loop"}
            </button>
            <button id="gk-japa-reset" class="gk-btn" style="color:var(--color-inauspicious);">Reset Round</button>
          </div>

          <div style="margin-top:24px; border-top:1px solid var(--color-border); padding-top:16px;">
            <button id="gk-japa-export" class="gk-btn" style="font-size:0.75rem;">💾 Export Sadhana JSON</button>
          </div>
        </div>
      </section>
    `}renderStories(){return`
      <section>
        <div style="margin-bottom:24px;">
          <h2 style="color:var(--color-primary); font-size:1.6rem;">
            ${p("नीतिकथाः",this.selectedLang)} (Dharmic Wisdom & Moral Stories)
          </h2>
          <p style="font-size:0.85rem; color:var(--color-text-muted);">
            Timeless fables from the 5 Books of Panchatantra, Hitopadesha, Tenali Raman, and Upanishads with illuminated moral cards.
          </p>
        </div>

        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(320px, 1fr)); gap:20px;">
          ${ja.map(a=>`
            <article class="gk-story-card">
              <div>
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                  <span class="gk-badge-good">${a.collection}</span>
                  <span style="font-size:0.75rem; color:var(--color-text-muted);">Reading: 3 mins</span>
                </div>
                <h3 style="color:var(--color-primary); font-size:1.25rem; margin-bottom:8px;">${a.title}</h3>
                
                <div style="background:rgba(230,81,0,0.04); padding:10px 14px; border-radius:6px; margin-bottom:14px; font-style:italic; font-size:0.85rem; border-left:3px solid var(--color-secondary);">
                  "${a.epigraphTranslation}"
                </div>

                <p style="font-size:0.9rem; line-height:1.65; margin-bottom:14px; color:var(--color-text);">
                  ${a.summary}
                </p>

                <!-- Prominent Golden Moral Takeaway Card -->
                <div class="gk-moral-takeaway-card">
                  <div class="gk-moral-takeaway-label">✨ Sacred Moral Takeaway</div>
                  <div class="gk-moral-takeaway-text">${a.moral}</div>
                </div>

                <div style="margin-bottom:14px;">
                  <div style="font-size:0.75rem; text-transform:uppercase; color:var(--color-text-muted); margin-bottom:4px;">Sanskrit Vocabulary:</div>
                  <div style="display:flex; flex-wrap:wrap; gap:6px;">
                    ${a.vocabulary.map(e=>`
                      <span style="font-size:0.75rem; background:rgba(0,0,0,0.05); padding:2px 8px; border-radius:4px;" title="${e.meaning}">
                        ${e.term}
                      </span>
                    `).join("")}
                  </div>
                </div>
              </div>

              <!-- Interactive Ethical Dilemma Quiz -->
              <div style="border-top:1px solid var(--color-border); padding-top:12px; margin-top:12px;">
                <div style="font-size:0.85rem; font-weight:700; margin-bottom:6px;">Dharmic Reflection:</div>
                <p style="font-size:0.85rem; margin-bottom:10px;">${a.quiz.question}</p>
                <div class="gk-quiz-options" data-story="${a.id}">
                  ${a.quiz.options.map((e,i)=>`
                    <button class="gk-btn gk-quiz-btn" data-story="${a.id}" data-idx="${i}" style="width:100%; text-align:left; margin-bottom:6px; font-size:0.8rem;">
                      ${e}
                    </button>
                  `).join("")}
                </div>
                <div id="gk-quiz-result-${a.id}" style="display:none; padding:8px 12px; border-radius:6px; font-size:0.8rem; margin-top:6px;"></div>
              </div>
            </article>
          `).join("")}
        </div>
      </section>
    `}renderCityModal(){return`
      <div class="gk-modal-backdrop" id="gk-city-modal-backdrop">
        <div class="gk-modal">
          <div class="gk-modal-header">
            <h3 style="color:var(--color-primary);">Select Global City</h3>
            <button id="gk-modal-close" class="gk-btn" style="border:none; font-size:1.2rem;">✕</button>
          </div>
          <input type="text" id="gk-city-search" class="gk-search-input" placeholder="Search 100+ global cities (e.g. Chennai, London, New York)..." autofocus>
          <ul class="gk-city-list" id="gk-city-list">
            ${this.cities.map(a=>`
              <li class="gk-city-item ${a.id===this.selectedCity.id?"active":""}" data-city-id="${a.id}">
                <div>
                  <strong>${a.name}</strong>
                  <span style="font-size:0.75rem; color:var(--color-text-muted); display:block;">${a.state?a.state+", ":""}${a.country}</span>
                </div>
                <span style="font-size:0.75rem; color:var(--color-accent); font-weight:700;">${a.tz_offset>=0?"+"+a.tz_offset:a.tz_offset}h</span>
              </li>
            `).join("")}
          </ul>
        </div>
      </div>
    `}renderCardMakerModal(){return`
      <div class="gk-modal-backdrop" id="gk-card-modal-backdrop">
        <div class="gk-card-maker-modal">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
            <h3 style="color:var(--color-primary); font-size:1.3rem;">🎨 Devotional Share-Card Generator</h3>
            <button id="gk-card-maker-close" class="gk-btn" style="border:none; font-size:1.2rem;">✕</button>
          </div>

          <p style="font-size:0.85rem; color:var(--color-text-muted);">
            Pick a sacred theme below and download or share your customized status card directly to WhatsApp or Instagram!
          </p>

          <!-- Theme Swatches -->
          <div class="gk-theme-swatches">
            <div class="gk-theme-swatch gk-theme-saffron ${this.cardTheme==="saffron"?"active":""}" data-theme="saffron">
              Saffron Dawn
            </div>
            <div class="gk-theme-swatch gk-theme-maroon ${this.cardTheme==="maroon"?"active":""}" data-theme="maroon">
              Sacred Maroon
            </div>
            <div class="gk-theme-swatch gk-theme-sandal ${this.cardTheme==="sandal"?"active":""}" data-theme="sandal">
              Sandalwood
            </div>
            <div class="gk-theme-swatch gk-theme-indigo ${this.cardTheme==="indigo"?"active":""}" data-theme="indigo">
              Temple Indigo
            </div>
          </div>

          <!-- Live Canvas Preview -->
          <div class="gk-canvas-preview-wrapper">
            <canvas id="gk-share-canvas"></canvas>
          </div>

          <!-- Action Buttons -->
          <div style="display:flex; justify-content:space-between; gap:12px; flex-wrap:wrap;">
            <button id="gk-canvas-download" class="gk-btn gk-btn-primary" style="flex:1;">
              📥 Download Image (PNG)
            </button>
            <button id="gk-canvas-whatsapp" class="gk-btn" style="flex:1; background:#25D366; color:#FFF; border:none; font-weight:700;">
              📱 Share on WhatsApp
            </button>
          </div>
        </div>
      </div>
    `}renderAdSlot(a,e="banner"){return`
      <div class="gk-ad-container gk-ad-${e}" id="${a}" data-ad-slot="${a}">
        <span class="gk-ad-label">ADVERTISEMENT</span>
        <div class="gk-ad-placeholder">
          <!-- Google AdSense Ready Slot (Zero CLS Pre-allocated) -->
        </div>
      </div>
    `}renderConsentBanner(){return localStorage.getItem("gk_consent")?"":`
      <div class="gk-consent-banner" id="gk-consent-banner">
        <div class="gk-consent-text">
          GuruKripa operates with a <strong>Zero-Server, Zero-PII</strong> architecture. We store your preferred city, script, and sadhana counts strictly inside your browser's private local storage.
        </div>
        <div class="gk-consent-actions">
          <button id="gk-consent-accept" class="gk-btn gk-btn-primary" style="font-size:0.8rem;">Accept & Continue</button>
        </div>
      </div>
    `}renderFooter(){return`
      <footer class="gk-footer">
        <div class="gk-footer-inner">
          <div>
            <span style="font-weight:700; color:var(--color-primary); font-size:1.1rem; display:block; margin-bottom:4px;">GuruKripa</span>
            <p style="font-size:0.8rem; color:var(--color-text-muted); max-width:400px;">
              A zero-cost, enterprise-grade Vedic spiritual portal dedicated to preserving and celebrating Sanatana Dharma with scientific astronomical precision and authentic public-domain texts.
            </p>
          </div>
          <ul class="gk-footer-links">
            <li><a href="/privacy.html">Privacy Policy</a></li>
            <li><a href="/terms.html">Terms of Service</a></li>
            <li><a href="/disclaimer.html">Astronomical Disclaimer</a></li>
          </ul>
        </div>
      </footer>
    `}bindEvents(){const a=document.getElementById("gk-lang-select");a&&a.addEventListener("change",d=>{this.selectedLang=d.target.value,localStorage.setItem("gk_lang",this.selectedLang),document.documentElement.setAttribute("data-lang",this.selectedLang),this.render()});const e=document.getElementById("gk-city-btn");e&&e.addEventListener("click",()=>{this.cityModalOpen=!0,this.render()});const i=document.getElementById("gk-gps-btn");i&&i.addEventListener("click",()=>this.autoDetectLocation());const t=document.getElementById("gk-theme-btn");t&&t.addEventListener("click",()=>this.toggleTheme()),document.querySelectorAll(".gk-nav-links a").forEach(d=>{d.addEventListener("click",k=>{k.preventDefault();const M=d.getAttribute("href");if(M&&M.startsWith("#")){const b=M.replace("#","");this.currentView=b,window.location.hash=b,this.render(),window.scrollTo({top:0,behavior:"smooth"})}})}),document.querySelectorAll(".gk-tab-btn").forEach(d=>{d.addEventListener("click",k=>{this.panchangTab=d.getAttribute("data-tab"),this.render()})});const n=document.getElementById("gk-chart-style-select");n&&n.addEventListener("change",d=>{this.chartStyle=d.target.value,this.render()});const r=document.getElementById("gk-date-picker");r&&r.addEventListener("change",d=>{this.selectedDate=new Date(d.target.value),this.render()}),document.querySelectorAll(".gk-deity-card-chip").forEach(d=>{d.addEventListener("click",()=>{this.selectedDeity=d.getAttribute("data-deity-id"),this.render()})}),document.querySelectorAll(".gk-cat-pill").forEach(d=>{d.addEventListener("click",()=>{this.selectedCategory=d.getAttribute("data-category"),this.render()})});const l=document.getElementById("gk-reset-filters");l&&l.addEventListener("click",()=>{this.selectedDeity="all",this.selectedCategory="all",this.render()}),document.querySelectorAll(".gk-audio-play-btn").forEach(d=>{d.addEventListener("click",()=>{const k=d.getAttribute("data-play-id");this.playChantSound(k)})}),document.querySelectorAll(".gk-speed-btn").forEach(d=>{d.addEventListener("click",()=>{this.chantSpeed=parseFloat(d.getAttribute("data-speed")),this.render()})}),document.querySelectorAll(".gk-share-card-btn").forEach(d=>{d.addEventListener("click",()=>{const k=d.getAttribute("data-share-id");this.openCardMaker(k)})});const s=document.getElementById("gk-card-maker-close");s&&s.addEventListener("click",()=>this.closeCardMaker()),document.querySelectorAll(".gk-theme-swatch").forEach(d=>{d.addEventListener("click",()=>{this.cardTheme=d.getAttribute("data-theme"),document.querySelectorAll(".gk-theme-swatch").forEach(k=>k.classList.remove("active")),d.classList.add("active"),this.drawShareCanvas()})});const h=document.getElementById("gk-canvas-download");h&&h.addEventListener("click",()=>this.downloadCardImage());const u=document.getElementById("gk-canvas-whatsapp");u&&u.addEventListener("click",()=>this.shareCardToWhatsApp());const m=document.getElementById("gk-modal-close");m&&m.addEventListener("click",()=>{this.cityModalOpen=!1,this.render()});const x=document.getElementById("gk-city-search");x&&x.addEventListener("input",d=>{const k=d.target.value.toLowerCase();document.querySelectorAll(".gk-city-item").forEach(b=>{const $=b.innerText.toLowerCase();b.style.display=$.includes(k)?"flex":"none"})}),document.querySelectorAll(".gk-city-item").forEach(d=>{d.addEventListener("click",()=>{const k=d.getAttribute("data-city-id"),M=this.cities.find(b=>b.id===k);M&&(this.saveCity(M),this.cityModalOpen=!1,this.render())})});const y=document.getElementById("gk-font-inc");y&&y.addEventListener("click",()=>{this.slokaFontSize=Math.min(this.slokaFontSize+.15,2.2),this.render()});const S=document.getElementById("gk-font-dec");S&&S.addEventListener("click",()=>{this.slokaFontSize=Math.max(this.slokaFontSize-.15,.9),this.render()});const A=document.getElementById("gk-toggle-sabdartha");A&&A.addEventListener("click",()=>{this.showSabdartha=!this.showSabdartha,this.render()});const P=document.getElementById("gk-japa-trigger");P&&P.addEventListener("click",()=>this.handleJapaClick());const I=document.getElementById("gk-japa-sound-toggle");I&&I.addEventListener("click",()=>{this.japaEngine.soundEnabled=!this.japaEngine.soundEnabled,this.japaEngine.saveState(),this.render()});const L=document.getElementById("gk-japa-vib-toggle");L&&L.addEventListener("click",()=>{this.japaEngine.vibrationEnabled=!this.japaEngine.vibrationEnabled,this.japaEngine.saveState(),this.render()});const R=document.getElementById("gk-japa-meru-toggle");R&&R.addEventListener("click",()=>{this.japaEngine.meruReversalMode=!this.japaEngine.meruReversalMode,this.japaEngine.saveState(),this.render()});const E=document.getElementById("gk-japa-reset");E&&E.addEventListener("click",()=>{confirm("Reset current 108 bead counter to 0?")&&(this.japaEngine.resetCurrentMala(),this.render())});const B=document.getElementById("gk-japa-export");B&&B.addEventListener("click",()=>{const d=this.japaEngine.exportDataJSON(),k=new Blob([d],{type:"application/json"}),M=URL.createObjectURL(k),b=document.createElement("a");b.href=M,b.download=`GuruKripa_Japa_Backup_${new Date().toISOString().slice(0,10)}.json`,b.click()}),document.querySelectorAll(".gk-quiz-btn").forEach(d=>{d.addEventListener("click",()=>{const k=d.getAttribute("data-story"),M=parseInt(d.getAttribute("data-idx"),10),b=ja.find(D=>D.id===k),$=document.getElementById(`gk-quiz-result-${k}`);b&&$&&($.style.display="block",M===b.quiz.correctIndex?($.style.background="rgba(46, 125, 50, 0.1)",$.style.color="#2E7D32",$.innerHTML=`<strong>✓ Spot On!</strong> ${b.quiz.explanation}`):($.style.background="rgba(198, 40, 40, 0.1)",$.style.color="#C62828",$.innerHTML="<strong>Reflect Again:</strong> Consider the spiritual principle of Buddhi and Satya."))})});const j=document.getElementById("gk-consent-accept");j&&j.addEventListener("click",()=>{localStorage.setItem("gk_consent","accepted");const d=document.getElementById("gk-consent-banner");d&&d.remove()})}}document.addEventListener("DOMContentLoaded",()=>{new tt});
