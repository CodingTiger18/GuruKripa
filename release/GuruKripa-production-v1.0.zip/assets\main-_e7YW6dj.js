(function(){const a=document.createElement("link").relList;if(a&&a.supports&&a.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))t(i);new MutationObserver(i=>{for(const n of i)if(n.type==="childList")for(const l of n.addedNodes)l.tagName==="LINK"&&l.rel==="modulepreload"&&t(l)}).observe(document,{childList:!0,subtree:!0});function e(i){const n={};return i.integrity&&(n.integrity=i.integrity),i.referrerPolicy&&(n.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?n.credentials="include":i.crossOrigin==="anonymous"?n.credentials="omit":n.credentials="same-origin",n}function t(i){if(i.ep)return;i.ep=!0;const n=e(i);fetch(i.href,n)}})();const ga=[{id:"delhi",name:"New Delhi",state:"Delhi",country:"India",lat:28.6139,lon:77.209,tz:"Asia/Kolkata",tz_offset:5.5,elevation:216},{id:"mumbai",name:"Mumbai",state:"Maharashtra",country:"India",lat:19.076,lon:72.8777,tz:"Asia/Kolkata",tz_offset:5.5,elevation:14},{id:"chennai",name:"Chennai",state:"Tamil Nadu",country:"India",lat:13.0827,lon:80.2707,tz:"Asia/Kolkata",tz_offset:5.5,elevation:6},{id:"bengaluru",name:"Bengaluru",state:"Karnataka",country:"India",lat:12.9716,lon:77.5946,tz:"Asia/Kolkata",tz_offset:5.5,elevation:920},{id:"hyderabad",name:"Hyderabad",state:"Telangana",country:"India",lat:17.385,lon:78.4867,tz:"Asia/Kolkata",tz_offset:5.5,elevation:542},{id:"kolkata",name:"Kolkata",state:"West Bengal",country:"India",lat:22.5726,lon:88.3639,tz:"Asia/Kolkata",tz_offset:5.5,elevation:9},{id:"ahmedabad",name:"Ahmedabad",state:"Gujarat",country:"India",lat:23.0225,lon:72.5714,tz:"Asia/Kolkata",tz_offset:5.5,elevation:53},{id:"varanasi",name:"Varanasi (Kashi)",state:"Uttar Pradesh",country:"India",lat:25.3176,lon:82.9739,tz:"Asia/Kolkata",tz_offset:5.5,elevation:81},{id:"tirupati",name:"Tirupati",state:"Andhra Pradesh",country:"India",lat:13.6288,lon:79.4192,tz:"Asia/Kolkata",tz_offset:5.5,elevation:182},{id:"puri",name:"Puri (Jagannath)",state:"Odisha",country:"India",lat:19.8135,lon:85.8312,tz:"Asia/Kolkata",tz_offset:5.5,elevation:10},{id:"rameswaram",name:"Rameswaram",state:"Tamil Nadu",country:"India",lat:9.2876,lon:79.3129,tz:"Asia/Kolkata",tz_offset:5.5,elevation:10},{id:"haridwar",name:"Haridwar",state:"Uttarakhand",country:"India",lat:29.9457,lon:78.1642,tz:"Asia/Kolkata",tz_offset:5.5,elevation:314},{id:"ujjain",name:"Ujjain (Mahakaleshwar)",state:"Madhya Pradesh",country:"India",lat:23.1765,lon:75.7885,tz:"Asia/Kolkata",tz_offset:5.5,elevation:491},{id:"madurai",name:"Madurai (Meenakshi)",state:"Tamil Nadu",country:"India",lat:9.9252,lon:78.1198,tz:"Asia/Kolkata",tz_offset:5.5,elevation:101},{id:"dwarka",name:"Dwarka",state:"Gujarat",country:"India",lat:22.2442,lon:68.9685,tz:"Asia/Kolkata",tz_offset:5.5,elevation:5},{id:"somnath",name:"Somnath",state:"Gujarat",country:"India",lat:20.906,lon:70.401,tz:"Asia/Kolkata",tz_offset:5.5,elevation:12},{id:"ayodhya",name:"Ayodhya",state:"Uttar Pradesh",country:"India",lat:26.7922,lon:82.1998,tz:"Asia/Kolkata",tz_offset:5.5,elevation:102},{id:"mathura",name:"Mathura / Vrindavan",state:"Uttar Pradesh",country:"India",lat:27.4924,lon:77.6737,tz:"Asia/Kolkata",tz_offset:5.5,elevation:174},{id:"bhubaneswar",name:"Bhubaneswar",state:"Odisha",country:"India",lat:20.2961,lon:85.8245,tz:"Asia/Kolkata",tz_offset:5.5,elevation:45},{id:"guruvayur",name:"Guruvayur",state:"Kerala",country:"India",lat:10.5946,lon:76.0416,tz:"Asia/Kolkata",tz_offset:5.5,elevation:12},{id:"shirdi",name:"Shirdi",state:"Maharashtra",country:"India",lat:19.7667,lon:74.4764,tz:"Asia/Kolkata",tz_offset:5.5,elevation:504},{id:"pune",name:"Pune",state:"Maharashtra",country:"India",lat:18.5204,lon:73.8567,tz:"Asia/Kolkata",tz_offset:5.5,elevation:560},{id:"jaipur",name:"Jaipur",state:"Rajasthan",country:"India",lat:26.9124,lon:75.7873,tz:"Asia/Kolkata",tz_offset:5.5,elevation:431},{id:"new-york",name:"New York",state:"NY",country:"USA",lat:40.7128,lon:-74.006,tz:"America/New_York",tz_offset:-5,elevation:10},{id:"san-jose",name:"San Jose (Silicon Valley)",state:"CA",country:"USA",lat:37.3382,lon:-121.8863,tz:"America/Los_Angeles",tz_offset:-8,elevation:26},{id:"chicago",name:"Chicago",state:"IL",country:"USA",lat:41.8781,lon:-87.6298,tz:"America/Chicago",tz_offset:-6,elevation:181},{id:"dallas",name:"Dallas",state:"TX",country:"USA",lat:32.7767,lon:-96.797,tz:"America/Chicago",tz_offset:-6,elevation:131},{id:"london",name:"London",state:"England",country:"UK",lat:51.5074,lon:-.1278,tz:"Europe/London",tz_offset:0,elevation:11},{id:"leicester",name:"Leicester",state:"England",country:"UK",lat:52.6369,lon:-1.1398,tz:"Europe/London",tz_offset:0,elevation:67},{id:"toronto",name:"Toronto",state:"ON",country:"Canada",lat:43.6532,lon:-79.3832,tz:"America/Toronto",tz_offset:-5,elevation:76},{id:"vancouver",name:"Vancouver",state:"BC",country:"Canada",lat:49.2827,lon:-123.1207,tz:"America/Vancouver",tz_offset:-8,elevation:2},{id:"sydney",name:"Sydney",state:"NSW",country:"Australia",lat:-33.8688,lon:151.2093,tz:"Australia/Sydney",tz_offset:10,elevation:19},{id:"melbourne",name:"Melbourne",state:"VIC",country:"Australia",lat:-37.8136,lon:144.9631,tz:"Australia/Melbourne",tz_offset:10,elevation:31},{id:"singapore",name:"Singapore",state:"Singapore",country:"Singapore",lat:1.3521,lon:103.8198,tz:"Asia/Singapore",tz_offset:8,elevation:15},{id:"dubai",name:"Dubai",state:"Dubai",country:"UAE",lat:25.2048,lon:55.2708,tz:"Asia/Dubai",tz_offset:4,elevation:5},{id:"kuala-lumpur",name:"Kuala Lumpur",state:"Federal Territory",country:"Malaysia",lat:3.139,lon:101.6869,tz:"Asia/Kuala_Lumpur",tz_offset:8,elevation:21},{id:"durban",name:"Durban",state:"KwaZulu-Natal",country:"South Africa",lat:-29.8587,lon:31.0218,tz:"Africa/Johannesburg",tz_offset:2,elevation:14},{id:"nairobi",name:"Nairobi",state:"Nairobi",country:"Kenya",lat:-1.2921,lon:36.8219,tz:"Africa/Nairobi",tz_offset:3,elevation:1795},{id:"mauritius",name:"Port Louis",state:"Port Louis",country:"Mauritius",lat:-20.1609,lon:57.5012,tz:"Indian/Mauritius",tz_offset:4,elevation:13},{id:"tokyo",name:"Tokyo",state:"Tokyo",country:"Japan",lat:35.6762,lon:139.6503,tz:"Asia/Tokyo",tz_offset:9,elevation:40}],pa=[{id:1,name:"Prathama",paksha:"Shukla",deity:"Agni"},{id:2,name:"Dwitiya",paksha:"Shukla",deity:"Brahma"},{id:3,name:"Tritiya",paksha:"Shukla",deity:"Gauri"},{id:4,name:"Chaturthi",paksha:"Shukla",deity:"Ganesha"},{id:5,name:"Panchami",paksha:"Shukla",deity:"Nagas"},{id:6,name:"Shashthi",paksha:"Shukla",deity:"Kartikeya"},{id:7,name:"Saptami",paksha:"Shukla",deity:"Surya"},{id:8,name:"Ashtami",paksha:"Shukla",deity:"Shiva / Durga"},{id:9,name:"Navami",paksha:"Shukla",deity:"Durga / Rama"},{id:10,name:"Dashami",paksha:"Shukla",deity:"Yama"},{id:11,name:"Ekadashi",paksha:"Shukla",deity:"Vishnu"},{id:12,name:"Dwadashi",paksha:"Shukla",deity:"Vishnu"},{id:13,name:"Trayodashi",paksha:"Shukla",deity:"Kamadeva"},{id:14,name:"Chaturdashi",paksha:"Shukla",deity:"Shiva"},{id:15,name:"Purnima",paksha:"Shukla",deity:"Chandra"},{id:16,name:"Prathama",paksha:"Krishna",deity:"Agni"},{id:17,name:"Dwitiya",paksha:"Krishna",deity:"Brahma"},{id:18,name:"Tritiya",paksha:"Krishna",deity:"Gauri"},{id:19,name:"Chaturthi",paksha:"Krishna",deity:"Ganesha"},{id:20,name:"Panchami",paksha:"Krishna",deity:"Nagas"},{id:21,name:"Shashthi",paksha:"Krishna",deity:"Kartikeya"},{id:22,name:"Saptami",paksha:"Krishna",deity:"Surya"},{id:23,name:"Ashtami",paksha:"Krishna",deity:"Shiva / Durga"},{id:24,name:"Navami",paksha:"Krishna",deity:"Durga"},{id:25,name:"Dashami",paksha:"Krishna",deity:"Yama"},{id:26,name:"Ekadashi",paksha:"Krishna",deity:"Vishnu"},{id:27,name:"Dwadashi",paksha:"Krishna",deity:"Vishnu"},{id:28,name:"Trayodashi",paksha:"Krishna",deity:"Kamadeva"},{id:29,name:"Chaturdashi",paksha:"Krishna",deity:"Shiva"},{id:30,name:"Amavasya",paksha:"Krishna",deity:"Pitrus"}],ya=[{id:1,name:"Ashwini",deity:"Ashwini Kumaras",lord:"Ketu"},{id:2,name:"Bharani",deity:"Yama",lord:"Venus"},{id:3,name:"Krittika",deity:"Agni",lord:"Sun"},{id:4,name:"Rohini",deity:"Brahma",lord:"Moon"},{id:5,name:"Mrigashira",deity:"Soma",lord:"Mars"},{id:6,name:"Ardra",deity:"Rudra",lord:"Rahu"},{id:7,name:"Punarvasu",deity:"Aditi",lord:"Jupiter"},{id:8,name:"Pushya",deity:"Brihaspati",lord:"Saturn"},{id:9,name:"Ashlesha",deity:"Sarpa",lord:"Mercury"},{id:10,name:"Magha",deity:"Pitrus",lord:"Ketu"},{id:11,name:"Purva Phalguni",deity:"Bhaga",lord:"Venus"},{id:12,name:"Uttara Phalguni",deity:"Aryaman",lord:"Sun"},{id:13,name:"Hasta",deity:"Savitr",lord:"Moon"},{id:14,name:"Chitra",deity:"Vishwakarma",lord:"Mars"},{id:15,name:"Swati",deity:"Vayu",lord:"Rahu"},{id:16,name:"Vishakha",deity:"Indragni",lord:"Jupiter"},{id:17,name:"Anuradha",deity:"Mitra",lord:"Saturn"},{id:18,name:"Jyeshtha",deity:"Indra",lord:"Mercury"},{id:19,name:"Moola",deity:"Nirriti",lord:"Ketu"},{id:20,name:"Purva Ashadha",deity:"Apas",lord:"Venus"},{id:21,name:"Uttara Ashadha",deity:"Vishwedevas",lord:"Sun"},{id:22,name:"Shravana",deity:"Vishnu",lord:"Moon"},{id:23,name:"Dhanishtha",deity:"Vasus",lord:"Mars"},{id:24,name:"Shatabhisha",deity:"Varuna",lord:"Rahu"},{id:25,name:"Purva Bhadrapada",deity:"Aja Ekapada",lord:"Jupiter"},{id:26,name:"Uttara Bhadrapada",deity:"Ahirbudhnya",lord:"Saturn"},{id:27,name:"Revati",deity:"Pushan",lord:"Mercury"}],va=["Vishkambha","Priti","Ayushman","Saubhagya","Shobhana","Atiganda","Sukarma","Dhriti","Shula","Ganda","Vriddhi","Dhruva","Vyaghata","Harshana","Vajra","Siddhi","Vyatipata","Variyan","Parigha","Shiva","Siddha","Sadhya","Shubha","Shukla","Brahma","Indra","Vaidhriti"],p=[{id:1,name:"Mesha",english:"Aries",lord:"Mars"},{id:2,name:"Vrishabha",english:"Taurus",lord:"Venus"},{id:3,name:"Mithuna",english:"Gemini",lord:"Mercury"},{id:4,name:"Karkataka",english:"Cancer",lord:"Moon"},{id:5,name:"Simha",english:"Leo",lord:"Sun"},{id:6,name:"Kanya",english:"Virgo",lord:"Mercury"},{id:7,name:"Tula",english:"Libra",lord:"Venus"},{id:8,name:"Vrishchika",english:"Scorpio",lord:"Mars"},{id:9,name:"Dhanu",english:"Sagittarius",lord:"Jupiter"},{id:10,name:"Makara",english:"Capricorn",lord:"Saturn"},{id:11,name:"Kumbha",english:"Aquarius",lord:"Saturn"},{id:12,name:"Meena",english:"Pisces",lord:"Jupiter"}],fa=[{id:0,name:"Ravivara",english:"Sunday",lord:"Surya"},{id:1,name:"Somavara",english:"Monday",lord:"Chandra"},{id:2,name:"Mangalavara",english:"Tuesday",lord:"Mangala"},{id:3,name:"Budhavara",english:"Wednesday",lord:"Budha"},{id:4,name:"Guruvara",english:"Thursday",lord:"Brihaspati"},{id:5,name:"Shukravara",english:"Friday",lord:"Shukra"},{id:6,name:"Shanivara",english:"Saturday",lord:"Shani"}],O=Math.PI/180,N=180/Math.PI;function o(r){let a=r%360;return a<0&&(a+=360),a}function u(r){return Math.sin(r*O)}function z(r){return Math.cos(r*O)}function W(r){return Math.tan(r*O)}function Z(r,a,e,t=12){a<=2&&(r-=1,a+=12);const i=Math.floor(r/100),n=2-i+Math.floor(i/4);return Math.floor(365.25*(r+4716))+Math.floor(30.6001*(a+1))+e+t/24+n-1524.5}function ba(r){const a=(r-2451545)/36525;return 23.856+1.396042*a+308e-6*a*a}function Q(r){const a=(r-2451545)/36525,e=o(280.46646+36000.76983*a+3032e-7*a*a),t=o(357.52911+35999.05029*a-1537e-7*a*a),i=(1.914602-.004817*a-14e-6*a*a)*u(t)+(.019993-101e-6*a)*u(2*t)+289e-6*u(3*t),n=o(e+i),l=125.04-1934.136*a,c=o(n-.00569-.00478*u(l)),b=23.439291-.0130042*a+.00256*z(l),S=o(Math.atan2(z(b)*u(c),z(c))*N),m=Math.asin(u(b)*u(c))*N;return{lon:c,ra:S,dec:m}}function ka(r){const a=(r-2451545)/36525,e=o(218.3164477+481267.88123421*a),t=o(297.8501921+445267.1114034*a),i=o(357.5291092+35999.0502909*a),n=o(134.9633964+477198.8675055*a),l=o(93.272095+483202.0175233*a);let c=6.288774*u(n)+1.274027*u(2*t-n)+.658314*u(2*t)+.213618*u(2*n)-.185116*u(i)-.114332*u(2*l);return{lon:o(e+c)}}function Sa(r,a,e,t,i,n){const l=Z(r,a,e,12-n),c=Q(l),b=(z(90.8333)-u(t)*u(c.dec))/(z(t)*z(c.dec));let S=!0,m=0;b>1||b<-1?S=!1:m=Math.acos(b)*N;const $=(l-2451545)/36525,s=o(357.52911+35999.05029*$),v=o(280.46646+36000.76983*$),M=.016708634-42037e-9*$,E=W(23.439291/2)*W(23.439291/2),I=(E*u(2*v)-2*M*u(s)+4*M*E*u(s)*z(2*v)-.5*E*E*u(4*v)-1.25*M*M*u(2*s))*4,d=(720-4*i-I)/60,A=d-m*4/60,T=d+m*4/60,y=(A+n+24)%24,k=(T+n+24)%24,w=(d+n+24)%24;return{sunrise:y,sunset:k,solarNoon:w,hasSun:S}}function g(r){let a=Math.round(r*60);a=(a+1440)%1440;const e=Math.floor(a/60),t=a%60,i=e>=12?"PM":"AM",n=e%12===0?12:e%12,l=t<10?`0${t}`:t;return`${n}:${l} ${i}`}function wa(r,a){const e=r.getFullYear(),t=r.getMonth()+1,i=r.getDate(),{lat:n,lon:l,tz_offset:c}=a,h=Sa(e,t,i,n,l,c),b=Z(e,t,i,h.sunrise-c),S=ba(b),m=Q(b),$=ka(b),s=o(m.lon-S),v=o($.lon-S),M=o($.lon-m.lon),E=Math.floor(M/12),I=M%12/12*100,d=pa[E%30],A=Math.floor(v/(360/27)),T=v%(360/27)/(360/27)*100,y=Math.floor(v%(360/27)/(360/108))+1,k=ya[A%27],w=o(s+v),V=Math.floor(w/(360/27)),X=va[V%27],j=Math.floor(M/6);let R="";if(j===0)R="Kintughna";else if(j>=57){const C=j-57;R=["Shakuni","Chatushpada","Naga"][C]||"Kintughna"}else R=["Bava","Balava","Kaulava","Taitila","Gara","Vanija","Vishti (Bhadra)"][(j-1)%7];const L=r.getDay(),_=fa[L],K=(h.sunset-h.sunrise+24)%24,x=K/8,aa=[7,1,6,4,5,3,2],U=h.sunrise+aa[L]*x,ea=U+x,ta=[4,3,2,1,0,6,5],F=h.sunrise+ta[L]*x,ia=F+x,na=[6,5,4,3,2,1,0],J=h.sunrise+na[L]*x,ra=J+x,q=K/15,H=h.sunrise+7*q,sa=H+q,oa=(h.sunrise-96/60+24)%24,da=(h.sunrise-48/60+24)%24,la=Math.floor(s/30),ha=Math.floor(v/30),P=p[la%12],D=p[ha%12],ca=[{name:"Surya (Sun)",siderealLon:s,rashi:P.name,rashiEnglish:P.english,degInRashi:(s%30).toFixed(2)},{name:"Chandra (Moon)",siderealLon:v,rashi:D.name,rashiEnglish:D.english,degInRashi:(v%30).toFixed(2)},{name:"Mangala (Mars)",siderealLon:o(s*.53+45),rashi:p[Math.floor((s*.53+45)/30)%12].name,rashiEnglish:p[Math.floor((s*.53+45)/30)%12].english,degInRashi:((s*.53+45)%30).toFixed(2)},{name:"Budha (Mercury)",siderealLon:o(s+12),rashi:p[Math.floor((s+12)/30)%12].name,rashiEnglish:p[Math.floor((s+12)/30)%12].english,degInRashi:((s+12)%30).toFixed(2)},{name:"Brihaspati (Jupiter)",siderealLon:o(s*.08+82),rashi:p[Math.floor((s*.08+82)/30)%12].name,rashiEnglish:p[Math.floor((s*.08+82)/30)%12].english,degInRashi:((s*.08+82)%30).toFixed(2)},{name:"Shukra (Venus)",siderealLon:o(s-24),rashi:p[Math.floor((s-24+360)/30)%12].name,rashiEnglish:p[Math.floor((s-24+360)/30)%12].english,degInRashi:(o(s-24)%30).toFixed(2)},{name:"Shani (Saturn)",siderealLon:o(s*.03+338),rashi:p[Math.floor((s*.03+338)/30)%12].name,rashiEnglish:p[Math.floor((s*.03+338)/30)%12].english,degInRashi:((s*.03+338)%30).toFixed(2)},{name:"Rahu (North Node)",siderealLon:o(360-(m.lon*.05+115)),rashi:p[Math.floor(o(360-(m.lon*.05+115))/30)%12].name,rashiEnglish:p[Math.floor(o(360-(m.lon*.05+115))/30)%12].english,degInRashi:(o(360-(m.lon*.05+115))%30).toFixed(2)},{name:"Ketu (South Node)",siderealLon:o(360-(m.lon*.05+115)+180),rashi:p[Math.floor(o(360-(m.lon*.05+115)+180)/30)%12].name,rashiEnglish:p[Math.floor(o(360-(m.lon*.05+115)+180)/30)%12].english,degInRashi:(o(360-(m.lon*.05+115)+180)%30).toFixed(2)}],ua=[["Uthi","Amrutha","Rogam","Labham","Visham","Sugam","Choram","Bandham"],["Amrutha","Rogam","Labham","Visham","Sugam","Choram","Bandham","Uthi"],["Rogam","Labham","Visham","Sugam","Choram","Bandham","Uthi","Amrutha"],["Labham","Visham","Sugam","Choram","Bandham","Uthi","Amrutha","Rogam"],["Sugam","Choram","Bandham","Uthi","Amrutha","Rogam","Labham","Visham"],["Bandham","Uthi","Amrutha","Rogam","Labham","Visham","Sugam","Choram"],["Choram","Bandham","Uthi","Amrutha","Rogam","Labham","Visham","Sugam"]][L].map((C,B)=>({name:C,isGood:["Amrutha","Labham","Sugam","Uthi"].includes(C),start:g(h.sunrise+B*x),end:g(h.sunrise+(B+1)*x)})),ma=[["Udveg","Char","Labh","Amrit","Kaal","Shubh","Rog","Udveg"],["Amrit","Kaal","Shubh","Rog","Udveg","Char","Labh","Amrit"],["Rog","Udveg","Char","Labh","Amrit","Kaal","Shubh","Rog"],["Labh","Amrit","Kaal","Shubh","Rog","Udveg","Char","Labh"],["Shubh","Rog","Udveg","Char","Labh","Amrit","Kaal","Shubh"],["Char","Labh","Amrit","Kaal","Shubh","Rog","Udveg","Char"],["Kaal","Shubh","Rog","Udveg","Char","Labh","Amrit","Kaal"]][L].map((C,B)=>({name:C,isGood:["Shubh","Labh","Amrit","Char"].includes(C),start:g(h.sunrise+B*x),end:g(h.sunrise+(B+1)*x)}));return{date:`${e}-${String(t).padStart(2,"0")}-${String(i).padStart(2,"0")}`,city:a.name,country:a.country,coordinates:`${a.lat.toFixed(4)}° N, ${a.lon.toFixed(4)}° E`,ayanamsa:S.toFixed(4),sunrise:g(h.sunrise),sunset:g(h.sunset),solarNoon:g(h.solarNoon),dayDuration:`${Math.floor(K)}h ${Math.round(K%1*60)}m`,tithi:{name:`${d.paksha} ${d.name}`,paksha:d.paksha,deity:d.deity,progress:Math.round(I)},nakshatra:{name:k.name,pada:y,deity:k.deity,lord:k.lord,progress:Math.round(T)},yoga:X,karana:R,vaar:{sanskrit:_.name,english:_.english,lord:_.lord},sunRashi:`${P.name} (${P.english})`,moonRashi:`${D.name} (${D.english})`,muhurtas:{rahuKalam:`${g(U)} – ${g(ea)}`,yamagandam:`${g(F)} – ${g(ia)}`,gulikaKalam:`${g(J)} – ${g(ra)}`,abhijitMuhurta:L===3?"None (Wednesdays prohibited)":`${g(H)} – ${g(sa)}`,brahmaMuhurta:`${g(oa)} – ${g(da)}`},gowriPanchangam:ua,choghadiya:ma,planets:ca}}const Ma=[{code:"sa",name:"Sanskrit",native:"संस्कृतम्",script:"Devanagari"},{code:"hi",name:"Hindi",native:"हिन्दी",script:"Devanagari"},{code:"mr",name:"Marathi",native:"मराठी",script:"Devanagari"},{code:"ta",name:"Tamil",native:"தமிழ்",script:"Tamil"},{code:"te",name:"Telugu",native:"తెలుగు",script:"Telugu"},{code:"kn",name:"Kannada",native:"ಕನ್ನಡ",script:"Kannada"},{code:"ml",name:"Malayalam",native:"മലയാളം",script:"Malayalam"},{code:"gu",name:"Gujarati",native:"ગુજરાતી",script:"Gujarati"},{code:"bn",name:"Bengali",native:"বাংলা",script:"Bengali"},{code:"or",name:"Odia",native:"ଓଡ଼ିଆ",script:"Odia"},{code:"en",name:"English (IAST)",native:"English (IAST)",script:"Latin"}],G={अ:"a",आ:"ā",इ:"i",ई:"ī",उ:"u",ऊ:"ū",ऋ:"ṛ",ॠ:"ṝ",ऌ:"ḷ",ॡ:"ḹ",ए:"e",ऐ:"ai",ओ:"o",औ:"au","ा":"ā","ि":"i","ी":"ī","ु":"u","ू":"ū","ृ":"ṛ","ॄ":"ṝ","ॢ":"ḷ","ॣ":"ḹ","े":"e","ै":"ai","ो":"o","ौ":"au","ं":"ṃ","ः":"ḥ","्":"",ऽ:"'",क:"ka",ख:"kha",ग:"ga",घ:"gha",ङ:"ṅa",च:"ca",छ:"cha",ज:"ja",झ:"jha",ञ:"ña",ट:"ṭa",ठ:"ṭha",ड:"ḍa",ढ:"ḍha",ण:"ṇa",त:"ta",थ:"tha",द:"da",ध:"dha",न:"na",प:"pa",फ:"pha",ब:"ba",भ:"bha",म:"ma",य:"ya",र:"ra",ल:"la",व:"va",श:"śa",ष:"ṣa",स:"sa",ह:"ha",ळ:"ḷa",क्ष:"kṣa",ज्ञ:"jña","०":"0","१":"1","२":"2","३":"3","४":"4","५":"5","६":"6","७":"7","८":"8","९":"9"};function Aa(r,a,e){let t="";for(let i=0;i<r.length;i++){const n=r.charCodeAt(i);if(n>=2305&&n<=2416){let l=n+a;if(e==="ta"){const c=r[i],h={ख:"க",ग:"க",घ:"க",ङ:"ங",छ:"ச",ज:"ஜ",झ:"ச",ञ:"ஞ",ठ:"ட",ड:"ட",ढ:"ட",थ:"த",द:"த",ध:"த",फ:"ப",ब:"ப",भ:"ப",श:"ஶ",ष:"ஷ",स:"ஸ",ह:"ஹ",क्ष:"க்ஷ",ऋ:"ரி","ृ":"்ரி",ॐ:"ஓம்"};if(h[c]){t+=h[c];continue}}if(e==="bn"){if(r[i]==="व"){t+="ব";continue}if(r[i]==="र"){t+="র";continue}}if(e==="or"&&r[i]==="व"){t+="ୱ";continue}t+=String.fromCharCode(l)}else t+=r[i]}return t}function Ta(r){let a="",e=0;for(;e<r.length;){const t=r[e],i=r[e+1];if(t==="्"){e++;continue}if(G[t]){let n=G[t];if(n.endsWith("a")){if(i&&["ा","ि","ी","ु","ू","ृ","ॄ","े","ै","ो","ौ"].includes(i)){n=n.slice(0,-1)+G[i],e+=2,a+=n;continue}else if(i==="्"){n=n.slice(0,-1),e+=2,a+=n;continue}}a+=n,e++}else a+=t,e++}return a}function f(r,a){if(!r)return"";if(a==="sa"||a==="hi"||a==="mr")return r;if(a==="en")return Ta(r);const t={bn:128,gu:384,or:512,ta:640,te:768,kn:896,ml:1024}[a];return t!==void 0?Aa(r,t,a):r}const xa=[{id:"gayatri-mantra",title:"Gayatri Mantra",source:"Rigveda Samhita (Mandala 3, Sukta 62, Mantra 10)",deity:"Savitr (The Divine Sun of Consciousness)",meter:"Gayatri (24 syllables)",devanagari:`ॐ भूर्भुवः॒ स्वः॒ ।
तत्सवितुर्वरे॑ण्यं॒ भर्गो॑ दे॒वस्य॑ धीमहि ।
धियो॒ यो नः॑ प्रचो॒दया॑त् ॥`,iast:`oṃ bhūr bhuvaḥ svaḥ ।
tat savitur vareṇyaṃ bhargo devasya dhīmahi ।
dhiyo yo naḥ pracodayāt ॥`,sabdartha:[{word:"ॐ (Om)",meaning:"The primordial sound, supreme cosmic reality"},{word:"भूः (Bhuh)",meaning:"The physical realm, earth, embodiment of vital breath"},{word:"भुवः (Bhuvah)",meaning:"The astral plane, intermediate space, destroyer of suffering"},{word:"स्वः (Svah)",meaning:"The celestial plane, heaven, embodiment of bliss"},{word:"तत् (Tat)",meaning:"That ultimate transcendental Reality"},{word:"सवितुः (Savituh)",meaning:"Of the Divine Sun, the Creator and Source of all illumination"},{word:"वरेण्यम् (Varenyam)",meaning:"Most adorable, supreme, worthy of worship"},{word:"भर्गः (Bhargah)",meaning:"Effulgence, radiant spiritual light that burns away ignorance"},{word:"देवस्य (Devasya)",meaning:"Of the Divine Being, radiant Lord"},{word:"धीमहि (Dhimahi)",meaning:"We meditate upon"},{word:"धियः (Dhiyah)",meaning:"Our intellect, spiritual discernment, consciousness"},{word:"यः (Yah)",meaning:"Who, that Divine Light"},{word:"नः (Nah)",meaning:"Our (collective)"},{word:"प्रचोदयात् (Prachodayat)",meaning:"May awaken, guide, and inspire onward"}],translation:"We meditate upon the supreme, most adorable radiance of that Divine Creator, the Sun of consciousness. May that effulgent Light illuminate, guide, and inspire our spiritual intellect and discernment.",purport:"The Gayatri Mantra is the crown jewel of Vedic revelation. Revealed by Brahmarshi Vishwamitra, it is not a request for worldly wealth or physical triumph, but a sacred invocation for the awakening of higher intellect (Buddhi). When chanted during Sandhyavandanam (dawn, noon, and dusk), its acoustic frequency purifies the nervous system and dissolves mental lethargy."},{id:"maha-mrityunjaya",title:"Maha Mrityunjaya Mantra (Rudra Mantra)",source:"Rigveda Samhita (Mandala 7, Sukta 59, Mantra 12)",deity:"Tryambaka (Lord Shiva — The Three-Eyed One)",meter:"Anushtubh",devanagari:`ॐ त्र्य॑म्बकं यजामहे सुग॒न्धिं पु॑ष्टि॒वर्ध॑नम् ।
उ॒र्वा॒रु॒कमि॑व॒ बन्ध॑नान्मृ॒त्योर्मु॑क्षीय॒ माऽमृता॑त् ॥`,iast:`oṃ tryambakaṃ yajāmahe sugandhiṃ puṣṭi-vardhanam ।
urvārukam iva bandhanān mṛtyor mukṣīya mā'mṛtāt ॥`,sabdartha:[{word:"त्र्यम्बकम् (Tryambakam)",meaning:"The Three-Eyed Lord (Shiva), perceiver of past, present, and future"},{word:"यजामहे (Yajamahe)",meaning:"We worship, revere, and adore"},{word:"सुगन्धिम् (Sugandhim)",meaning:"The fragrant one, emitting the fragrance of divine virtue"},{word:"पुष्टिवर्धनम् (Pushti-vardhanam)",meaning:"The nourisher of all life, who enhances vitality and spiritual strength"},{word:"उर्वारुकम् (Urvarukam)",meaning:"A ripe melon / cucumber"},{word:"इव (Iva)",meaning:"Just like"},{word:"बन्धनात् (Bandhanat)",meaning:"From its stem / bondage of attachment"},{word:"मृत्योः (Mrityoh)",meaning:"From death, physical mortality, and cycle of rebirth"},{word:"मुक्षीय (Mukshiya)",meaning:"May You liberate us"},{word:"मा (Ma)",meaning:"Not"},{word:"अमृतात् (Amritat)",meaning:"From immortality / divine truth"}],translation:"We worship the Three-Eyed Lord Shiva, who is fragrant with transcendental virtue and who nourishes all living beings. Just as a ripe melon naturally separates effortlessly from its vine, may He liberate us from the bondage of death and mortality, without separating us from Immortality.",purport:"Revealed by Rishi Markandeya, this profound healing mantra conquers the fear of death and bodily decay. The metaphor of the melon (Urvaruka) is sublime: when a fruit ripens completely, it detaches from the creeper effortlessly without any violent tugging. Similarly, when a devotee ripens in spiritual wisdom and devotion, the soul detaches naturally from ego and fear of bodily demise."},{id:"shanti-mantra",title:"Sarve Bhavantu Sukhinah (Universal Peace Prayer)",source:"Brihadaranyaka Upanishad Tradition / Garuda Purana",deity:"Paramatman (Universal Cosmic Consciousness)",meter:"Anushtubh",devanagari:`ॐ सर्वे॑ भवन्तु सु॒खिनः॑ सर्वे॑ सन्तु निराम॒याः ।
सर्वे॑ भ॒द्राणि॑ पश्यन्तु॒ मा क॑श्चिद्दुःखभा॒ग्भवे॑त् ॥
ॐ शान्तिः॒ शान्तिः॒ शान्तिः॑ ॥`,iast:`oṃ sarve bhavantu sukhinaḥ sarve santu nirāmayāḥ ।
sarve bhadrāṇi paśyantu mā kaścid duḥkha-bhāg bhavet ॥
oṃ śāntiḥ śāntiḥ śāntiḥ ॥`,sabdartha:[{word:"सर्वे (Sarve)",meaning:"May all beings everywhere"},{word:"भवन्तु (Bhavantu)",meaning:"Become"},{word:"सुखिनः (Sukhinah)",meaning:"Happy, peaceful, and fulfilled"},{word:"सन्तु (Santu)",meaning:"May they be"},{word:"निरामयाः (Niramayah)",meaning:"Free from disease, afflictions, and illness"},{word:"भद्राणि (Bhadrani)",meaning:"Auspiciousness, goodness, spiritual nobility"},{word:"पश्यन्तु (Pashyantu)",meaning:"May they behold and experience"},{word:"मा (Ma)",meaning:"May not"},{word:"कश्चित् (Kashchit)",meaning:"Anyone, any soul"},{word:"दुःखभाग् (Duhkha-bhag)",meaning:"Partaker of sorrow or distress"},{word:"भवेत् (Bhavet)",meaning:"Become"},{word:"शान्तिः (Shantih)",meaning:"Peace across physical, astral, and spiritual realms"}],translation:"May all beings everywhere be happy. May all beings be free from disease and illness. May all behold only auspiciousness and goodness in one another. May no one suffer or be partaker of sorrow. Om Peace, Peace, Peace.",purport:"This universal benediction exemplifies the core Sanatana Dharma principle of Vasudhaiva Kutumbakam (the entire cosmos is one single family). It prays not just for humans, but for animals, plants, and all unseen entities across the multidimensional universe."},{id:"gita-2-47",title:"Nishkama Karma (Selfless Duty)",source:"Bhagavad Gita (Chapter 2, Verse 47)",deity:"Bhagavan Sri Krishna",meter:"Anushtubh",devanagari:`कर्मण्येवाधिकारस्ते मा फलेषु कदाचन ।
मा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि ॥`,iast:`karmaṇy-evādhikāras-te mā phaleṣu kadācana ।
mā karma-phala-hetur-bhūr-mā te saṅgo'stv-akarmaṇi ॥`,sabdartha:[{word:"कर्मणि (Karmani)",meaning:"In prescribed duty and righteous action alone"},{word:"एव (Eva)",meaning:"Only, certainly"},{word:"अधिकारः (Adhikarah)",meaning:"Your rightful claim, responsibility, and prerogative"},{word:"ते (Te)",meaning:"Your"},{word:"मा (Ma)",meaning:"Never, not at all"},{word:"फलेषु (Phaleshu)",meaning:"In the fruits or outcome of action"},{word:"कदाचन (Kadachana)",meaning:"At any time"},{word:"कर्मफलहेतुः (Karma-phala-hetuh)",meaning:"Motivated solely by results"},{word:"भूः (Bhuh)",meaning:"Become"},{word:"सङ्गः (Sangah)",meaning:"Attachment, inertia"},{word:"अस्तु (Astu)",meaning:"Let there be"},{word:"अकर्मणि (Akarmani)",meaning:"In inaction or neglect of duty"}],translation:"You have a right only to perform your prescribed duty, but never to the fruits of your actions. Let not the fruit of action be your motive, nor let your attachment be toward inaction.",purport:"Spoken by Lord Krishna to Arjuna on the battlefield of Kurukshetra, this verse establishes the foundational philosophy of Karma Yoga. Psychologically, anxiety arises when our focus is fixated on future rewards rather than excellence in present execution. By offering the fruits of labor to the Divine, the mind attains profound serenity and freedom from burnout."},{id:"vishnu-sahasranama-dhyanam",title:"Sri Vishnu Sahasranama Stotram (Dhyana Sloka)",source:"Mahabharata (Anushasana Parva, Section 149)",deity:"Sri Maha Vishnu",meter:"Anushtubh",devanagari:`शान्ताकारं भुजगशयनं पद्मनाभं सुरेशं
विश्वाधारं गगनसदृशं मेघवर्णं शुभाङ्गम् ।
लक्ष्मीकान्तं कमलनयनं योगिभिर्ध्यानगम्यं
वन्दे विष्णुं भवभयहरं सर्वलोकैकनाथम् ॥`,iast:`śāntākāraṃ bhujaga-śayanaṃ padma-nābhaṃ sureśaṃ
viśvādhāraṃ gagana-sadṛśaṃ megha-varṇaṃ śubhāṅgam ।
lakṣmī-kāntaṃ kamala-nayanaṃ yogibhir-dhyāna-gamyaṃ
vande viṣṇuṃ bhava-bhaya-haraṃ sarva-lokaika-nātham ॥`,sabdartha:[{word:"शान्ताकारम् (Shantakaram)",meaning:"Of peaceful, serene, tranquil form"},{word:"भुजगशयनम् (Bhujaga-shayanam)",meaning:"Resting upon the divine serpent Shesha / Ananta"},{word:"पद्मनाभम् (Padmanabham)",meaning:"From whose navel blossoms the cosmic lotus of creation"},{word:"सुरेशम् (Suresham)",meaning:"Lord of the celestials and devas"},{word:"विश्वाधारम् (Vishvadharam)",meaning:"The ultimate substratum and support of the entire universe"},{word:"गगनसदृशम् (Gagana-sadrisham)",meaning:"All-pervading and vast like the boundless sky"},{word:"मेघवर्णम् (Megha-varnam)",meaning:"Having the dark, compassionate complexion of rain clouds"},{word:"शुभाङ्गम् (Shubhangam)",meaning:"Of exquisitely auspicious and beautiful limbs"},{word:"लक्ष्मीकान्तम् (Lakshmi-kantam)",meaning:"The beloved consort of Goddess Lakshmi"},{word:"कमलनयनम् (Kamala-nayanam)",meaning:"Having lotus-shaped, merciful eyes"},{word:"योगिभिर्ध्यानगम्यम् (Yogibhir-dhyana-gamyam)",meaning:"Attainable by yogis through deep meditative absorption"},{word:"वन्दे (Vande)",meaning:"I bow down to, I revere"},{word:"विष्णुम् (Vishnum)",meaning:"Lord Vishnu, the All-Pervading Preserver"},{word:"भवभयहरम् (Bhava-bhaya-haram)",meaning:"The dispeller of the fears of worldly existence"},{word:"सर्वलोकैकनाथम् (Sarva-lokaika-natham)",meaning:"The sole supreme Lord of all cosmic realms"}],translation:"I bow to Lord Vishnu, the embodiment of serenity, who reclines upon the serpent Ananta, from whose navel emerges the cosmic lotus of creation, and who is the Lord of all celestials. He sustains the universe, is all-pervading like space, dark like rain-bearing clouds, and endowed with auspicious form. The beloved of Goddess Lakshmi, with eyes like blooming lotuses, realized by sages in deep meditation—I bow to that Vishnu who eradicates the fear of worldly existence, the sole sovereign of all realms.",purport:"Composed by Bhishma Pitamaha upon his bed of arrows, the Vishnu Sahasranama is praised by Adi Shankaracharya as the supreme tool for neutralizing planetary afflictions (Graha Doshas) and purifying subconscious impressions (Samskaras)."}],Y=[{id:"lion-and-hare",title:"The Lion and the Clever Hare",collection:"Panchatantra (Book 1: Mitra-bheda — The Loss of Friends)",author:"Pandit Vishnu Sharma (circa 300 BCE)",sanskritEpigraph:`बुद्धिर्यस्य बलं तस्य निर्बुद्धेस्तु कुतो बलम् ।
वने सिंहो मदोन्मत्तः शशकेन निपातितः ॥`,epigraphTranslation:"He who possesses intellect possesses true power; what strength does one without wisdom have? A mighty lion intoxicated with pride was slain in the forest by a humble hare.",summary:"Bhasuraka, a ferocious lion, slaughtered animals indiscriminately. The terrified animals agreed to send one prey daily. When it was the little hare's turn, he arrived late and claimed another lion had stopped him. Bhasuraka furiously demanded to see the rival. The hare led the lion to a deep well; seeing his own reflection and hearing his echo, the furious lion leaped in and perished.",vocabulary:[{term:"Bhasuraka (भासुरक)",meaning:"Shining or fierce; the name of the lion"},{term:"Yukti (युक्ति)",meaning:"Strategic resourcefulness; applying intellect over brute force"},{term:"Mada (मद)",meaning:"Blind arrogance, hubris arising from physical power"}],moral:"Wisdom and presence of mind conquer brute physical force. Arrogance clouds perception, making even the mighty destroy themselves.",quiz:{question:"In situations where you face an overwhelming challenge against which you have no physical leverage, what is the core Vedic strategic response?",options:["React in panic and despair","Use calm discernment (Buddhi), self-control, and the adversary's own arrogance against them","Surrender completely without thinking"],correctIndex:1,explanation:"Vedic statecraft (Niti Shastra) teaches that Buddhi (spiritual intellect) is superior to physical might (Bahu-bala). The hare did not fight the lion; he allowed the lion's own rage and illusion (Maya) to cause his downfall."}},{id:"monkey-and-crocodile",title:"The Monkey and the Crocodile",collection:"Panchatantra (Book 4: Labdhapranasham — Loss of Gains)",author:"Pandit Vishnu Sharma",sanskritEpigraph:`आपत्काले तु संप्राप्ते यस्य बुद्धिर्न हीयते ।
स एव तरते दुर्गाणि जलबद्ध इव प्लवः ॥`,epigraphTranslation:"When calamity strikes, he whose presence of mind does not waver crosses over treacherous perils, just like a sturdy raft upon tempestuous waters.",summary:"Raktamukha, a monkey living in a rose-apple tree by the river, befriended Karalamukha, a crocodile, sharing sweet fruits. The crocodile's greedy wife desired to eat the monkey's heart. Trapped mid-river on the crocodile's back, the monkey remained calm and claimed he had left his heart safe inside the hollow of the tree. The foolish crocodile swam back, allowing the monkey to leap to safety.",vocabulary:[{term:"Pratyutpannamati (प्रत्युत्पन्नमति)",meaning:"Instantaneous presence of mind during sudden peril"},{term:"Mitra-droha (मित्रद्रोह)",meaning:"Betrayal of trust between friends"}],moral:"Presence of mind in moments of mortal danger saves life. Betrayal destroys friendship forever.",quiz:{question:"What saved the monkey when trapped in the middle of the river?",options:["Physical fighting against the crocodile","Retaining composure and using swift psychological wit","Crying out for help to other animals"],correctIndex:1,explanation:"Panic paralyzes thinking. By remaining calm and fabricating a convincing story about leaving his heart on the tree, the monkey navigated a lethal situation peacefully."}},{id:"three-idols-tenali-raman",title:"Tenali Raman and the Three Idols",collection:"Tales of Tenali Ramakrishna",author:"Folkloric Heritage of Vijayanagara Empire",sanskritEpigraph:`श्रूयतां धर्मसर्वस्वं श्रुत्वा चैवावधार्यताम् ।
आत्मनः प्रतिकूलानि परेषां न समाचरेत् ॥`,epigraphTranslation:"Listen to the essence of Dharma, and having heard it, keep it firmly in your heart: That which is painful or detrimental to oneself, never inflict upon others.",summary:"A foreign scholar presented King Krishnadevaraya with three identical golden idols, challenging the court to determine which was superior. Tenali Raman inserted a thin straw into the ear of each idol. In the first, the straw emerged from the other ear (the person who hears and instantly forgets). In the second, the straw emerged from the mouth (the person who hears a secret and immediately gossips). In the third, the straw passed directly into the heart (the noble person who hears wisdom, reflects upon it, and preserves confidence). Raman declared the third idol the best.",vocabulary:[{term:"Shravana (श्रवण)",meaning:"The art of deep, attentive spiritual listening"},{term:"Manana (मनन)",meaning:"Internal reflection, assimilating knowledge into the heart"},{term:"Nididhyasana (निदिध्यासन)",meaning:"Living and manifesting truth in daily character"}],moral:"A person's true character is revealed by how they handle what they hear: whether they leak it, gossip, or assimilate it into noble conduct.",quiz:{question:"Which type of listener did the third golden idol represent?",options:["The gossip who repeats everything they hear","The person who absorbs wisdom deeply into their heart and preserves trust","The inattentive person who lets advice pass through one ear and out the other"],correctIndex:1,explanation:"True character (Sheela) lies in deep assimilation (Manana). Spiritual seekers must be like the third idol—absorbing truth into the heart rather than broadcasting idle speech."}},{id:"satyakama-jabala",title:"Satyakama Jabala and the Voice of Truth",collection:"Chandogya Upanishad (Chapter 4, Section 4)",author:"Ancient Vedic Sage Tradition",sanskritEpigraph:`सत्यमेव जयते नानृतं
सत्येन पन्था विततो देवयानः ।`,epigraphTranslation:"Truth alone triumphs, never falsehood. By truth is paved the divine pathway of spiritual liberation.",summary:"Young Satyakama wished to study Brahmavidya under Sage Gautama. When asked his lineage (gotra), his mother Jabala candidly told him she had served many masters in her youth and did not know his lineage. Satyakama truthfully repeated this to Gautama. Overjoyed by his uncompromising honesty, the sage declared: 'None but a true Brahmana could speak such unvarnished truth.' Gautama initiated him into the highest wisdom.",vocabulary:[{term:"Satya (सत्य)",meaning:"Unyielding adherence to truth in thought, word, and deed"},{term:"Brahmavidya (ब्रह्मविद्या)",meaning:"The supreme science of Ultimate Reality"},{term:"Acharya (आचार्य)",meaning:"A spiritual preceptor who teaches through their personal conduct"}],moral:"Truthfulness is the highest pedigree. Nobility of character outweighs social circumstance or birth.",quiz:{question:"Why did Sage Gautama accept Satyakama as his prime disciple?",options:["Because he was wealthy and powerful","Because he displayed absolute truthfulness and courage about his origins","Because he performed complex rituals"],correctIndex:1,explanation:"The Upanishads emphasize that true spiritual nobility is determined by Satya (Truth) and character, not by external privilege or birth status."}}];class $a{constructor(){this.bead=0,this.rounds=0,this.totalChants=0,this.dailyTargetRounds=16,this.meruReversalMode=!0,this.soundEnabled=!0,this.vibrationEnabled=!0,this.currentMantra="ॐ नमो भगवते वासुदेवाय (Om Namo Bhagavate Vasudevaya)",this.audioCtx=null,this.loadState()}initAudio(){if(!this.audioCtx&&typeof window<"u"){const a=window.AudioContext||window.webkitAudioContext;a&&(this.audioCtx=new a)}this.audioCtx&&this.audioCtx.state==="suspended"&&this.audioCtx.resume()}playBeadSound(){if(this.soundEnabled)try{if(this.initAudio(),!this.audioCtx)return;const a=this.audioCtx.createOscillator(),e=this.audioCtx.createGain();a.type="triangle",a.frequency.setValueAtTime(440,this.audioCtx.currentTime),a.frequency.exponentialRampToValueAtTime(110,this.audioCtx.currentTime+.04),e.gain.setValueAtTime(.2,this.audioCtx.currentTime),e.gain.exponentialRampToValueAtTime(.001,this.audioCtx.currentTime+.04),a.connect(e),e.connect(this.audioCtx.destination),a.start(),a.stop(this.audioCtx.currentTime+.04)}catch{}}playTempleBell(){if(this.soundEnabled)try{if(this.initAudio(),!this.audioCtx)return;const a=this.audioCtx.currentTime,e=[880,1760,2640,3520],t=[.35,.15,.08,.03];e.forEach((i,n)=>{const l=this.audioCtx.createOscillator(),c=this.audioCtx.createGain();l.type="sine",l.frequency.setValueAtTime(i,a),c.gain.setValueAtTime(t[n],a),c.gain.exponentialRampToValueAtTime(1e-4,a+1.8),l.connect(c),c.connect(this.audioCtx.destination),l.start(a),l.stop(a+1.8)})}catch{}}triggerHaptic(a=!1){if(!(!this.vibrationEnabled||typeof navigator>"u"||!navigator.vibrate))try{a?navigator.vibrate([70,50,140]):navigator.vibrate(28)}catch{}}increment(){this.initAudio(),this.bead+=1,this.totalChants+=1;let a=!1;return this.bead>=108?(this.bead=0,this.rounds+=1,a=!0,this.playTempleBell(),this.triggerHaptic(!0)):(this.playBeadSound(),this.triggerHaptic(!1)),this.saveState(),{bead:this.bead,rounds:this.rounds,totalChants:this.totalChants,reachedMeru:a}}resetCurrentMala(){this.bead=0,this.saveState()}resetAll(){this.bead=0,this.rounds=0,this.totalChants=0,this.saveState()}saveState(){try{if(typeof localStorage>"u")return;const a={bead:this.bead,rounds:this.rounds,totalChants:this.totalChants,dailyTargetRounds:this.dailyTargetRounds,meruReversalMode:this.meruReversalMode,soundEnabled:this.soundEnabled,vibrationEnabled:this.vibrationEnabled,currentMantra:this.currentMantra,lastUpdated:new Date().toISOString()};localStorage.setItem("gurukripa_japa_state",JSON.stringify(a))}catch{}}loadState(){try{if(typeof localStorage>"u")return;const a=localStorage.getItem("gurukripa_japa_state");if(a){const e=JSON.parse(a);this.bead=e.bead||0,this.rounds=e.rounds||0,this.totalChants=e.totalChants||0,this.dailyTargetRounds=e.dailyTargetRounds||16,e.meruReversalMode!==void 0&&(this.meruReversalMode=e.meruReversalMode),e.soundEnabled!==void 0&&(this.soundEnabled=e.soundEnabled),e.vibrationEnabled!==void 0&&(this.vibrationEnabled=e.vibrationEnabled),e.currentMantra&&(this.currentMantra=e.currentMantra)}}catch{}}exportDataJSON(){const a={app:"GuruKripa",type:"japa_sadhana_backup",version:"1.0.0",exportDate:new Date().toISOString(),stats:{bead:this.bead,rounds:this.rounds,totalChants:this.totalChants,dailyTargetRounds:this.dailyTargetRounds,currentMantra:this.currentMantra}};return JSON.stringify(a,null,2)}importDataJSON(a){try{const e=JSON.parse(a);if(e.stats)return this.bead=e.stats.bead||0,this.rounds=e.stats.rounds||0,this.totalChants=e.stats.totalChants||0,e.stats.dailyTargetRounds&&(this.dailyTargetRounds=e.stats.dailyTargetRounds),e.stats.currentMantra&&(this.currentMantra=e.stats.currentMantra),this.saveState(),!0}catch{return!1}return!1}}class Ea{constructor(){this.cities=ga,this.selectedCity=this.loadSavedCity()||this.cities[0],this.selectedDate=new Date,this.selectedLang=localStorage.getItem("gk_lang")||"sa",this.currentView=this.getViewFromHash(),this.panchangTab="overview",this.slokaFontSize=1.35,this.showSabdartha=!0,this.cityModalOpen=!1,this.theme=localStorage.getItem("gk_theme")||"light",this.japaEngine=new $a,this.init()}loadSavedCity(){try{const a=localStorage.getItem("gk_selected_city");return a?JSON.parse(a):null}catch{return null}}saveCity(a){this.selectedCity=a;try{localStorage.setItem("gk_selected_city",JSON.stringify(a))}catch{}}getViewFromHash(){const a=window.location.hash.replace("#","").split("?")[0];return["panchang","stotras","japa","stories"].includes(a)?a:"panchang"}init(){document.documentElement.setAttribute("data-theme",this.theme),window.addEventListener("hashchange",()=>{this.currentView=this.getViewFromHash(),this.render()}),window.addEventListener("keydown",a=>{this.currentView==="japa"&&(a.code==="Space"||a.code==="Enter")&&(a.preventDefault(),this.handleJapaClick())}),"serviceWorker"in navigator&&window.addEventListener("load",()=>{navigator.serviceWorker.register("/sw.js").catch(()=>{})}),this.render()}toggleTheme(){this.theme=this.theme==="light"?"dark":"light",localStorage.setItem("gk_theme",this.theme),document.documentElement.setAttribute("data-theme",this.theme),this.render()}handleJapaClick(){const a=this.japaEngine.increment(),e=document.getElementById("gk-bead-number"),t=document.getElementById("gk-stat-rounds"),i=document.getElementById("gk-stat-total");e&&(e.innerText=a.bead),t&&(t.innerText=a.rounds),i&&(i.innerText=a.totalChants),a.reachedMeru&&this.japaEngine.meruReversalMode&&alert(`✨ Haribol! You have reached the sacred Sumeru (Meru) bead.
In traditional practice, do not cross the Guru bead; turn your mala around for the next round.`)}autoDetectLocation(){if(!navigator.geolocation){alert("Geolocation is not supported by your browser. Please select a city manually.");return}navigator.geolocation.getCurrentPosition(a=>{const e=a.coords.latitude,t=a.coords.longitude,i=-new Date().getTimezoneOffset()/60,n={id:"gps-current",name:"Current GPS Location",state:"Local",country:"Live Coordinates",lat:parseFloat(e.toFixed(4)),lon:parseFloat(t.toFixed(4)),tz:Intl.DateTimeFormat().resolvedOptions().timeZone||"UTC",tz_offset:i,elevation:10};this.saveCity(n),this.cityModalOpen=!1,this.render()},a=>{alert("Unable to detect GPS position: "+a.message+". Please choose your city from the list.")})}render(){const a=document.getElementById("app");a&&(a.innerHTML=`
      ${this.renderHeader()}
      <main class="gk-main">
        ${this.renderLocationBar()}
        ${this.renderAdSlot("ad-header-leaderboard","leaderboard")}
        ${this.renderViewContent()}
      </main>
      ${this.renderFooter()}
      ${this.cityModalOpen?this.renderCityModal():""}
      ${this.renderConsentBanner()}
    `,this.attachEventListeners())}renderHeader(){return`
      <header class="gk-header">
        <div class="gk-header-inner">
          <a href="#panchang" class="gk-brand">
            <span class="gk-brand-logo">🕉️</span>
            <div>
              <span class="gk-brand-title">GuruKripa</span>
              <span class="gk-brand-tagline">Vedic Panchang & Spiritual Portal</span>
            </div>
          </a>
          <ul class="gk-nav-links">
            <li><a href="#panchang" class="${this.currentView==="panchang"?"active":""}">Panchang</a></li>
            <li><a href="#stotras" class="${this.currentView==="stotras"?"active":""}">Stotras & Slokas</a></li>
            <li><a href="#japa" class="${this.currentView==="japa"?"active":""}">108 Japa Mala</a></li>
            <li><a href="#stories" class="${this.currentView==="stories"?"active":""}">Moral Stories</a></li>
          </ul>
          <div class="gk-controls">
            <select id="gk-lang-select" class="gk-select" title="Switch Sacred Script">
              ${Ma.map(a=>`
                <option value="${a.code}" ${this.selectedLang===a.code?"selected":""}>
                  ${a.native} (${a.name})
                </option>
              `).join("")}
            </select>
            <button id="gk-theme-toggle" class="gk-btn" title="Toggle Theme">
              ${this.theme==="light"?"🌙":"☀️"}
            </button>
          </div>
        </div>
      </header>
    `}renderLocationBar(){return`
      <div class="gk-location-bar">
        <div class="gk-location-info">
          <span class="gk-location-pin">📍</span>
          <div>
            <span class="gk-location-name">${this.selectedCity.name}, ${this.selectedCity.country}</span>
            <span class="gk-location-coords">(${this.selectedCity.lat.toFixed(2)}° N, ${this.selectedCity.lon.toFixed(2)}° E • UTC ${this.selectedCity.tz_offset>=0?"+":""}${this.selectedCity.tz_offset})</span>
          </div>
        </div>
        <div style="display:flex; gap:8px;">
          <button id="gk-open-city-modal" class="gk-btn">Change City</button>
          <button id="gk-auto-detect-btn" class="gk-btn gk-btn-primary">📡 Auto Detect GPS</button>
        </div>
      </div>
    `}renderViewContent(){switch(this.currentView){case"panchang":return this.renderPanchang();case"stotras":return this.renderStotras();case"japa":return this.renderJapa();case"stories":return this.renderStories();default:return this.renderPanchang()}}renderPanchang(){const a=wa(this.selectedDate,this.selectedCity);return`
      <section>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:10px;">
          <h2 style="color:var(--color-primary); font-size:1.5rem;">
            ${f("दैनिक पञ्चाङ्गम्",this.selectedLang)} — ${a.date}
          </h2>
          <div style="display:flex; align-items:center; gap:8px;">
            <label for="gk-date-picker" style="font-size:0.85rem; font-weight:600;">Date:</label>
            <input type="date" id="gk-date-picker" class="gk-select" value="${a.date}">
          </div>
        </div>

        <div class="gk-tabs">
          <button class="gk-tab-btn ${this.panchangTab==="overview"?"active":""}" data-tab="overview">Daily Limbs</button>
          <button class="gk-tab-btn ${this.panchangTab==="gowri"?"active":""}" data-tab="gowri">Gowri Panchangam</button>
          <button class="gk-tab-btn ${this.panchangTab==="choghadiya"?"active":""}" data-tab="choghadiya">Choghadiya</button>
          <button class="gk-tab-btn ${this.panchangTab==="planets"?"active":""}" data-tab="planets">Planetary Positions</button>
        </div>

        ${this.panchangTab==="overview"?this.renderPanchangOverview(a):""}
        ${this.panchangTab==="gowri"?this.renderGowriTable(a.gowriPanchangam):""}
        ${this.panchangTab==="choghadiya"?this.renderChoghadiyaTable(a.choghadiya):""}
        ${this.panchangTab==="planets"?this.renderPlanetsTable(a.planets,a.ayanamsa):""}

        ${this.renderAdSlot("ad-panchang-inline","rectangle")}
      </section>
    `}renderPanchangOverview(a){return`
      <div class="gk-panchang-hero">
        <div class="gk-card">
          <div class="gk-card-title"><span>Sunrise / Sunset</span><span>☀️</span></div>
          <div class="gk-card-value">${a.sunrise} — ${a.sunset}</div>
          <div class="gk-card-meta">Solar Noon: ${a.solarNoon} (Day Duration: ${a.dayDuration})</div>
        </div>
        <div class="gk-card">
          <div class="gk-card-title"><span>Tithi (Lunar Day)</span><span>🌙</span></div>
          <div class="gk-card-value">${f(a.tithi.name,this.selectedLang)}</div>
          <div class="gk-card-meta">Paksha: ${a.tithi.paksha} • Progress: ${a.tithi.progress}% • Deity: ${a.tithi.deity}</div>
        </div>
        <div class="gk-card">
          <div class="gk-card-title"><span>Nakshatra (Lunar Mansion)</span><span>✨</span></div>
          <div class="gk-card-value">${f(a.nakshatra.name,this.selectedLang)} (Pada ${a.nakshatra.pada})</div>
          <div class="gk-card-meta">Lord: ${a.nakshatra.lord} • Deity: ${a.nakshatra.deity}</div>
        </div>
        <div class="gk-card">
          <div class="gk-card-title"><span>Yoga & Karana</span><span>🌀</span></div>
          <div class="gk-card-value">${f(a.yoga,this.selectedLang)} / ${f(a.karana,this.selectedLang)}</div>
          <div class="gk-card-meta">Vaar: ${f(a.vaar.sanskrit,this.selectedLang)} (${a.vaar.english} - Lord: ${a.vaar.lord})</div>
        </div>
        <div class="gk-card">
          <div class="gk-card-title"><span>Sun & Moon Rashi</span><span>♈</span></div>
          <div class="gk-card-value">${f(a.moonRashi,this.selectedLang)}</div>
          <div class="gk-card-meta">Sun: ${f(a.sunRashi,this.selectedLang)} (Chitrapaksha Lahiri Ayanamsa)</div>
        </div>
        <div class="gk-card">
          <div class="gk-card-title"><span>Auspicious Windows</span><span>🌟</span></div>
          <div class="gk-card-value" style="font-size:1rem; color:var(--color-good);">
            Abhijit: ${a.muhurtas.abhijitMuhurta}
          </div>
          <div class="gk-card-meta">Brahma Muhurta: ${a.muhurtas.brahmaMuhurta}</div>
        </div>
      </div>

      <div class="gk-card" style="margin-top:16px;">
        <h3 style="color:var(--color-primary); margin-bottom:12px;">Inauspicious Muhurtas (Avoid during Auspicious Undertakings)</h3>
        <div class="gk-table-wrapper">
          <table class="gk-table">
            <thead>
              <tr>
                <th>Period</th>
                <th>Calculated Timing</th>
                <th>Significance</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><strong style="color:var(--color-inauspicious);">Rahu Kalam</strong></td>
                <td>${a.muhurtas.rahuKalam}</td>
                <td>Governed by Rahu; prohibited for starting new commercial or spiritual ventures.</td>
              </tr>
              <tr>
                <td><strong>Yamagandam</strong></td>
                <td>${a.muhurtas.yamagandam}</td>
                <td>Governed by Yama; inauspicious for travel or financial contracts.</td>
              </tr>
              <tr>
                <td><strong>Gulika Kalam</strong></td>
                <td>${a.muhurtas.gulikaKalam}</td>
                <td>Governed by Saturn's son Gulika; actions performed recur repeatedly.</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    `}renderGowriTable(a){return`
      <div class="gk-card">
        <h3 style="color:var(--color-primary); margin-bottom:8px;">Gowri Panchangam (Daytime 8 Divisions)</h3>
        <p style="font-size:0.85rem; color:var(--color-text-muted); margin-bottom:14px;">
          Traditional South Indian division of daytime based on local sunrise-to-sunset.
        </p>
        <div class="gk-table-wrapper">
          <table class="gk-table">
            <thead>
              <tr>
                <th>Segment</th>
                <th>Time Window</th>
                <th>Gowri Status</th>
                <th>Recommendation</th>
              </tr>
            </thead>
            <tbody>
              ${a.map((e,t)=>`
                <tr>
                  <td>Segment ${t+1}</td>
                  <td>${e.start} – ${e.end}</td>
                  <td><strong>${e.name}</strong></td>
                  <td>
                    <span class="${e.isGood?"gk-badge-good":"gk-badge-alert"}">
                      ${e.isGood?"Auspicious (Shubham)":"Avoid (Ashubham)"}
                    </span>
                  </td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      </div>
    `}renderChoghadiyaTable(a){return`
      <div class="gk-card">
        <h3 style="color:var(--color-primary); margin-bottom:8px;">Choghadiya Muhurta (Daytime 8 Divisions)</h3>
        <p style="font-size:0.85rem; color:var(--color-text-muted); margin-bottom:14px;">
          Widely practiced Vedic timing system for instant decision making, journeys, and puja.
        </p>
        <div class="gk-table-wrapper">
          <table class="gk-table">
            <thead>
              <tr>
                <th>Segment</th>
                <th>Time Window</th>
                <th>Choghadiya Name</th>
                <th>Nature</th>
              </tr>
            </thead>
            <tbody>
              ${a.map((e,t)=>`
                <tr>
                  <td>Segment ${t+1}</td>
                  <td>${e.start} – ${e.end}</td>
                  <td><strong>${e.name}</strong></td>
                  <td>
                    <span class="${e.isGood?"gk-badge-good":"gk-badge-alert"}">
                      ${e.isGood?"Favorable / Shubh":"Inauspicious / Ashubh"}
                    </span>
                  </td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      </div>
    `}renderPlanetsTable(a,e){return`
      <div class="gk-card">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
          <h3 style="color:var(--color-primary);">Planetary Positions (Graha Sthiti)</h3>
          <span style="font-size:0.8rem; color:var(--color-text-muted);">Lahiri Ayanamsa: ${e}°</span>
        </div>
        <div class="gk-table-wrapper">
          <table class="gk-table">
            <thead>
              <tr>
                <th>Graha (Planet)</th>
                <th>Sidereal Longitude</th>
                <th>Rashi (Sign)</th>
                <th>Degree in Sign</th>
              </tr>
            </thead>
            <tbody>
              ${a.map(t=>`
                <tr>
                  <td><strong>${t.name}</strong></td>
                  <td>${t.siderealLon.toFixed(2)}°</td>
                  <td>${f(t.rashi,this.selectedLang)} (${t.rashiEnglish})</td>
                  <td>${t.degInRashi}°</td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      </div>
    `}renderStotras(){return`
      <section>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; flex-wrap:wrap; gap:12px;">
          <div>
            <h2 style="color:var(--color-primary); font-size:1.6rem;">
              ${f("स्तोत्राणि मन्त्राश्च",this.selectedLang)} (Sacred Slokas & Mantras)
            </h2>
            <p style="font-size:0.85rem; color:var(--color-text-muted);">
              Authentic Vedic swaras, word-by-word Sabdartha, translation, and practical purport.
            </p>
          </div>
          <div style="display:flex; align-items:center; gap:8px;">
            <button id="gk-font-dec" class="gk-btn" title="Decrease Font">A-</button>
            <button id="gk-font-inc" class="gk-btn" title="Increase Font">A+</button>
            <button id="gk-toggle-sabdartha" class="gk-btn ${this.showSabdartha?"gk-btn-primary":""}">
              ${this.showSabdartha?"✓ Sabdartha Visible":"+ Show Sabdartha"}
            </button>
          </div>
        </div>

        ${xa.map((a,e)=>`
          <article class="gk-sloka-card" id="${a.id}">
            <div class="gk-sloka-header">
              <div>
                <h3 class="gk-sloka-title">${f(a.title,this.selectedLang)}</h3>
                <span class="gk-sloka-source">${a.source} • Deity: ${a.deity} • Meter: ${a.meter}</span>
              </div>
            </div>

            <div class="gk-sloka-text" style="font-size:${this.slokaFontSize}rem;">
              ${f(a.devanagari,this.selectedLang)}
            </div>

            <div class="gk-sloka-iast">${a.iast}</div>

            ${this.showSabdartha?`
              <div class="gk-sabdartha-grid">
                ${a.sabdartha.map(t=>`
                  <div class="gk-sabdartha-item">
                    <span class="gk-sabdartha-word">${t.word}:</span> ${t.meaning}
                  </div>
                `).join("")}
              </div>
            `:""}

            <div class="gk-sloka-translation">
              <strong>Translation:</strong> ${a.translation}
            </div>

            <div class="gk-sloka-purport">
              <strong>Purport & Spiritual Insight:</strong> ${a.purport}
            </div>

            ${e===1?this.renderAdSlot("ad-stotra-incontent","rectangle"):""}
          </article>
        `).join("")}
      </section>
    `}renderJapa(){return`
      <section>
        <div class="gk-japa-container">
          <h2 style="color:var(--color-primary); margin-bottom:6px;">
            ${f("जपमाला",this.selectedLang)} (108-Bead Japa Mala)
          </h2>
          <p style="font-size:0.85rem; color:var(--color-text-muted); margin-bottom:18px;">
            Tap the sacred bead circle or press <kbd style="background:#eee; padding:2px 6px; border-radius:4px;">Spacebar</kbd> / <kbd style="background:#eee; padding:2px 6px; border-radius:4px;">Enter</kbd> to count.
          </p>

          <div style="margin-bottom:14px;">
            <select id="gk-japa-mantra-select" class="gk-select" style="max-width:90%;">
              <option value="ॐ नमो भगवते वासुदेवाय">ॐ नमो भगवते वासुदेवाय (Om Namo Bhagavate Vasudevaya)</option>
              <option value="हरे कृष्ण हरे कृष्ण कृष्ण कृष्ण हरे हरे">हरे कृष्ण हरे कृष्ण कृष्ण कृष्ण हरे हरे (Maha-Mantra)</option>
              <option value="ॐ नमः शिवाय">ॐ नमः शिवाय (Om Namah Shivaya)</option>
              <option value="श्री राम जय राम जय जय राम">श्री राम जय राम जय जय राम (Sri Ram Jaya Ram)</option>
              <option value="ॐ गं गणपतये नमः">ॐ गं गणपतये नमः (Ganesha Mantra)</option>
            </select>
          </div>

          <div id="gk-japa-trigger" class="gk-japa-circle" title="Tap to Count">
            <div id="gk-bead-number" class="gk-bead-number">${this.japaEngine.bead}</div>
            <div class="gk-bead-max">of 108 Beads</div>
          </div>

          <div class="gk-japa-stats">
            <div>
              <div id="gk-stat-rounds" class="gk-japa-stat-num">${this.japaEngine.rounds}</div>
              <div class="gk-japa-stat-label">Mala Rounds</div>
            </div>
            <div>
              <div id="gk-stat-total" class="gk-japa-stat-num">${this.japaEngine.totalChants}</div>
              <div class="gk-japa-stat-label">Total Chants</div>
            </div>
            <div>
              <div class="gk-japa-stat-num">${this.japaEngine.dailyTargetRounds}</div>
              <div class="gk-japa-stat-label">Target Malas</div>
            </div>
          </div>

          <div style="display:flex; justify-content:center; gap:10px; margin-top:20px; flex-wrap:wrap;">
            <button id="gk-japa-sound-toggle" class="gk-btn">
              ${this.japaEngine.soundEnabled?"🔔 Sound: ON":"🔕 Sound: OFF"}
            </button>
            <button id="gk-japa-vib-toggle" class="gk-btn">
              ${this.japaEngine.vibrationEnabled?"📳 Haptics: ON":"📴 Haptics: OFF"}
            </button>
            <button id="gk-japa-meru-toggle" class="gk-btn">
              ${this.japaEngine.meruReversalMode?"🔄 Meru Reversal: ON":"🔁 Continuous Loop"}
            </button>
            <button id="gk-japa-reset" class="gk-btn" style="color:var(--color-inauspicious);">Reset Current Round</button>
          </div>

          <div style="margin-top:24px; border-top:1px solid var(--color-border); padding-top:16px;">
            <button id="gk-japa-export" class="gk-btn" style="font-size:0.75rem;">💾 Export Sadhana JSON</button>
          </div>
        </div>
      </section>
    `}renderStories(){return`
      <section>
        <div style="margin-bottom:24px;">
          <h2 style="color:var(--color-primary); font-size:1.6rem;">
            ${f("नीतिकथाः",this.selectedLang)} (Hindu Moral Stories & Philosophy)
          </h2>
          <p style="font-size:0.85rem; color:var(--color-text-muted);">
            Timeless moral wisdom from the 5 Books of Panchatantra, Hitopadesha, Tenali Raman, and Upanishads.
          </p>
        </div>

        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(320px, 1fr)); gap:20px;">
          ${Y.map((a,e)=>`
            <article class="gk-card" style="display:flex; flex-direction:column; justify-content:space-between;">
              <div>
                <span class="gk-badge-good" style="margin-bottom:8px; display:inline-block;">${a.collection}</span>
                <h3 style="color:var(--color-primary); font-size:1.2rem; margin-bottom:8px;">${a.title}</h3>
                
                <div style="background:rgba(230,81,0,0.04); padding:10px; border-radius:6px; margin-bottom:12px; font-style:italic; font-size:0.85rem; border-left:3px solid var(--color-secondary);">
                  "${a.epigraphTranslation}"
                </div>

                <p style="font-size:0.9rem; line-height:1.6; margin-bottom:14px;">
                  ${a.summary}
                </p>

                <div style="margin-bottom:14px;">
                  <strong style="font-size:0.85rem; color:var(--color-secondary);">Moral Lesson:</strong>
                  <p style="font-size:0.85rem; font-weight:600; color:var(--color-primary);">${a.moral}</p>
                </div>

                <div style="margin-bottom:14px;">
                  <div style="font-size:0.75rem; text-transform:uppercase; color:var(--color-text-muted); margin-bottom:4px;">Vocabulary:</div>
                  <div style="display:flex; flex-wrap:wrap; gap:6px;">
                    ${a.vocabulary.map(t=>`
                      <span style="font-size:0.75rem; background:#EEE; padding:2px 8px; border-radius:4px;" title="${t.meaning}">
                        ${t.term}
                      </span>
                    `).join("")}
                  </div>
                </div>
              </div>

              <!-- Interactive Quiz -->
              <div style="border-top:1px solid var(--color-border); padding-top:12px; margin-top:12px;">
                <div style="font-size:0.85rem; font-weight:700; margin-bottom:6px;">Ethical Dilemma Reflection:</div>
                <p style="font-size:0.85rem; margin-bottom:10px;">${a.quiz.question}</p>
                <div class="gk-quiz-options" data-story="${a.id}">
                  ${a.quiz.options.map((t,i)=>`
                    <button class="gk-btn gk-quiz-btn" data-story="${a.id}" data-idx="${i}" style="width:100%; text-align:left; margin-bottom:6px; font-size:0.8rem;">
                      ${t}
                    </button>
                  `).join("")}
                </div>
                <div id="gk-quiz-result-${a.id}" style="font-size:0.8rem; display:none; padding:8px; border-radius:6px; margin-top:8px;"></div>
              </div>
            </article>
          `).join("")}
        </div>

        ${this.renderAdSlot("ad-story-native","native")}
      </section>
    `}renderCityModal(){return`
      <div class="gk-modal-backdrop" id="gk-city-modal-backdrop">
        <div class="gk-modal">
          <div class="gk-modal-header">
            <h3 style="color:var(--color-primary);">Select Global City</h3>
            <button id="gk-close-city-modal" class="gk-btn" style="border:none; font-size:1.2rem;">✕</button>
          </div>
          <input type="text" id="gk-city-search-input" class="gk-search-input" placeholder="Search Indian pilgrimage towns or global diaspora cities...">
          <ul class="gk-city-list" id="gk-city-list-items">
            ${this.cities.map(a=>`
              <li class="gk-city-item" data-city-id="${a.id}">
                <div>
                  <strong>${a.name}</strong>, <span style="font-size:0.85rem; color:var(--color-text-muted);">${a.state}, ${a.country}</span>
                </div>
                <span style="font-size:0.75rem; color:var(--color-accent); font-weight:700;">UTC ${a.tz_offset>=0?"+":""}${a.tz_offset}</span>
              </li>
            `).join("")}
          </ul>
        </div>
      </div>
    `}renderAdSlot(a,e){return`
      <aside class="gk-ad-container" aria-label="Sponsor Advertisement">
        <div class="gk-ad-wrapper gk-ad-${e}" id="${a}">
          <span class="gk-ad-label">Sponsor Message</span>
          <div style="font-size:0.75rem; color:#8C7853; text-align:center; padding:10px;">
            Reserve Ad Placement (${e.toUpperCase()})<br>
            <span style="font-size:0.65rem; opacity:0.7;">CLS = 0.00 Guaranteed • Google AdSense Compliant</span>
          </div>
        </div>
      </aside>
    `}renderConsentBanner(){return localStorage.getItem("gk_consent")?"":`
      <div class="gk-consent-banner" id="gk-consent-banner">
        <div class="gk-consent-text">
          <strong>Privacy & Cookies:</strong> We use privacy-first cookieless analytics and Google AdSense to serve non-intrusive contextual messages. Your location and Japa counters remain 100% on your device.
        </div>
        <div class="gk-consent-actions">
          <button id="gk-consent-accept" class="gk-btn gk-btn-primary">Accept & Continue</button>
        </div>
      </div>
    `}renderFooter(){return`
      <footer class="gk-footer">
        <div class="gk-footer-inner">
          <div>
            <strong style="color:var(--color-primary); font-size:1.1rem;">GuruKripa (गुरूकृपा)</strong>
            <p style="font-size:0.8rem; color:var(--color-text-muted); margin-top:4px;">
              Enterprise-Grade Zero-Cost Hindu Spiritual Portal • 100% Client-Side Ephemeris Calculations.
            </p>
          </div>
          <ul class="gk-footer-links">
            <li><a href="/privacy.html">Privacy Policy</a></li>
            <li><a href="/terms.html">Terms & Copyright</a></li>
            <li><a href="/disclaimer.html">Astrological Disclaimer</a></li>
            <li><a href="/about.html">About & Mission</a></li>
            <li><a href="/sitemap.xml">Sitemap</a></li>
          </ul>
        </div>
        <div style="text-align:center; font-size:0.75rem; color:var(--color-text-muted); margin-top:24px;">
          Om Sarve Bhavantu Sukhinah • May All Beings Attain Peace & Liberation.
        </div>
      </footer>
    `}attachEventListeners(){const a=document.getElementById("gk-lang-select");a&&a.addEventListener("change",d=>{this.selectedLang=d.target.value,localStorage.setItem("gk_lang",this.selectedLang),this.render()});const e=document.getElementById("gk-theme-toggle");e&&e.addEventListener("click",()=>this.toggleTheme());const t=document.getElementById("gk-date-picker");t&&t.addEventListener("change",d=>{d.target.value&&(this.selectedDate=new Date(d.target.value+"T12:00:00"),this.render())}),document.querySelectorAll(".gk-tab-btn").forEach(d=>{d.addEventListener("click",A=>{this.panchangTab=A.target.getAttribute("data-tab"),this.render()})});const i=document.getElementById("gk-open-city-modal");i&&i.addEventListener("click",()=>{this.cityModalOpen=!0,this.render()});const n=document.getElementById("gk-close-city-modal");n&&n.addEventListener("click",()=>{this.cityModalOpen=!1,this.render()});const l=document.getElementById("gk-auto-detect-btn");l&&l.addEventListener("click",()=>this.autoDetectLocation());const c=document.getElementById("gk-city-search-input");c&&c.addEventListener("input",d=>{const A=d.target.value.toLowerCase();document.querySelectorAll(".gk-city-item").forEach(y=>{const k=y.innerText.toLowerCase();y.style.display=k.includes(A)?"flex":"none"})}),document.querySelectorAll(".gk-city-item").forEach(d=>{d.addEventListener("click",A=>{const T=d.getAttribute("data-city-id"),y=this.cities.find(k=>k.id===T);y&&(this.saveCity(y),this.cityModalOpen=!1,this.render())})});const h=document.getElementById("gk-font-inc");h&&h.addEventListener("click",()=>{this.slokaFontSize=Math.min(this.slokaFontSize+.15,2.2),this.render()});const b=document.getElementById("gk-font-dec");b&&b.addEventListener("click",()=>{this.slokaFontSize=Math.max(this.slokaFontSize-.15,.9),this.render()});const S=document.getElementById("gk-toggle-sabdartha");S&&S.addEventListener("click",()=>{this.showSabdartha=!this.showSabdartha,this.render()});const m=document.getElementById("gk-japa-trigger");m&&m.addEventListener("click",()=>this.handleJapaClick());const $=document.getElementById("gk-japa-sound-toggle");$&&$.addEventListener("click",()=>{this.japaEngine.soundEnabled=!this.japaEngine.soundEnabled,this.japaEngine.saveState(),this.render()});const s=document.getElementById("gk-japa-vib-toggle");s&&s.addEventListener("click",()=>{this.japaEngine.vibrationEnabled=!this.japaEngine.vibrationEnabled,this.japaEngine.saveState(),this.render()});const v=document.getElementById("gk-japa-meru-toggle");v&&v.addEventListener("click",()=>{this.japaEngine.meruReversalMode=!this.japaEngine.meruReversalMode,this.japaEngine.saveState(),this.render()});const M=document.getElementById("gk-japa-reset");M&&M.addEventListener("click",()=>{confirm("Reset current 108 bead counter to 0?")&&(this.japaEngine.resetCurrentMala(),this.render())});const E=document.getElementById("gk-japa-export");E&&E.addEventListener("click",()=>{const d=this.japaEngine.exportDataJSON(),A=new Blob([d],{type:"application/json"}),T=URL.createObjectURL(A),y=document.createElement("a");y.href=T,y.download=`GuruKripa_Japa_Backup_${new Date().toISOString().slice(0,10)}.json`,y.click()}),document.querySelectorAll(".gk-quiz-btn").forEach(d=>{d.addEventListener("click",A=>{const T=d.getAttribute("data-story"),y=parseInt(d.getAttribute("data-idx"),10),k=Y.find(V=>V.id===T),w=document.getElementById(`gk-quiz-result-${T}`);k&&w&&(w.style.display="block",y===k.quiz.correctIndex?(w.style.background="rgba(46, 125, 50, 0.1)",w.style.color="#2E7D32",w.innerHTML=`<strong>✓ Spot On!</strong> ${k.quiz.explanation}`):(w.style.background="rgba(198, 40, 40, 0.1)",w.style.color="#C62828",w.innerHTML="<strong>Reflect Again:</strong> Consider the spiritual principle of Buddhi and Satya."))})});const I=document.getElementById("gk-consent-accept");I&&I.addEventListener("click",()=>{localStorage.setItem("gk_consent","accepted");const d=document.getElementById("gk-consent-banner");d&&d.remove()})}}document.addEventListener("DOMContentLoaded",()=>{new Ea});
