(function(){const a=document.createElement("link").relList;if(a&&a.supports&&a.supports("modulepreload"))return;for(const t of document.querySelectorAll('link[rel="modulepreload"]'))i(t);new MutationObserver(t=>{for(const r of t)if(r.type==="childList")for(const n of r.addedNodes)n.tagName==="LINK"&&n.rel==="modulepreload"&&i(n)}).observe(document,{childList:!0,subtree:!0});function e(t){const r={};return t.integrity&&(r.integrity=t.integrity),t.referrerPolicy&&(r.referrerPolicy=t.referrerPolicy),t.crossOrigin==="use-credentials"?r.credentials="include":t.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function i(t){if(t.ep)return;t.ep=!0;const r=e(t);fetch(t.href,r)}})();const Oa=[{id:"delhi",name:"New Delhi",state:"Delhi",country:"India",lat:28.6139,lon:77.209,tz:"Asia/Kolkata",tz_offset:5.5,elevation:216},{id:"mumbai",name:"Mumbai",state:"Maharashtra",country:"India",lat:19.076,lon:72.8777,tz:"Asia/Kolkata",tz_offset:5.5,elevation:14},{id:"chennai",name:"Chennai",state:"Tamil Nadu",country:"India",lat:13.0827,lon:80.2707,tz:"Asia/Kolkata",tz_offset:5.5,elevation:6},{id:"bengaluru",name:"Bengaluru",state:"Karnataka",country:"India",lat:12.9716,lon:77.5946,tz:"Asia/Kolkata",tz_offset:5.5,elevation:920},{id:"hyderabad",name:"Hyderabad",state:"Telangana",country:"India",lat:17.385,lon:78.4867,tz:"Asia/Kolkata",tz_offset:5.5,elevation:542},{id:"kolkata",name:"Kolkata",state:"West Bengal",country:"India",lat:22.5726,lon:88.3639,tz:"Asia/Kolkata",tz_offset:5.5,elevation:9},{id:"ahmedabad",name:"Ahmedabad",state:"Gujarat",country:"India",lat:23.0225,lon:72.5714,tz:"Asia/Kolkata",tz_offset:5.5,elevation:53},{id:"varanasi",name:"Varanasi (Kashi)",state:"Uttar Pradesh",country:"India",lat:25.3176,lon:82.9739,tz:"Asia/Kolkata",tz_offset:5.5,elevation:81},{id:"tirupati",name:"Tirupati",state:"Andhra Pradesh",country:"India",lat:13.6288,lon:79.4192,tz:"Asia/Kolkata",tz_offset:5.5,elevation:182},{id:"puri",name:"Puri (Jagannath)",state:"Odisha",country:"India",lat:19.8135,lon:85.8312,tz:"Asia/Kolkata",tz_offset:5.5,elevation:10},{id:"rameswaram",name:"Rameswaram",state:"Tamil Nadu",country:"India",lat:9.2876,lon:79.3129,tz:"Asia/Kolkata",tz_offset:5.5,elevation:10},{id:"haridwar",name:"Haridwar",state:"Uttarakhand",country:"India",lat:29.9457,lon:78.1642,tz:"Asia/Kolkata",tz_offset:5.5,elevation:314},{id:"ujjain",name:"Ujjain (Mahakaleshwar)",state:"Madhya Pradesh",country:"India",lat:23.1765,lon:75.7885,tz:"Asia/Kolkata",tz_offset:5.5,elevation:491},{id:"madurai",name:"Madurai (Meenakshi)",state:"Tamil Nadu",country:"India",lat:9.9252,lon:78.1198,tz:"Asia/Kolkata",tz_offset:5.5,elevation:101},{id:"dwarka",name:"Dwarka",state:"Gujarat",country:"India",lat:22.2442,lon:68.9685,tz:"Asia/Kolkata",tz_offset:5.5,elevation:5},{id:"somnath",name:"Somnath",state:"Gujarat",country:"India",lat:20.906,lon:70.401,tz:"Asia/Kolkata",tz_offset:5.5,elevation:12},{id:"ayodhya",name:"Ayodhya",state:"Uttar Pradesh",country:"India",lat:26.7922,lon:82.1998,tz:"Asia/Kolkata",tz_offset:5.5,elevation:102},{id:"mathura",name:"Mathura / Vrindavan",state:"Uttar Pradesh",country:"India",lat:27.4924,lon:77.6737,tz:"Asia/Kolkata",tz_offset:5.5,elevation:174},{id:"bhubaneswar",name:"Bhubaneswar",state:"Odisha",country:"India",lat:20.2961,lon:85.8245,tz:"Asia/Kolkata",tz_offset:5.5,elevation:45},{id:"guruvayur",name:"Guruvayur",state:"Kerala",country:"India",lat:10.5946,lon:76.0416,tz:"Asia/Kolkata",tz_offset:5.5,elevation:12},{id:"shirdi",name:"Shirdi",state:"Maharashtra",country:"India",lat:19.7667,lon:74.4764,tz:"Asia/Kolkata",tz_offset:5.5,elevation:504},{id:"pune",name:"Pune",state:"Maharashtra",country:"India",lat:18.5204,lon:73.8567,tz:"Asia/Kolkata",tz_offset:5.5,elevation:560},{id:"jaipur",name:"Jaipur",state:"Rajasthan",country:"India",lat:26.9124,lon:75.7873,tz:"Asia/Kolkata",tz_offset:5.5,elevation:431},{id:"new-york",name:"New York",state:"NY",country:"USA",lat:40.7128,lon:-74.006,tz:"America/New_York",tz_offset:-5,elevation:10},{id:"san-jose",name:"San Jose (Silicon Valley)",state:"CA",country:"USA",lat:37.3382,lon:-121.8863,tz:"America/Los_Angeles",tz_offset:-8,elevation:26},{id:"chicago",name:"Chicago",state:"IL",country:"USA",lat:41.8781,lon:-87.6298,tz:"America/Chicago",tz_offset:-6,elevation:181},{id:"dallas",name:"Dallas",state:"TX",country:"USA",lat:32.7767,lon:-96.797,tz:"America/Chicago",tz_offset:-6,elevation:131},{id:"london",name:"London",state:"England",country:"UK",lat:51.5074,lon:-.1278,tz:"Europe/London",tz_offset:0,elevation:11},{id:"leicester",name:"Leicester",state:"England",country:"UK",lat:52.6369,lon:-1.1398,tz:"Europe/London",tz_offset:0,elevation:67},{id:"toronto",name:"Toronto",state:"ON",country:"Canada",lat:43.6532,lon:-79.3832,tz:"America/Toronto",tz_offset:-5,elevation:76},{id:"vancouver",name:"Vancouver",state:"BC",country:"Canada",lat:49.2827,lon:-123.1207,tz:"America/Vancouver",tz_offset:-8,elevation:2},{id:"sydney",name:"Sydney",state:"NSW",country:"Australia",lat:-33.8688,lon:151.2093,tz:"Australia/Sydney",tz_offset:10,elevation:19},{id:"melbourne",name:"Melbourne",state:"VIC",country:"Australia",lat:-37.8136,lon:144.9631,tz:"Australia/Melbourne",tz_offset:10,elevation:31},{id:"singapore",name:"Singapore",state:"Singapore",country:"Singapore",lat:1.3521,lon:103.8198,tz:"Asia/Singapore",tz_offset:8,elevation:15},{id:"dubai",name:"Dubai",state:"Dubai",country:"UAE",lat:25.2048,lon:55.2708,tz:"Asia/Dubai",tz_offset:4,elevation:5},{id:"kuala-lumpur",name:"Kuala Lumpur",state:"Federal Territory",country:"Malaysia",lat:3.139,lon:101.6869,tz:"Asia/Kuala_Lumpur",tz_offset:8,elevation:21},{id:"durban",name:"Durban",state:"KwaZulu-Natal",country:"South Africa",lat:-29.8587,lon:31.0218,tz:"Africa/Johannesburg",tz_offset:2,elevation:14},{id:"nairobi",name:"Nairobi",state:"Nairobi",country:"Kenya",lat:-1.2921,lon:36.8219,tz:"Africa/Nairobi",tz_offset:3,elevation:1795},{id:"mauritius",name:"Port Louis",state:"Port Louis",country:"Mauritius",lat:-20.1609,lon:57.5012,tz:"Indian/Mauritius",tz_offset:4,elevation:13},{id:"tokyo",name:"Tokyo",state:"Tokyo",country:"Japan",lat:35.6762,lon:139.6503,tz:"Asia/Tokyo",tz_offset:9,elevation:40}],Ua=[{id:1,name:"Prathama",paksha:"Shukla",deity:"Agni"},{id:2,name:"Dwitiya",paksha:"Shukla",deity:"Brahma"},{id:3,name:"Tritiya",paksha:"Shukla",deity:"Gauri"},{id:4,name:"Chaturthi",paksha:"Shukla",deity:"Ganesha"},{id:5,name:"Panchami",paksha:"Shukla",deity:"Nagas"},{id:6,name:"Shashthi",paksha:"Shukla",deity:"Kartikeya"},{id:7,name:"Saptami",paksha:"Shukla",deity:"Surya"},{id:8,name:"Ashtami",paksha:"Shukla",deity:"Shiva / Durga"},{id:9,name:"Navami",paksha:"Shukla",deity:"Durga / Rama"},{id:10,name:"Dashami",paksha:"Shukla",deity:"Yama"},{id:11,name:"Ekadashi",paksha:"Shukla",deity:"Vishnu"},{id:12,name:"Dwadashi",paksha:"Shukla",deity:"Vishnu"},{id:13,name:"Trayodashi",paksha:"Shukla",deity:"Kamadeva"},{id:14,name:"Chaturdashi",paksha:"Shukla",deity:"Shiva"},{id:15,name:"Purnima",paksha:"Shukla",deity:"Chandra"},{id:16,name:"Prathama",paksha:"Krishna",deity:"Agni"},{id:17,name:"Dwitiya",paksha:"Krishna",deity:"Brahma"},{id:18,name:"Tritiya",paksha:"Krishna",deity:"Gauri"},{id:19,name:"Chaturthi",paksha:"Krishna",deity:"Ganesha"},{id:20,name:"Panchami",paksha:"Krishna",deity:"Nagas"},{id:21,name:"Shashthi",paksha:"Krishna",deity:"Kartikeya"},{id:22,name:"Saptami",paksha:"Krishna",deity:"Surya"},{id:23,name:"Ashtami",paksha:"Krishna",deity:"Shiva / Durga"},{id:24,name:"Navami",paksha:"Krishna",deity:"Durga"},{id:25,name:"Dashami",paksha:"Krishna",deity:"Yama"},{id:26,name:"Ekadashi",paksha:"Krishna",deity:"Vishnu"},{id:27,name:"Dwadashi",paksha:"Krishna",deity:"Vishnu"},{id:28,name:"Trayodashi",paksha:"Krishna",deity:"Kamadeva"},{id:29,name:"Chaturdashi",paksha:"Krishna",deity:"Shiva"},{id:30,name:"Amavasya",paksha:"Krishna",deity:"Pitrus"}],ma=[{id:1,name:"Ashwini",deity:"Ashwini Kumaras",lord:"Ketu"},{id:2,name:"Bharani",deity:"Yama",lord:"Venus"},{id:3,name:"Krittika",deity:"Agni",lord:"Sun"},{id:4,name:"Rohini",deity:"Brahma",lord:"Moon"},{id:5,name:"Mrigashira",deity:"Soma",lord:"Mars"},{id:6,name:"Ardra",deity:"Rudra",lord:"Rahu"},{id:7,name:"Punarvasu",deity:"Aditi",lord:"Jupiter"},{id:8,name:"Pushya",deity:"Brihaspati",lord:"Saturn"},{id:9,name:"Ashlesha",deity:"Sarpa",lord:"Mercury"},{id:10,name:"Magha",deity:"Pitrus",lord:"Ketu"},{id:11,name:"Purva Phalguni",deity:"Bhaga",lord:"Venus"},{id:12,name:"Uttara Phalguni",deity:"Aryaman",lord:"Sun"},{id:13,name:"Hasta",deity:"Savitr",lord:"Moon"},{id:14,name:"Chitra",deity:"Vishwakarma",lord:"Mars"},{id:15,name:"Swati",deity:"Vayu",lord:"Rahu"},{id:16,name:"Vishakha",deity:"Indragni",lord:"Jupiter"},{id:17,name:"Anuradha",deity:"Mitra",lord:"Saturn"},{id:18,name:"Jyeshtha",deity:"Indra",lord:"Mercury"},{id:19,name:"Moola",deity:"Nirriti",lord:"Ketu"},{id:20,name:"Purva Ashadha",deity:"Apas",lord:"Venus"},{id:21,name:"Uttara Ashadha",deity:"Vishwedevas",lord:"Sun"},{id:22,name:"Shravana",deity:"Vishnu",lord:"Moon"},{id:23,name:"Dhanishtha",deity:"Vasus",lord:"Mars"},{id:24,name:"Shatabhisha",deity:"Varuna",lord:"Rahu"},{id:25,name:"Purva Bhadrapada",deity:"Aja Ekapada",lord:"Jupiter"},{id:26,name:"Uttara Bhadrapada",deity:"Ahirbudhnya",lord:"Saturn"},{id:27,name:"Revati",deity:"Pushan",lord:"Mercury"}],_a=["Vishkambha","Priti","Ayushman","Saubhagya","Shobhana","Atiganda","Sukarma","Dhriti","Shula","Ganda","Vriddhi","Dhruva","Vyaghata","Harshana","Vajra","Siddhi","Vyatipata","Variyan","Parigha","Shiva","Siddha","Sadhya","Shubha","Shukla","Brahma","Indra","Vaidhriti"],J=[{id:1,name:"Mesha",english:"Aries",lord:"Mars"},{id:2,name:"Vrishabha",english:"Taurus",lord:"Venus"},{id:3,name:"Mithuna",english:"Gemini",lord:"Mercury"},{id:4,name:"Karkataka",english:"Cancer",lord:"Moon"},{id:5,name:"Simha",english:"Leo",lord:"Sun"},{id:6,name:"Kanya",english:"Virgo",lord:"Mercury"},{id:7,name:"Tula",english:"Libra",lord:"Venus"},{id:8,name:"Vrishchika",english:"Scorpio",lord:"Mars"},{id:9,name:"Dhanu",english:"Sagittarius",lord:"Jupiter"},{id:10,name:"Makara",english:"Capricorn",lord:"Saturn"},{id:11,name:"Kumbha",english:"Aquarius",lord:"Saturn"},{id:12,name:"Meena",english:"Pisces",lord:"Jupiter"}],Ha=[{id:0,name:"Ravivara",english:"Sunday",lord:"Surya"},{id:1,name:"Somavara",english:"Monday",lord:"Chandra"},{id:2,name:"Mangalavara",english:"Tuesday",lord:"Mangala"},{id:3,name:"Budhavara",english:"Wednesday",lord:"Budha"},{id:4,name:"Guruvara",english:"Thursday",lord:"Brihaspati"},{id:5,name:"Shukravara",english:"Friday",lord:"Shukra"},{id:6,name:"Shanivara",english:"Saturday",lord:"Shani"}],Q=Math.PI/180,Z=180/Math.PI;function g(o){let a=o%360;return a<0&&(a+=360),a}function f(o){return Math.sin(o*Q)}function D(o){return Math.cos(o*Q)}function ga(o){return Math.tan(o*Q)}function va(o,a,e,i=12){a<=2&&(o-=1,a+=12);const t=Math.floor(o/100),r=2-t+Math.floor(t/4);return Math.floor(365.25*(o+4716))+Math.floor(30.6001*(a+1))+e+i/24+r-1524.5}function qa(o){const a=(o-2451545)/36525;return 23.856+1.396042*a+308e-6*a*a}function fa(o){const a=(o-2451545)/36525,e=g(280.46646+36000.76983*a+3032e-7*a*a),i=g(357.52911+35999.05029*a-1537e-7*a*a),t=(1.914602-.004817*a-14e-6*a*a)*f(i)+(.019993-101e-6*a)*f(2*i)+289e-6*f(3*i),r=g(e+t),n=125.04-1934.136*a,l=g(r-.00569-.00478*f(n)),u=23.439291-.0130042*a+.00256*D(n),c=g(Math.atan2(D(u)*f(l),D(l))*Z),b=Math.asin(f(u)*f(l))*Z;return{lon:l,ra:c,dec:b}}function Wa(o){const a=(o-2451545)/36525,e=g(218.3164477+481267.88123421*a),i=g(297.8501921+445267.1114034*a),t=g(357.5291092+35999.0502909*a),r=g(134.9633964+477198.8675055*a),n=g(93.272095+483202.0175233*a);let l=6.288774*f(r)+1.274027*f(2*i-r)+.658314*f(2*i)+.213618*f(2*r)-.185116*f(t)-.114332*f(2*n);return{lon:g(e+l)}}function Ja(o,a,e,i,t,r){const n=va(o,a,e,12-r),l=fa(n),u=(D(90.8333)-f(i)*f(l.dec))/(D(i)*D(l.dec));let c=!0,b=0;u>1||u<-1?c=!1:b=Math.acos(u)*Z;const T=(n-2451545)/36525,S=g(357.52911+35999.05029*T),x=g(280.46646+36000.76983*T),M=.016708634-42037e-9*T,L=ga(23.439291/2)*ga(23.439291/2),R=(L*f(2*x)-2*M*f(S)+4*M*L*f(S)*D(2*x)-.5*L*L*f(4*x)-1.25*M*M*f(2*S))*4,$=(720-4*t-R)/60,j=$-b*4/60,B=$+b*4/60,V=(j+r+24)%24,s=(B+r+24)%24,v=($+r+24)%24;return{sunrise:V,sunset:s,solarNoon:v,hasSun:c}}function h(o){let a=Math.round(o*60);a=(a+1440)%1440;const e=Math.floor(a/60),i=a%60,t=e>=12?"PM":"AM",r=e%12===0?12:e%12,n=i<10?`0${i}`:i;return`${r}:${n} ${t}`}function Ya(o,a){const e=o.getFullYear(),i=o.getMonth()+1,t=o.getDate(),{lat:r,lon:n,tz_offset:l}=a,d=Ja(e,i,t,r,n,l),u=va(e,i,t,d.sunrise-l),c=qa(u),b=fa(u),T=Wa(u),S=g(b.lon-c),x=g(T.lon-c),M=g(T.lon-b.lon),L=Math.floor(M/12),R=M%12/12*100,$=Ua[L%30],j=Math.floor(x/(360/27)),B=x%(360/27)/(360/27)*100,V=Math.floor(x%(360/27)/(360/108))+1,s=ma[j%27],v=g(S+x),C=Math.floor(v/(360/27)),k=_a[C%27],w=Math.floor(M/6);let K="";if(w===0)K="Kintughna";else if(w>=57){const p=w-57;K=["Shakuni","Chatushpada","Naga"][p]||"Kintughna"}else K=["Bava","Balava","Kaulava","Taitila","Gara","Vanija","Vishti (Bhadra)"][(w-1)%7];const E=o.getDay(),N=Ha[E],P=(d.sunset-d.sunrise+24)%24,A=P/8,ba=[7,1,6,4,5,3,2],X=d.sunrise+ba[E]*A,ka=X+A,Sa=[4,3,2,1,0,6,5],aa=d.sunrise+Sa[E]*A,wa=aa+A,Aa=[6,5,4,3,2,1,0],ea=d.sunrise+Aa[E]*A,xa=ea+A,ta=P/15,ia=d.sunrise+7*ta,Ca=ia+ta,Ta=(d.sunrise-96/60+24)%24,Ma=(d.sunrise-48/60+24)%24,$a=Math.floor(S/30),La=Math.floor(x/30),na=J[$a%12],ra=J[La%12];function I(p,y,Ka,da=!1){const G=g(Ka),Pa=Math.floor(G/30)%12,la=J[Pa],W=G%30,ha=Math.floor(W),ca=Math.floor(W%1*60),ua=Math.round(W%1*60%1*60),Ga=Math.floor(G/(360/27))%27,Fa=ma[Ga],Na=Math.floor(G%(360/27)/(360/108))+1;return{name:p,sanskrit:y,siderealLon:G,deg:ha,min:ca,sec:ua,degInRashi:`${ha}° ${ca}' ${ua}"`,rashi:la.name,rashiEnglish:la.english,nakshatra:Fa.name,pada:Na,isRetrograde:da,status:da?"Retrograde (Vakra)":"Direct (Marga)"}}const Ea=[I("Surya (Sun)","सूर्यः",S,!1),I("Chandra (Moon)","चन्द्रः",x,!1),I("Mangala (Mars)","मङ्गलः",g(S*.53+45),!1),I("Budha (Mercury)","बुधः",g(S+12),!1),I("Brihaspati (Jupiter)","बृहस्पतिः",g(S*.08+82),!1),I("Shukra (Venus)","शुक्रः",g(S-24),!1),I("Shani (Saturn)","शनिः",g(S*.03+338),!1),I("Rahu (North Node)","राहुः",g(360-(b.lon*.05+115)),!0),I("Ketu (South Node)","केतुः",g(360-(b.lon*.05+115)+180),!0)],Ia=[["Uthi","Amrutha","Rogam","Labham","Visham","Sugam","Choram","Bandham"],["Amrutha","Rogam","Labham","Visham","Sugam","Choram","Bandham","Uthi"],["Rogam","Labham","Visham","Sugam","Choram","Bandham","Uthi","Amrutha"],["Labham","Visham","Sugam","Choram","Bandham","Uthi","Amrutha","Rogam"],["Sugam","Choram","Bandham","Uthi","Amrutha","Rogam","Labham","Visham"],["Bandham","Uthi","Amrutha","Rogam","Labham","Visham","Sugam","Choram"],["Choram","Bandham","Uthi","Amrutha","Rogam","Labham","Visham","Sugam"]],za=[["Choram","Bandham","Uthi","Amrutha","Rogam","Labham","Visham","Sugam"],["Sugam","Choram","Bandham","Uthi","Amrutha","Rogam","Labham","Visham"],["Labham","Visham","Sugam","Choram","Bandham","Uthi","Amrutha","Rogam"],["Rogam","Labham","Visham","Sugam","Choram","Bandham","Uthi","Amrutha"],["Amrutha","Rogam","Labham","Visham","Sugam","Choram","Bandham","Uthi"],["Uthi","Amrutha","Rogam","Labham","Visham","Sugam","Choram","Bandham"],["Bandham","Uthi","Amrutha","Rogam","Labham","Visham","Sugam","Choram"]],z=(24-P)/8,sa=Ia[E].map((p,y)=>({name:p,nature:["Amrutha","Labham","Sugam","Uthi"].includes(p)?"Good":"Inauspicious",isGood:["Amrutha","Labham","Sugam","Uthi"].includes(p),slot:`${h(d.sunrise+y*A)} – ${h(d.sunrise+(y+1)*A)}`,start:h(d.sunrise+y*A),end:h(d.sunrise+(y+1)*A)})),Da=za[E].map((p,y)=>({name:p,nature:["Amrutha","Labham","Sugam","Uthi"].includes(p)?"Good":"Inauspicious",isGood:["Amrutha","Labham","Sugam","Uthi"].includes(p),slot:`${h(d.sunset+y*z)} – ${h(d.sunset+(y+1)*z)}`,start:h(d.sunset+y*z),end:h(d.sunset+(y+1)*z)})),O=[...sa];O.day=sa,O.night=Da;const Ra=[["Udveg","Char","Labh","Amrit","Kaal","Shubh","Rog","Udveg"],["Amrit","Kaal","Shubh","Rog","Udveg","Char","Labh","Amrit"],["Rog","Udveg","Char","Labh","Amrit","Kaal","Shubh","Rog"],["Labh","Amrit","Kaal","Shubh","Rog","Udveg","Char","Labh"],["Shubh","Rog","Udveg","Char","Labh","Amrit","Kaal","Shubh"],["Char","Labh","Amrit","Kaal","Shubh","Rog","Udveg","Char"],["Kaal","Shubh","Rog","Udveg","Char","Labh","Amrit","Kaal"]],ja=[["Shubh","Amrit","Char","Rog","Kaal","Labh","Udveg","Shubh"],["Char","Rog","Kaal","Labh","Udveg","Shubh","Amrit","Char"],["Kaal","Labh","Udveg","Shubh","Amrit","Char","Rog","Kaal"],["Udveg","Shubh","Amrit","Char","Rog","Kaal","Labh","Udveg"],["Amrit","Char","Rog","Kaal","Labh","Udveg","Shubh","Amrit"],["Rog","Kaal","Labh","Udveg","Shubh","Amrit","Char","Rog"],["Labh","Udveg","Shubh","Amrit","Char","Rog","Kaal","Labh"]],oa=Ra[E].map((p,y)=>({name:p,nature:["Shubh","Labh","Amrit","Char"].includes(p)?"Auspicious":"Inauspicious",isGood:["Shubh","Labh","Amrit","Char"].includes(p),slot:`${h(d.sunrise+y*A)} – ${h(d.sunrise+(y+1)*A)}`,start:h(d.sunrise+y*A),end:h(d.sunrise+(y+1)*A)})),Ba=ja[E].map((p,y)=>({name:p,nature:["Shubh","Labh","Amrit","Char"].includes(p)?"Auspicious":"Inauspicious",isGood:["Shubh","Labh","Amrit","Char"].includes(p),slot:`${h(d.sunset+y*z)} – ${h(d.sunset+(y+1)*z)}`,start:h(d.sunset+y*z),end:h(d.sunset+(y+1)*z)})),U=[...oa];U.day=oa,U.night=Ba;const _=Math.floor(c),H=Math.floor(c%1*60),q=Math.round(c%1*60%1*60),Va={value:parseFloat(c.toFixed(4)),degrees:_,minutes:H,seconds:q,formatted:`${_}° ${H}' ${q}"`,toFixed:p=>c.toFixed(p),toString:()=>`${_}° ${H}' ${q}"`,valueOf:()=>c};return{date:`${e}-${String(i).padStart(2,"0")}-${String(t).padStart(2,"0")}`,city:a.name,country:a.country,coordinates:`${a.lat.toFixed(4)}° N, ${a.lon.toFixed(4)}° E`,ayanamsa:Va,sunrise:h(d.sunrise),sunset:h(d.sunset),solarNoon:h(d.solarNoon),dayDuration:`${Math.floor(P)}h ${Math.round(P%1*60)}m`,tithi:{name:`${$.paksha} ${$.name}`,paksha:$.paksha,deity:$.deity,progress:Math.round(R)},nakshatra:{name:s.name,pada:V,deity:s.deity,lord:s.lord,progress:Math.round(B)},yoga:k,karana:K,vaar:{sanskrit:N.name,english:N.english,lord:N.lord},sunRashi:`${na.name} (${na.english})`,moonRashi:`${ra.name} (${ra.english})`,muhurtas:{rahuKalam:`${h(X)} – ${h(ka)}`,yamagandam:`${h(aa)} – ${h(wa)}`,gulikaKalam:`${h(ea)} – ${h(xa)}`,abhijitMuhurta:E===3?"None (Wednesdays prohibited)":`${h(ia)} – ${h(Ca)}`,brahmaMuhurta:`${h(Ta)} – ${h(Ma)}`},gowriPanchangam:O,choghadiya:U,planets:Ea}}const Za=[{code:"sa",name:"Sanskrit",native:"संस्कृतम्",script:"Devanagari"},{code:"hi",name:"Hindi",native:"हिन्दी",script:"Devanagari"},{code:"mr",name:"Marathi",native:"मराठी",script:"Devanagari"},{code:"ta",name:"Tamil",native:"தமிழ்",script:"Tamil"},{code:"te",name:"Telugu",native:"తెలుగు",script:"Telugu"},{code:"kn",name:"Kannada",native:"ಕನ್ನಡ",script:"Kannada"},{code:"ml",name:"Malayalam",native:"മലയാളം",script:"Malayalam"},{code:"gu",name:"Gujarati",native:"ગુજરાતી",script:"Gujarati"},{code:"bn",name:"Bengali",native:"বাংলা",script:"Bengali"},{code:"or",name:"Odia",native:"ଓଡ଼ିଆ",script:"Odia"},{code:"en",name:"English (IAST)",native:"English (IAST)",script:"Latin"}];function F(o){return o?o.replace(/[\u0951\u0952\u0953\u0954\u1CD0-\u1CF9\uA8E0-\uA8F7]/g,""):""}const Qa={sa:"ॐ",hi:"ॐ",mr:"ॐ",ta:"ஓம்",te:"ఓం",kn:"ಓಂ",ml:"ഓം",gu:"ૐ",bn:"ওঁ",or:"ଓଁ",en:"Oṃ"},Y={अ:"a",आ:"ā",इ:"i",ई:"ī",उ:"u",ऊ:"ū",ऋ:"ṛ",ॠ:"ṝ",ऌ:"ḷ",ॡ:"ḹ",ए:"e",ऐ:"ai",ओ:"o",औ:"au","ा":"ā","ि":"i","ी":"ī","ु":"u","ू":"ū","ृ":"ṛ","ॄ":"ṝ","ॢ":"ḷ","ॣ":"ḹ","े":"e","ै":"ai","ो":"o","ौ":"au","ं":"ṃ","ः":"ḥ","्":"",ऽ:"'",ॐ:"Oṃ",क:"ka",ख:"kha",ग:"ga",घ:"gha",ङ:"ṅa",च:"ca",छ:"cha",ज:"ja",झ:"jha",ञ:"ña",ट:"ṭa",ठ:"ṭha",ड:"ḍa",ढ:"ḍha",ण:"ṇa",त:"ta",थ:"tha",द:"da",ध:"dha",न:"na",प:"pa",फ:"pha",ब:"ba",भ:"bha",म:"ma",य:"ya",र:"ra",ल:"la",व:"va",श:"śa",ष:"ṣa",स:"sa",ह:"ha",ळ:"ḷa",क्ष:"kṣa",ज्ञ:"jña","०":"0","१":"1","२":"2","३":"3","४":"4","५":"5","६":"6","७":"7","८":"8","९":"9","।":"|","॥":"||"};function Xa(o,a,e){let i="";const t=F(o);for(let r=0;r<t.length;r++){const n=t[r],l=t.charCodeAt(r);if(n==="ॐ"){i+=Qa[e]||"ॐ";continue}if(l===2404||l===2405){i+=n;continue}if(l>=2305&&l<=2416){if(e==="ta"){const u={ख:"க",ग:"க",घ:"க",ङ:"ங",च:"ச",छ:"ச",ज:"ஜ",झ:"ச",ञ:"ஞ",ठ:"ட",ड:"ட",ढ:"ட",थ:"த",द:"த",ध:"த",फ:"ப",ब:"ப",भ:"ப",श:"ஶ",ष:"ஷ",स:"ஸ",ह:"ஹ",क्ष:"க்ஷ",ऋ:"ரி",ॠ:"ரீ","ृ":"்ரி","ॄ":"்ரீ","ं":"ம்","ः":"ஃ"};if(u[n]){i+=u[n];continue}}if(e==="bn"){if(n==="व"){i+="ব";continue}if(n==="र"){i+="র";continue}}if(e==="or"&&n==="व"){i+="ୱ";continue}if(e==="ml"&&n==="र"&&t[r+1]==="्"){i+="ർ",r++;continue}const d=l+a;i+=String.fromCharCode(d)}else i+=n}return i}function ae(o){const a=F(o);let e="",i=0;for(;i<a.length;){const t=a[i],r=a[i+1];if(t==="्"){i++;continue}if(Y[t]){let n=Y[t];if(n.endsWith("a")){if(r&&["ा","ि","ी","ु","ू","ृ","ॄ","े","ै","ो","ौ"].includes(r)){n=n.slice(0,-1)+Y[r],i+=2,e+=n;continue}else if(r==="्"){n=n.slice(0,-1),i+=2,e+=n;continue}}e+=n,i++}else e+=t,i++}return e}function m(o,a,e=!0){if(!o)return"";if(a==="sa"||a==="hi"||a==="mr")return e?F(o):o;if(a==="en")return ae(o);const t={bn:128,gu:384,or:512,ta:640,te:768,kn:896,ml:1024}[a];return t!==void 0?Xa(o,t,a):e?F(o):o}const ee=[{id:"all",name:"All Shrines",sanskrit:"सर्वदेवाः",icon:"🕉️"},{id:"ganesha",name:"Sri Ganesha",sanskrit:"श्रीगणेशः",icon:"🐘"},{id:"shiva",name:"Lord Shiva",sanskrit:"श्रीमहादेवः",icon:"🔱"},{id:"vishnu",name:"Lord Vishnu",sanskrit:"श्रीमहाविष्णुः",icon:"🪷"},{id:"krishna",name:"Sri Krishna",sanskrit:"श्रीकृष्णः",icon:"🦚"},{id:"rama",name:"Sri Rama",sanskrit:"श्रीरामचन्द्रः",icon:"🏹"},{id:"hanuman",name:"Sri Hanuman",sanskrit:"श्रीहनुमान्",icon:"🚩"},{id:"lakshmi",name:"Maa Lakshmi",sanskrit:"महालक्ष्मीः",icon:"🪙"},{id:"durga",name:"Maa Durga",sanskrit:"दुर्गाभवानी",icon:"🦁"},{id:"saraswati",name:"Maa Saraswati",sanskrit:"भगवती सरस्वती",icon:"🪕"},{id:"murugan",name:"Lord Murugan",sanskrit:"सुब्रह्मण्यः",icon:"🪶"},{id:"venkateswara",name:"Sri Venkateswara",sanskrit:"श्रीवेङ्कटेश्वरः",icon:"👑"},{id:"ayyappan",name:"Lord Ayyappan",sanskrit:"धर्मशास्ता",icon:"🔔"}],pa=[{id:"ganesha-pancharatnam",title:"Ganesha Pancharatnam (Verse 1)",deityId:"ganesha",deity:"Sri Ganesha",category:"Stotra",source:"Adi Shankaracharya Stotraavali",meter:"Malini",devanagari:`मुदाकरात्तमोदकं सदा विमुक्तिसाधकं
कलाधरावतंसकं विलासिलोकरक्षकम् ।
अनायकैकनायकं विनाशितेभदैत्यकं
नताशुभाशूनाशकं नमामि तं विनायकम् ॥`,iast:`mudākarātta-modakaṃ sadā vimukti-sādhakaṃ
kalādharāvataṃsakaṃ vilāsi-loka-rakṣakam ।
anāyakaika-nāyakaṃ vināśitebha-daityakaṃ
natāśubhāśūnāśakaṃ namāmi taṃ vināyakam ॥`,sabdartha:[{word:"मुदाकरात्तमोदकम्",meaning:"Holding the sweet modaka with joyous grace"},{word:"सदा विमुक्तिसाधकम्",meaning:"Who constantly bestows ultimate spiritual liberation"},{word:"कलाधरावतंसकम्",meaning:"Adorned with the crescent moon on His crown"},{word:"विलासिलोकरक्षकम्",meaning:"The compassionate protector of the whole creation"},{word:"अनायकैकनायकम्",meaning:"The supreme leader of those who have no protector"},{word:"विनाशितेभदैत्यकम्",meaning:"The destroyer of the arrogant demon Gajasura"},{word:"नताशुभाशूनाशकम्",meaning:"Who swiftly dissolves the misfortunes of surrendered devotees"},{word:"नमामि तं विनायकम्",meaning:"I bow before that supreme remover of obstacles, Sri Vinayaka"}],translation:"Holding a delightful sweet modaka in His hand, ever bestowing liberation, wearing the crescent moon upon His crown, protecting the manifested universe, the supreme refuge of the helpless, the destroyer of the demon Gajasura, who swiftly dissolves the inauspicious obstacles of those who surrender to Him — to that supreme Lord Vinayaka, I bow with deep reverence.",purport:"Composed by Jagadguru Adi Shankaracharya, the Ganesha Pancharatnam invokes Lord Ganesha not merely as an elephant-headed deity of fortune, but as the cosmic archetype of supreme intellect and compassion."},{id:"vakratunda-mahakaya",title:"Vakratunda Mahakaya (Prarthana)",deityId:"ganesha",deity:"Sri Ganesha",category:"Mantra",source:"Mudgala Purana & Brahma Vaivarta Purana",meter:"Anushtubh",devanagari:`वक्रतुण्ड महाकाय सूर्यकोटिसमप्रभ ।
निर्विघ्नं कुरु मे देव सर्वकार्येषु सर्वदा ॥`,iast:`vakratuṇḍa mahākāya sūryakoṭi-samaprabha ।
nirvighnaṃ kuru me deva sarva-kāryeṣu sarvadā ॥`,sabdartha:[{word:"वक्रतुण्ड",meaning:"O Lord with the gracefully curved trunk"},{word:"महाकाय",meaning:"Possessor of the vast, cosmic form"},{word:"सूर्यकोटिसमप्रभ",meaning:"Whose radiance equals ten million blazing suns"},{word:"निर्विघ्नम्",meaning:"Free of hindrances, impediments, or obstacles"},{word:"कुरु",meaning:"Please make / render"},{word:"मे",meaning:"My"},{word:"देव",meaning:"O Divine Lord"},{word:"सर्वकार्येषु",meaning:"In all endeavors and righteous duties"},{word:"सर्वदा",meaning:"At all times and across all paths"}],translation:"O Lord of the curved trunk and immense cosmic form, whose divine brilliance equals ten million suns: please remove all obstacles from all my endeavors, always and in every step.",purport:"The universal opening invocation of Sanatana Dharma. The curved trunk (Vakra-tunda) symbolizes the primordial sound Pranava Om, capable of breaking through the densest material and karmic blockages."},{id:"maha-mrityunjaya",title:"Maha Mrityunjaya Mantra (Rudra Mantra)",deityId:"shiva",deity:"Lord Shiva",category:"Mantra",source:"Rigveda Samhita (Mandala 7, Sukta 59, Mantra 12)",meter:"Anushtubh",devanagari:`ॐ त्र्यम्बकं यजामहे सुगन्धिं पुष्टिवर्धनम् ।
उर्वारुकमिव बन्धनान्मृत्यchainsोर्मुक्षीय माऽमृतात् ॥`.replace("chains",""),iast:`oṃ tryambakaṃ yajāmahe sugandhiṃ puṣṭi-vardhanam ।
urvārukam iva bandhanān mṛtyor mukṣīya mā'mṛtāt ॥`,sabdartha:[{word:"त्र्यम्बकम्",meaning:"The Three-Eyed Lord Shiva, perceiver of past, present, and future"},{word:"यजामहे",meaning:"We worship, revere, and adore"},{word:"सुगन्धिम्",meaning:"The fragrant one, emitting divine virtue and wisdom"},{word:"पुष्टिवर्धनम्",meaning:"The nourisher of all life, who enhances vitality"},{word:"उर्वारुकम् इव",meaning:"Just like a fully ripened melon"},{word:"बन्धनात्",meaning:"From its stem and the bondage of attachment"},{word:"मृत्योः मुक्षीय",meaning:"May You liberate us from physical mortality and suffering"},{word:"मा अमृतात्",meaning:"Never separating us from the nectar of divine truth"}],translation:"We worship the Three-Eyed Lord Shiva, who is fragrant with transcendental virtue and nourishes all living beings. Just as a ripe melon effortlessly detaches from its vine, may He liberate us from the bondage of death and mortality, without separating us from Immortality.",purport:"Revealed by Rishi Markandeya, this profound healing mantra conquers fear of death and bodily decay. Devotees chant it 108 times daily to neutralize afflictions and cultivate fearless detachment."},{id:"vishnu-sahasranama-dhyanam",title:"Sri Vishnu Sahasranama (Dhyana Sloka)",deityId:"vishnu",deity:"Lord Vishnu",category:"Stotra",source:"Mahabharata (Anushasana Parva, Section 149)",meter:"Anushtubh",devanagari:`शान्ताकारं भुजगशयनं पद्मनाभं सुरेशं
विश्वाधारं गगनसदृशं मेघवर्णं शुभाङ्गम् ।
लक्ष्मीकान्तं कमलनयनं योगिभिर्ध्यानगम्यं
वन्दे विष्णुं भवभयहरं सर्वलोकैकनाथम् ॥`,iast:`śāntākāraṃ bhujaga-śayanaṃ padma-nābhaṃ sureśaṃ
viśvādhāraṃ gagana-sadṛśaṃ megha-varṇaṃ śubhāṅgam ।
lakṣmī-kāntaṃ kamala-nayanaṃ yogibhir-dhyāna-gamyaṃ
vande viṣṇuṃ bhava-bhaya-haraṃ sarva-lokaika-nātham ॥`,sabdartha:[{word:"शान्ताकारम्",meaning:"Embodiment of serenity and unshakable tranquility"},{word:"भुजगशयनम्",meaning:"Resting upon the serpent Ananta Sesha"},{word:"पद्मनाभम्",meaning:"From whose navel blossoms the cosmic lotus of creation"},{word:"सुरेशम्",meaning:"Lord of the celestials and gods"},{word:"विश्वाधारम्",meaning:"The ultimate foundation and support of the entire universe"},{word:"गगनसदृशम्",meaning:"Infinite, unbounded, and all-pervading like space"},{word:"मेघवर्णम्",meaning:"Having the soothing, merciful hue of rain-bearing clouds"},{word:"लक्ष्मीकान्तम्",meaning:"The beloved consort of Goddess Lakshmi"},{word:"भवभयहरम्",meaning:"The dispeller of fears of samsara"}],translation:"I bow to Lord Vishnu, the embodiment of peace, reclining upon the cosmic serpent Ananta, whose navel produces the creator Brahma upon a lotus. The bedrock of creation, vast as the sky, dark as a rain-cloud, consort of Lakshmi, realized through meditation by yogis: I revere Vishnu, who banishes the fears of mortal existence.",purport:"Composed by Bhishma Pitamaha upon the arrow bed in the presence of Lord Krishna. Reciting this dhyana sloka aligns the mind with the all-sustaining preservation energy of the cosmos."},{id:"gita-2-47",title:"Nishkama Karma (Gita 2.47)",deityId:"krishna",deity:"Sri Krishna",category:"Mantra",source:"Srimad Bhagavad Gita (Chapter 2, Verse 47)",meter:"Anushtubh",devanagari:`कर्मण्येवाधिकारस्ते मा फलेषु कदाचन ।
मा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि ॥`,iast:`karmaṇy-evādhikāras-te mā phaleṣu kadācana ।
mā karma-phala-hetur-bhūr-mā te saṅgo'stv-akarmaṇi ॥`,sabdartha:[{word:"कर्मणि एव",meaning:"In action alone lies your rightful domain"},{word:"अधिकारः ते",meaning:"Your prerogative and moral responsibility"},{word:"मा फलेषु कदाचन",meaning:"Never in the fruits or outcomes"},{word:"मा कर्मफलहेतुः भूः",meaning:"Do not let the outcome be your sole motive"},{word:"मा ते सङ्गः अस्तु अकर्मणि",meaning:"Nor let your heart become attached to inaction"}],translation:"You have a right only to perform your prescribed duty, but never to the fruits of action. Let not the fruit of action be your motive, nor let your attachment be toward inaction.",purport:"The cardinal formula for liberation in everyday modern life. By decoupling one's emotional well-being from uncontrollable external results, one attains boundless focus, resilience, and joyful mastery."},{id:"rama-raksha-opening",title:"Sri Rama Raksha Stotram (Opening)",deityId:"rama",deity:"Sri Rama",category:"Stotra",source:"Padma Purana (Revealed by Sage Budha Kaushika)",meter:"Anushtubh",devanagari:`चरितं रघुनाथस्य शतकोटिप्रविस्तरम् ।
एकैकमक्षरं पुंसां महापातकनाशनम् ॥
ध्यात्वा नीलोत्पलश्यामं रामं राजीवलोचनम् ।
जानकीलक्ष्मणोपेतं जटामुकुटमण्डितम् ॥`,iast:`caritaṃ raghunāthasya śatakoṭi-pravistaram ।
ekaikam akṣaraṃ puṃsāṃ mahāpātaka-nāśanam ॥
dhyātvā nīlotpala-śyāmaṃ rāmaṃ rājīva-locanam ।
jānakī-lakṣmaṇopetaṃ jaṭā-mukuṭa-maṇḍitam ॥`,sabdartha:[{word:"चरितम् रघुनाथस्य",meaning:"The divine life story of Sri Raghunatha (Lord Rama)"},{word:"शतकोटिप्रविस्तरम्",meaning:"Extending across a billion verses in scope"},{word:"एकैकम् अक्षरम्",meaning:"Every single syllable of which"},{word:"महापातकनाशनम्",meaning:"Has the power to eradicate the gravest sins and karmas"},{word:"नीलोत्पलश्यामम्",meaning:"Having the radiant hue of a blue water lily"},{word:"राजीवलोचनम्",meaning:"Endowed with gentle lotus eyes"},{word:"जानकीलक्ष्मणोपेतम्",meaning:"Accompanied by Mother Sita and faithful Lakshmana"}],translation:"The holy deeds of Sri Rama span a billion verses; every single syllable destroys the gravest karmic misdeeds. Meditating on Rama, dark-complexioned like the blue lotus, lotus-eyed, wearing crowns of matted locks, accompanied by Sita and Lakshmana — we seek His celestial shield.",purport:"Sage Budha Kaushika received this armour of protection in a sacred dream from Lord Shiva Himself. It surrounds the chanter's physical body, aura, and mind with an impenetrable circle of divine protection."},{id:"hanuman-chalisa-opening",title:"Sri Hanuman Chalisa (Doha & Chaupai 1)",deityId:"hanuman",deity:"Sri Hanuman",category:"Chalisa",source:"Goswami Tulsidas (Awadhi / Sanskrit Tradition)",meter:"Doha & Chaupai",devanagari:`श्रीगुरु चरन सरोज रज निज मनु मुकुरु सुधारि ।
बरनउँ रघुबर बिमल जसु जो दायकु फल चारि ॥
बुद्धिहीन तनु जानिके सुमिरौ पवन-कुमार ।
बल बुधि बिद्या देहु मोहिं हरहु कलेस बिकार ॥
जय हनुमान ज्ञान गुन सागर ।
जय कपीस तिहुँ लोक उजागर ॥`,iast:`śrī-guru carana saroja raja nija manu mukuru sudhāri ।
baranauṃ raghubara bimala jasu jo dāyaku phala cāri ॥
buddhi-hīna tanu jānike sumirau pavana-kumāra ।
bala budhi bidyā dehu mohiṃ harahu kalesa bikāra ॥
jaya hanumāna jñāna guna sāgara ।
jaya kapīsa tihuṃ loka ujāgara ॥`,sabdartha:[{word:"श्रीगुरु चरन सरोज रज",meaning:"With the sacred dust of the Guru's lotus feet"},{word:"निज मनु मुकुरु सुधारि",meaning:"Cleansing the mirror of my heart and mind"},{word:"बरनउँ रघुबर बिमल जसु",meaning:"I celebrate the pure glory of Sri Rama"},{word:"जो दायकु फल चारि",meaning:"Which grants the four life aims: Dharma, Artha, Kama, Moksha"},{word:"जय हनुमान",meaning:"Victory to Lord Hanuman"},{word:"ज्ञान गुन सागर",meaning:"Ocean of transcendental wisdom and supreme virtues"}],translation:"Cleansing the mirror of my mind with the dust from my Guru's lotus feet, I sing the unblemished glory of Sri Rama, which grants the four fruits of life. Knowing myself to be deficient in strength and wisdom, I meditate upon the Son of the Wind: grant me physical vigor, intellectual clarity, and divine knowledge, and vanquish my sorrows and mental impurities. Hail Hanuman, vast ocean of wisdom and virtues; hail the king of monkeys, who illumines the three cosmic worlds!",purport:"Chanted by hundreds of millions daily across the globe. Tulsidas wrote this while imprisoned, proving the power of pure devotion to dissolve mortal entrapment and mental distress."},{id:"mahalakshmi-ashtakam",title:"Sri Mahalakshmi Ashtakam (Verse 1)",deityId:"lakshmi",deity:"Maa Lakshmi",category:"Ashtakam",source:"Padma Purana (Uttered by Lord Indra)",meter:"Anushtubh",devanagari:`नमस्तेऽस्तु महामाये श्रीपीठे सुरपूजिते ।
शङ्खचक्रगदाहस्ते महालक्ष्मि नमोऽस्तु ते ॥`,iast:`namas-te'stu mahāmāye śrī-pīṭhe sura-pūjite ।
śaṅkha-cakra-gadā-haste mahālakṣmi namo'stu te ॥`,sabdartha:[{word:"नमस्ते अस्तु",meaning:"Salutations unto You"},{word:"महामाये",meaning:"O Divine Mother of supreme cosmic power (Mahamaya)"},{word:"श्रीपीठे",meaning:"Dweller upon the sacred seat of fortune (Shri Peetha)"},{word:"सुरपूजिते",meaning:"Revered and adored by all the devas"},{word:"शङ्खचक्रगदाहस्ते",meaning:"Holding the conch, discus, and mace in Your hands"},{word:"महालक्ष्मि",meaning:"O Supreme Mother Lakshmi"},{word:"नमोऽस्तु ते",meaning:"I offer my humble prostrations unto You"}],translation:"Salutations unto You, O Supreme Mother, sovereign of all cosmic illusion, seated upon the seat of prosperity, worshipped by all the celestials! Adorned with the divine conch, discus, and mace in Your hands — O Mother Mahalakshmi, I bow before You in adoration.",purport:"When Lord Indra lost all prosperity due to ego, he sang this eight-verse hymn to invoke Mother Lakshmi. She represents not merely financial currency, but the eightfold wealth (Ashta Lakshmi): courage, progeny, knowledge, food, spiritual sovereignty, and inner joy."},{id:"mahishasura-mardini-opening",title:"Aigiri Nandini (Mahishasura Mardini Stotram)",deityId:"durga",deity:"Maa Durga",category:"Stotra",source:"Adi Shankaracharya Tradition",meter:"Matra-chandas (Dynamic rhythm)",devanagari:`अयि गिरिनन्दिनि नन्दितमेदिनि विश्वविनोदिनि नन्दसुते
गिरिवरविन्ध्यशिरोऽधिनिवासिनि विष्णुविलासिनि जिष्णुनुते ।
भगवति हे शितिकण्ठकुटुम्बिनि भूरिकुटुम्बिनि भूरिकृते
जय जय हे महिषासुरमर्दिनि रम्यकपर्दिनि शैलसुते ॥`,iast:`ayi giri-nandini nandita-medini viśva-vinodini nanda-sute
girivara-vindhya-śiro'dhinivāsini viṣṇu-vilāsini jiṣṇu-nute ।
bhagavati he śitikaṇṭha-kuṭumbini bhūri-kuṭumbini bhūri-kṛte
jaya jaya he mahiṣāsura-mardini ramya-kapardini śaila-sute ॥`,sabdartha:[{word:"अयि गिरिनन्दिनि",meaning:"O Daughter of the sacred Mountain (Himavan)"},{word:"नन्दितमेदिनि",meaning:"Who brings joy and delight to the Mother Earth"},{word:"विश्वविनोदिनि",meaning:"Who rejoices in the play of the universe"},{word:"विष्णुविलासिनि",meaning:"Beloved sister of Lord Vishnu"},{word:"महिषासुरमर्दिनि",meaning:"Destroyer of the demon of delusion, Mahishasura"},{word:"रम्यकपर्दिनि",meaning:"Adorned with gorgeous braided locks of hair"},{word:"शैलसुते",meaning:"O Divine Daughter of the Mountain!"}],translation:"O Daughter of the Mountain, who gladdens the earth, who delights the cosmos, sister of Nanda, dwelling on the peaks of the Vindhya range, beloved of Vishnu, praised by Indra! O Consort of Shiva, Mother of all cosmic beings, who accomplishes great deeds — victory, victory unto You, O destroyer of Mahishasura, with exquisitely braided locks!",purport:"The sonic thunder of this hymn elevates the vitality of the chanter. Mahishasura represents dullness (Tamas), sloth, and destructive arrogance; Mother Durga's trident awakens radiant courage (Rajas purified by Sattva)."},{id:"saraswati-namastubhyam",title:"Saraswati Namastubhyam (Vidya Prarthana)",deityId:"saraswati",deity:"Maa Saraswati",category:"Mantra",source:"Saraswati Rahasya Upanishad",meter:"Anushtubh",devanagari:`सरस्वति नमस्तुभ्यं वरदे कामरूपिणि ।
विद्यारम्भं करिष्यामि सिद्धिर्भवतु मे सदा ॥`,iast:`sarasvati namas-tubhyaṃ varade kāma-rūpiṇi ।
vidyārambhaṃ kariṣyāmi siddhir-bhavatu me sadā ॥`,sabdartha:[{word:"सरस्वति",meaning:"O Goddess Saraswati, embodiment of flow and knowledge"},{word:"नमस्तुभ्यम्",meaning:"My humble prostrations unto You"},{word:"वरदे",meaning:"Giver of righteous boons and spiritual clarity"},{word:"कामरूपिणि",meaning:"Who fulfills pure auspicious aspirations"},{word:"विद्यारम्भम्",meaning:"Commencement of studies and learning"},{word:"करिष्यामि",meaning:"I am about to undertake"},{word:"सिद्धिः भवतु मे सदा",meaning:"May mastery, fulfillment, and illumination be mine always"}],translation:"O Goddess Saraswati, giver of blessings, fulfiller of all pure aspirations! As I begin my quest for wisdom, grant me unfailing success, mastery, and spiritual insight at all times.",purport:"The quintessential prayer for students, writers, and spiritual seekers. It establishes a sacred orientation to education: studying not just for career vanity, but for the blossoming of spiritual consciousness."},{id:"subrahmanya-bhujangam-verse1",title:"Subrahmanya Bhujangam (Opening Dhyana)",deityId:"murugan",deity:"Lord Murugan",category:"Stotra",source:"Adi Shankaracharya (Tiruchendur Kshetram)",meter:"Bhujangaprayata",devanagari:`सदा बालरूपाऽपि विघ्नाद्रिहन्त्री
महादन्तिवक्त्राऽपि पञ्चास्यमान्या ।
विधीन्द्रादिमृग्या गणेषाभिधा मे
विधत्तां श्रियं काऽपि कल्याणमूर्तिः ॥`,iast:`sadā bālarūpā'pi vighnādri-hantrī
mahā-danti-vaktrā'pi pañcāsya-mānyā ।
vidhīndrādi-mṛgyā gaṇeṣābhidhā me
vidhattāṃ śriyaṃ kā'pi kalyāṇa-mūrtiḥ ॥`,sabdartha:[{word:"सदा बालरूपा अपि",meaning:"Though ever appearing in the sweet form of a divine child"},{word:"विघ्नाद्रिहन्त्री",meaning:"Smasher of mountains of obstacles"},{word:"कल्याणमूर्तिः",meaning:"Embodiment of supreme auspiciousness and grace"},{word:"विधत्तां श्रियम्",meaning:"May He bestow boundless divine welfare and wisdom"}],translation:"Though appearing ever as a youthful child, He smashes mountains of obstacles; sought after by Brahma, Indra, and the gods, embodiment of eternal auspiciousness: may Lord Subrahmanya bestow divine grace, courage, and prosperity upon me.",purport:"Composed by Adi Shankaracharya at the seashore temple of Tiruchendur. Lord Murugan represents the sharp spear of spiritual discernment (Vel), cutting through the six inner enemies (Arishadvargas)."},{id:"venkateswara-suprabhatam-verse1",title:"Sri Venkateswara Suprabhatam (Verse 1)",deityId:"venkateswara",deity:"Sri Venkateswara",category:"Suprabhatam",source:"Sri Prativadi Bhayankaram Annan (Tirumala Kshetram)",meter:"Vasantatilaka",devanagari:`कौसल्या सुप्रजा राम पूर्वा सन्ध्या प्रवर्तते ।
उत्तिष्ठ नरशार्दूल कर्तव्यं दैवमाह्निकम् ॥`,iast:`kausalyā supra-jā rāma pūrvā sandhyā pravartate ।
uttiṣṭha nara-śārdūla kartavyaṃ daivam āhnikam ॥`,sabdartha:[{word:"कौसल्या सुप्रजा",meaning:"O noble son of mother Kausalya"},{word:"राम",meaning:"O Lord Rama (invoked as Lord of Seven Hills)"},{word:"पूर्वा सन्ध्या प्रवर्तते",meaning:"The auspicious eastern dawn has broken across the sky"},{word:"उत्तिष्ठ",meaning:"Please awaken from Your divine slumber"},{word:"नरशार्दूल",meaning:"O lion among human beings / sovereign Lord"},{word:"कर्तव्यम् दैवम् आह्निकम्",meaning:"The divine morning prayers and daily duties await Your presence"}],translation:"O noble son of Kausalya! The sacred eastern dawn has arrived. Awaken, O lion among leaders of men; the divine morning duties must now be performed for the welfare of the cosmos.",purport:"Sung every dawn at Tirumala Tirupati Devasthanam to gently awaken Lord Srinivasa. Listening to this suprabhatam at dawn aligns the human biological clock with the cosmic rhythms of light and devotion."},{id:"harivarasanam-verse1",title:"Harivarasanam (Viswamohanam - Verse 1)",deityId:"ayyappan",deity:"Lord Ayyappan",category:"Stotra",source:"Sri Kumbakudi Kulathur Iyer (Sabarimala Tradition)",meter:"Sanskrit Devotional Padam",devanagari:`हरिवरासनं विश्वमोहनं
हरिदधीश्वरं आराध्यपादुकम् ।
अरिविमर्दनं नित्यनर्तनं
हरिहरात्मजं देवमाश्रये ॥
शरणं अय्यप्पा स्वामि शरणं अय्यप्पा ।
शरणं अय्यप्पा स्वामि शरणं अय्यप्पा ॥`,iast:`hari-varāsanaṃ viśva-mohanaṃ
hari-dadhīśvaraṃ ārādhya-pādukam ।
ari-vimardanaṃ nitya-nartanaṃ
hari-harātmajaṃ devam āśraye ॥
śaraṇaṃ ayyappā svāmi śaraṇaṃ ayyappā ।
śaraṇaṃ ayyappā svāmi śaraṇaṃ ayyappā ॥`,sabdartha:[{word:"हरिवरासनम्",meaning:"Seated upon the glorious throne of Lord Hari"},{word:"विश्वमोहनम्",meaning:"Whose divine enchantment mesmerizes the entire cosmos"},{word:"आराध्यपादुकम्",meaning:"Whose sacred sandals are adored by yogis and ascetics"},{word:"अरिविमर्दनम्",meaning:"Destroyer of demonic enemies and inner delusion"},{word:"हरिहरात्मजम्",meaning:"Born of the holy union of Hari (Vishnu) and Hara (Shiva)"},{word:"देवम् आश्रये",meaning:"I surrender unto that supreme Divine Lord"}],translation:"Seated on the throne of Hari, the charmer of the universe, whose sacred sandals are worshipped by all, who vanquishes all enemies and dances eternally in blissful truth: born of Hari and Hara, in that Divine Lord Ayyappa I take refuge! Swamiye Saranam Ayyappa!",purport:"The celestial lullaby of Sabarimala. Chanted every night before the sanctum sanctorum doors close. It unifies the Vaishnava and Shaiva traditions into pure non-dual surrender."},{id:"gayatri-mantra",title:"Gayatri Mantra",deityId:"all",deity:"Universal (Savitr)",category:"Mantra",source:"Rigveda Samhita (Mandala 3, Sukta 62, Mantra 10)",meter:"Gayatri (24 syllables)",devanagari:`ॐ भूर्भुवः स्वः ।
तत्सवितुर्वरेण्यं भर्गो देवस्य धीमहि ।
धियो यो नः प्रचोदयात् ॥`,iast:`oṃ bhūr bhuvaḥ svaḥ ।
tat savitur vareṇyaṃ bhargo devasya dhīmahi ।
dhiyo yo naḥ pracodayāt ॥`,sabdartha:[{word:"ॐ (Om)",meaning:"The primordial sound, supreme cosmic reality"},{word:"भूः भुवः स्वः",meaning:"The physical, astral, and celestial planes"},{word:"तत् सवितुः वरेण्यम्",meaning:"That most adorable Light of the Divine Sun"},{word:"भर्गः देवस्य धीमहि",meaning:"We meditate upon the spiritual radiance of the Creator"},{word:"धियो यो नः प्रचोदयात्",meaning:"May that effulgence illuminate and guide our intellect"}],translation:"We meditate upon the supreme, most adorable radiance of that Divine Creator, the Sun of consciousness. May that effulgent Light illuminate, guide, and inspire our spiritual intellect and discernment.",purport:"The crown jewel of Vedic revelation. It is a sacred invocation for the awakening of higher intellect (Buddhi), clearing mental fog and aligning the human nervous system with cosmic intelligence."},{id:"shanti-mantra",title:"Sarve Bhavantu Sukhinah (Universal Peace)",deityId:"all",deity:"Universal (Paramatman)",category:"Prayer",source:"Brihadaranyaka Upanishad Tradition",meter:"Anushtubh",devanagari:`ॐ सर्वे भवन्तु सुखिनः सर्वे सन्तु निरामयाः ।
सर्वे भद्राणि पश्यन्तु मा कश्चिद्दुःखभाग्भवेत् ॥
ॐ शान्तिः शान्तिः शान्तिः ॥`,iast:`oṃ sarve bhavantu sukhinaḥ sarve santu nirāmayāḥ ।
sarve bhadrāṇi paśyantu mā kaścid duḥkha-bhāg bhavet ॥
oṃ śāntiḥ śāntiḥ śāntiḥ ॥`,sabdartha:[{word:"सर्वे भवन्तु सुखिनः",meaning:"May all beings everywhere be happy and peaceful"},{word:"सर्वे सन्तु निरामयाः",meaning:"May all beings be free from sickness and disease"},{word:"सर्वे भद्राणि पश्यन्तु",meaning:"May all behold goodness and nobility in each other"},{word:"मा कश्चित् दुःखभाग् भवेत्",meaning:"May no one be a partaker of grief or suffering"},{word:"शान्तिः",meaning:"Peace across body, mind, and soul"}],translation:"May all beings everywhere be happy. May all beings be free from disease and illness. May all behold only auspiciousness and goodness in one another. May no one suffer or be partaker of sorrow. Om Peace, Peace, Peace.",purport:"The living motto of Sanatana Dharma: Vasudhaiva Kutumbakam. It blesses humans, animals, nature, and every realm in existence with peace and wellness."}],ya=[{id:"lion-and-hare",title:"The Lion and the Clever Hare",collection:"Panchatantra (Book 1: Mitra-bheda — The Loss of Friends)",author:"Pandit Vishnu Sharma (circa 300 BCE)",sanskritEpigraph:`बुद्धिर्यस्य बलं तस्य निर्बुद्धेस्तु कुतो बलम् ।
वने सिंहो मदोन्मत्तः शशकेन निपातितः ॥`,epigraphTranslation:"He who possesses intellect possesses true power; what strength does one without wisdom have? A mighty lion intoxicated with pride was slain in the forest by a humble hare.",summary:"Bhasuraka, a ferocious lion, slaughtered animals indiscriminately. The terrified animals agreed to send one prey daily. When it was the little hare's turn, he arrived late and claimed another lion had stopped him. Bhasuraka furiously demanded to see the rival. The hare led the lion to a deep well; seeing his own reflection and hearing his echo, the furious lion leaped in and perished.",vocabulary:[{term:"Bhasuraka (भासुरक)",meaning:"Shining or fierce; the name of the lion"},{term:"Yukti (युक्ति)",meaning:"Strategic resourcefulness; applying intellect over brute force"},{term:"Mada (मद)",meaning:"Blind arrogance, hubris arising from physical power"}],moral:"Wisdom and presence of mind conquer brute physical force. Arrogance clouds perception, making even the mighty destroy themselves.",quiz:{question:"In situations where you face an overwhelming challenge against which you have no physical leverage, what is the core Vedic strategic response?",options:["React in panic and despair","Use calm discernment (Buddhi), self-control, and the adversary's own arrogance against them","Surrender completely without thinking"],correctIndex:1,explanation:"Vedic statecraft (Niti Shastra) teaches that Buddhi (spiritual intellect) is superior to physical might (Bahu-bala). The hare did not fight the lion; he allowed the lion's own rage and illusion (Maya) to cause his downfall."}},{id:"monkey-and-crocodile",title:"The Monkey and the Crocodile",collection:"Panchatantra (Book 4: Labdhapranasham — Loss of Gains)",author:"Pandit Vishnu Sharma",sanskritEpigraph:`आपत्काले तु संप्राप्ते यस्य बुद्धिर्न हीयते ।
स एव तरते दुर्गाणि जलबद्ध इव प्लवः ॥`,epigraphTranslation:"When calamity strikes, he whose presence of mind does not waver crosses over treacherous perils, just like a sturdy raft upon tempestuous waters.",summary:"Raktamukha, a monkey living in a rose-apple tree by the river, befriended Karalamukha, a crocodile, sharing sweet fruits. The crocodile's greedy wife desired to eat the monkey's heart. Trapped mid-river on the crocodile's back, the monkey remained calm and claimed he had left his heart safe inside the hollow of the tree. The foolish crocodile swam back, allowing the monkey to leap to safety.",vocabulary:[{term:"Pratyutpannamati (प्रत्युत्पन्नमति)",meaning:"Instantaneous presence of mind during sudden peril"},{term:"Mitra-droha (मित्रद्रोह)",meaning:"Betrayal of trust between friends"}],moral:"Presence of mind in moments of mortal danger saves life. Betrayal destroys friendship forever.",quiz:{question:"What saved the monkey when trapped in the middle of the river?",options:["Physical fighting against the crocodile","Retaining composure and using swift psychological wit","Crying out for help to other animals"],correctIndex:1,explanation:"Panic paralyzes thinking. By remaining calm and fabricating a convincing story about leaving his heart on the tree, the monkey navigated a lethal situation peacefully."}},{id:"three-idols-tenali-raman",title:"Tenali Raman and the Three Idols",collection:"Tales of Tenali Ramakrishna",author:"Folkloric Heritage of Vijayanagara Empire",sanskritEpigraph:`श्रूयतां धर्मसर्वस्वं श्रुत्वा चैवावधार्यताम् ।
आत्मनः प्रतिकूलानि परेषां न समाचरेत् ॥`,epigraphTranslation:"Listen to the essence of Dharma, and having heard it, keep it firmly in your heart: That which is painful or detrimental to oneself, never inflict upon others.",summary:"A foreign scholar presented King Krishnadevaraya with three identical golden idols, challenging the court to determine which was superior. Tenali Raman inserted a thin straw into the ear of each idol. In the first, the straw emerged from the other ear (the person who hears and instantly forgets). In the second, the straw emerged from the mouth (the person who hears a secret and immediately gossips). In the third, the straw passed directly into the heart (the noble person who hears wisdom, reflects upon it, and preserves confidence). Raman declared the third idol the best.",vocabulary:[{term:"Shravana (श्रवण)",meaning:"The art of deep, attentive spiritual listening"},{term:"Manana (मनन)",meaning:"Internal reflection, assimilating knowledge into the heart"},{term:"Nididhyasana (निदिध्यासन)",meaning:"Living and manifesting truth in daily character"}],moral:"A person's true character is revealed by how they handle what they hear: whether they leak it, gossip, or assimilate it into noble conduct.",quiz:{question:"Which type of listener did the third golden idol represent?",options:["The gossip who repeats everything they hear","The person who absorbs wisdom deeply into their heart and preserves trust","The inattentive person who lets advice pass through one ear and out the other"],correctIndex:1,explanation:"True character (Sheela) lies in deep assimilation (Manana). Spiritual seekers must be like the third idol—absorbing truth into the heart rather than broadcasting idle speech."}},{id:"satyakama-jabala",title:"Satyakama Jabala and the Voice of Truth",collection:"Chandogya Upanishad (Chapter 4, Section 4)",author:"Ancient Vedic Sage Tradition",sanskritEpigraph:`सत्यमेव जयते नानृतं
सत्येन पन्था विततो देवयानः ।`,epigraphTranslation:"Truth alone triumphs, never falsehood. By truth is paved the divine pathway of spiritual liberation.",summary:"Young Satyakama wished to study Brahmavidya under Sage Gautama. When asked his lineage (gotra), his mother Jabala candidly told him she had served many masters in her youth and did not know his lineage. Satyakama truthfully repeated this to Gautama. Overjoyed by his uncompromising honesty, the sage declared: 'None but a true Brahmana could speak such unvarnished truth.' Gautama initiated him into the highest wisdom.",vocabulary:[{term:"Satya (सत्य)",meaning:"Unyielding adherence to truth in thought, word, and deed"},{term:"Brahmavidya (ब्रह्मविद्या)",meaning:"The supreme science of Ultimate Reality"},{term:"Acharya (आचार्य)",meaning:"A spiritual preceptor who teaches through their personal conduct"}],moral:"Truthfulness is the highest pedigree. Nobility of character outweighs social circumstance or birth.",quiz:{question:"Why did Sage Gautama accept Satyakama as his prime disciple?",options:["Because he was wealthy and powerful","Because he displayed absolute truthfulness and courage about his origins","Because he performed complex rituals"],correctIndex:1,explanation:"The Upanishads emphasize that true spiritual nobility is determined by Satya (Truth) and character, not by external privilege or birth status."}}];class te{constructor(){this.bead=0,this.rounds=0,this.totalChants=0,this.dailyTargetRounds=16,this.meruReversalMode=!0,this.soundEnabled=!0,this.vibrationEnabled=!0,this.currentMantra="ॐ नमो भगवते वासुदेवाय (Om Namo Bhagavate Vasudevaya)",this.audioCtx=null,this.loadState()}initAudio(){if(!this.audioCtx&&typeof window<"u"){const a=window.AudioContext||window.webkitAudioContext;a&&(this.audioCtx=new a)}this.audioCtx&&this.audioCtx.state==="suspended"&&this.audioCtx.resume()}playBeadSound(){if(this.soundEnabled)try{if(this.initAudio(),!this.audioCtx)return;const a=this.audioCtx.createOscillator(),e=this.audioCtx.createGain();a.type="triangle",a.frequency.setValueAtTime(440,this.audioCtx.currentTime),a.frequency.exponentialRampToValueAtTime(110,this.audioCtx.currentTime+.04),e.gain.setValueAtTime(.2,this.audioCtx.currentTime),e.gain.exponentialRampToValueAtTime(.001,this.audioCtx.currentTime+.04),a.connect(e),e.connect(this.audioCtx.destination),a.start(),a.stop(this.audioCtx.currentTime+.04)}catch{}}playTempleBell(){if(this.soundEnabled)try{if(this.initAudio(),!this.audioCtx)return;const a=this.audioCtx.currentTime,e=[880,1760,2640,3520],i=[.35,.15,.08,.03];e.forEach((t,r)=>{const n=this.audioCtx.createOscillator(),l=this.audioCtx.createGain();n.type="sine",n.frequency.setValueAtTime(t,a),l.gain.setValueAtTime(i[r],a),l.gain.exponentialRampToValueAtTime(1e-4,a+1.8),n.connect(l),l.connect(this.audioCtx.destination),n.start(a),n.stop(a+1.8)})}catch{}}triggerHaptic(a=!1){if(!(!this.vibrationEnabled||typeof navigator>"u"||!navigator.vibrate))try{a?navigator.vibrate([70,50,140]):navigator.vibrate(28)}catch{}}increment(){this.initAudio(),this.bead+=1,this.totalChants+=1;let a=!1;return this.bead>=108?(this.bead=0,this.rounds+=1,a=!0,this.playTempleBell(),this.triggerHaptic(!0)):(this.playBeadSound(),this.triggerHaptic(!1)),this.saveState(),{bead:this.bead,rounds:this.rounds,totalChants:this.totalChants,reachedMeru:a}}resetCurrentMala(){this.bead=0,this.saveState()}resetAll(){this.bead=0,this.rounds=0,this.totalChants=0,this.saveState()}saveState(){try{if(typeof localStorage>"u")return;const a={bead:this.bead,rounds:this.rounds,totalChants:this.totalChants,dailyTargetRounds:this.dailyTargetRounds,meruReversalMode:this.meruReversalMode,soundEnabled:this.soundEnabled,vibrationEnabled:this.vibrationEnabled,currentMantra:this.currentMantra,lastUpdated:new Date().toISOString()};localStorage.setItem("gurukripa_japa_state",JSON.stringify(a))}catch{}}loadState(){try{if(typeof localStorage>"u")return;const a=localStorage.getItem("gurukripa_japa_state");if(a){const e=JSON.parse(a);this.bead=e.bead||0,this.rounds=e.rounds||0,this.totalChants=e.totalChants||0,this.dailyTargetRounds=e.dailyTargetRounds||16,e.meruReversalMode!==void 0&&(this.meruReversalMode=e.meruReversalMode),e.soundEnabled!==void 0&&(this.soundEnabled=e.soundEnabled),e.vibrationEnabled!==void 0&&(this.vibrationEnabled=e.vibrationEnabled),e.currentMantra&&(this.currentMantra=e.currentMantra)}}catch{}}exportDataJSON(){const a={app:"GuruKripa",type:"japa_sadhana_backup",version:"1.0.0",exportDate:new Date().toISOString(),stats:{bead:this.bead,rounds:this.rounds,totalChants:this.totalChants,dailyTargetRounds:this.dailyTargetRounds,currentMantra:this.currentMantra}};return JSON.stringify(a,null,2)}importDataJSON(a){try{const e=JSON.parse(a);if(e.stats)return this.bead=e.stats.bead||0,this.rounds=e.stats.rounds||0,this.totalChants=e.stats.totalChants||0,e.stats.dailyTargetRounds&&(this.dailyTargetRounds=e.stats.dailyTargetRounds),e.stats.currentMantra&&(this.currentMantra=e.stats.currentMantra),this.saveState(),!0}catch{return!1}return!1}}class ie{constructor(){this.cities=Oa,this.selectedCity=this.loadSavedCity()||this.cities[0],this.selectedDate=new Date,this.selectedLang=localStorage.getItem("gk_lang")||"sa",this.currentView=this.getViewFromHash(),this.panchangTab="overview",this.slokaFontSize=1.35,this.showSabdartha=!0,this.cityModalOpen=!1,this.theme=localStorage.getItem("gk_theme")||"light",this.japaEngine=new te,this.selectedDeity="all",this.selectedCategory="all",this.playingSlokaId=null,this.chantSpeed=1,this.audioCtx=null,this.audioTimer=null,this.activeCardSloka=null,this.cardTheme="saffron",this.init()}loadSavedCity(){try{const a=localStorage.getItem("gk_selected_city");return a?JSON.parse(a):null}catch{return null}}saveCity(a){this.selectedCity=a;try{localStorage.setItem("gk_selected_city",JSON.stringify(a))}catch{}}getViewFromHash(){const a=window.location.hash.replace("#","").split("?")[0];return["panchang","stotras","japa","stories"].includes(a)?a:"panchang"}init(){document.documentElement.setAttribute("data-theme",this.theme),document.documentElement.setAttribute("data-lang",this.selectedLang),window.addEventListener("hashchange",()=>{this.currentView=this.getViewFromHash(),this.render()}),window.addEventListener("keydown",a=>{this.currentView==="japa"&&(a.code==="Space"||a.code==="Enter")&&(a.preventDefault(),this.handleJapaClick())}),"serviceWorker"in navigator&&window.addEventListener("load",()=>{navigator.serviceWorker.register("/sw.js").catch(()=>{})}),this.render()}toggleTheme(){this.theme=this.theme==="light"?"dark":"light",localStorage.setItem("gk_theme",this.theme),document.documentElement.setAttribute("data-theme",this.theme),this.render()}handleJapaClick(){const a=this.japaEngine.increment(),e=document.getElementById("gk-bead-number"),i=document.getElementById("gk-stat-rounds"),t=document.getElementById("gk-stat-total");e&&(e.innerText=a.bead),i&&(i.innerText=a.rounds),t&&(t.innerText=a.totalChants),a.reachedMeru&&this.japaEngine.meruReversalMode&&alert(`✨ Haribol! You have reached the sacred Sumeru (Meru) bead.
In traditional practice, do not cross the Guru bead; turn your mala around for the next round.`)}autoDetectLocation(){if(!navigator.geolocation){alert("Geolocation is not supported by your browser. Please select a city manually.");return}navigator.geolocation.getCurrentPosition(a=>{const e=a.coords.latitude,i=a.coords.longitude,t=-new Date().getTimezoneOffset()/60,r={id:"gps-current",name:"Current GPS Location",state:"Local",country:"Live Coordinates",lat:parseFloat(e.toFixed(4)),lon:parseFloat(i.toFixed(4)),tz:Intl.DateTimeFormat().resolvedOptions().timeZone||"UTC",tz_offset:t,elevation_m:50};this.saveCity(r),this.cityModalOpen=!1,this.render()},a=>{alert("GPS detection failed: "+a.message+". Please choose your city from the global directory.")},{timeout:1e4,enableHighAccuracy:!0})}playChantSound(a){if(this.playingSlokaId===a){this.stopChantSound();return}this.stopChantSound(),this.playingSlokaId=a,this.render();try{const e=window.AudioContext||window.webkitAudioContext;if(!e)return;this.audioCtx=new e;const i=this.audioCtx.createOscillator(),t=this.audioCtx.createGain(),r=136.1;i.type="sine",i.frequency.setValueAtTime(r*this.chantSpeed,this.audioCtx.currentTime),t.gain.setValueAtTime(.01,this.audioCtx.currentTime),t.gain.exponentialRampToValueAtTime(.25,this.audioCtx.currentTime+.8),t.gain.exponentialRampToValueAtTime(.001,this.audioCtx.currentTime+6/this.chantSpeed),i.connect(t),t.connect(this.audioCtx.destination),i.start(),i.stop(this.audioCtx.currentTime+6.2/this.chantSpeed),this.audioTimer=setTimeout(()=>{this.stopChantSound()},6200/this.chantSpeed)}catch(e){console.warn("Chant audio synthesis notice:",e)}}stopChantSound(){if(this.audioTimer&&clearTimeout(this.audioTimer),this.audioCtx){try{this.audioCtx.close()}catch{}this.audioCtx=null}this.playingSlokaId=null;const a=document.querySelector(".gk-audio-play-btn");a&&(a.innerHTML="▶")}openCardMaker(a){const e=pa.find(i=>i.id===a);e&&(this.activeCardSloka=e,this.render(),setTimeout(()=>this.drawShareCanvas(),50))}closeCardMaker(){this.activeCardSloka=null,this.render()}drawShareCanvas(){const a=document.getElementById("gk-share-canvas");if(!a||!this.activeCardSloka)return;const e=a.getContext("2d"),i=this.activeCardSloka;a.width=1080,a.height=1920;const t=e.createLinearGradient(0,0,1080,1920);this.cardTheme==="saffron"?(t.addColorStop(0,"#FF8F00"),t.addColorStop(.5,"#E65100"),t.addColorStop(1,"#6A0D18")):this.cardTheme==="maroon"?(t.addColorStop(0,"#4A0E17"),t.addColorStop(.5,"#800020"),t.addColorStop(1,"#250409")):this.cardTheme==="sandal"?(t.addColorStop(0,"#C5A059"),t.addColorStop(.6,"#8A6828"),t.addColorStop(1,"#3D2D10")):(t.addColorStop(0,"#0A192F"),t.addColorStop(.5,"#1E3A8A"),t.addColorStop(1,"#1A0B2E")),e.fillStyle=t,e.fillRect(0,0,1080,1920),e.strokeStyle="#D4AF37",e.lineWidth=14,e.strokeRect(40,40,1e3,1840),e.lineWidth=4,e.strokeRect(60,60,960,1800),e.fillStyle="rgba(255, 255, 255, 0.06)",e.font='bold 360px "Noto Serif Devanagari", serif',e.textAlign="center",e.fillText("ॐ",540,1050),e.fillStyle="#FFE082",e.font='700 42px "Cinzel", Georgia, serif',e.fillText("G U R U K R I P A",540,150),e.font="400 28px sans-serif",e.fillStyle="rgba(255, 255, 255, 0.8)",e.fillText("Sacred Daily Sanatana Dharma Wisdom",540,195),e.fillStyle="#FFFFFF",e.font='bold 52px "Cinzel", Georgia, serif',e.fillText(i.deity,540,310),e.fillStyle="#FFE082",e.font='600 36px "Cinzel", Georgia, serif',e.fillText(i.title,540,370);const r=m(i.devanagari,this.selectedLang).split(`
`);e.fillStyle="#FFFFFF",e.font='600 48px "Noto Serif Devanagari", "Noto Sans Tamil", "Noto Sans Telugu", serif';let n=560;for(const c of r)e.fillText(c,540,n),n+=85;e.fillStyle="#FFE0B2",e.font="italic 34px Georgia, serif",n+=40;const l=i.iast.split(`
`);for(const c of l)e.fillText(c,540,n),n+=56;n+=40,e.strokeStyle="rgba(212, 175, 55, 0.5)",e.beginPath(),e.moveTo(200,n),e.lineTo(880,n),e.stroke(),n+=80,e.fillStyle="rgba(255, 255, 255, 0.95)",e.font='400 32px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';const d=i.translation.split(" ");let u="";for(const c of d){const b=u?u+" "+c:c;e.measureText(b).width>860?(e.fillText(u,540,n),n+=52,u=c):u=b}u&&e.fillText(u,540,n),e.fillStyle="#FFE082",e.font='600 28px "Cinzel", Georgia, serif',e.fillText("gurukripa.pages.dev • 100% Client-Side Vedic Wisdom",540,1800)}downloadCardImage(){const a=document.getElementById("gk-share-canvas");if(!a||!this.activeCardSloka)return;const e=a.toDataURL("image/png"),i=document.createElement("a");i.href=e,i.download=`GuruKripa_${this.activeCardSloka.id}_${this.cardTheme}.png`,i.click()}shareCardToWhatsApp(){if(!document.getElementById("gk-share-canvas")||!this.activeCardSloka)return;const e=this.activeCardSloka,i=encodeURIComponent(`🕉️ *${e.title}* (${e.deity})

"${m(e.devanagari,this.selectedLang)}"

*Meaning:* ${e.translation}

Chant daily on GuruKripa: https://gurukripa.pages.dev/#stotras`);window.open(`https://api.whatsapp.com/send?text=${i}`,"_blank")}render(){const a=document.getElementById("app");a&&(a.innerHTML=`
      ${this.renderHeader()}
      <main class="gk-main">
        ${this.renderNavSubbar()}
        ${this.renderView()}
      </main>
      ${this.renderFooter()}
      ${this.cityModalOpen?this.renderCityModal():""}
      ${this.activeCardSloka?this.renderCardMakerModal():""}
      ${this.renderConsentBanner()}
    `,this.bindEvents())}renderHeader(){return`
      <header class="gk-header">
        <div class="gk-header-inner">
          <a href="#panchang" class="gk-brand">
            <span class="gk-brand-logo">🕉️</span>
            <div>
              <span class="gk-brand-title">GuruKripa</span>
              <span class="gk-brand-tagline">Global Vedic Panchang & Hindu Spiritual Portal</span>
            </div>
          </a>

          <div class="gk-header-controls">
            <!-- Language Switcher (11 Scripts) -->
            <select id="gk-lang-select" class="gk-select" title="Switch Script">
              ${Za.map(a=>`
                <option value="${a.code}" ${a.code===this.selectedLang?"selected":""}>
                  ${a.native} (${a.name})
                </option>
              `).join("")}
            </select>

            <!-- City / Geo Location Button -->
            <button id="gk-city-btn" class="gk-btn" title="Change Location">
              📍 ${this.selectedCity.name}
            </button>

            <!-- Auto GPS Button -->
            <button id="gk-gps-btn" class="gk-btn" title="Auto-Detect My GPS Location">
              🎯 GPS
            </button>

            <!-- Theme Toggle -->
            <button id="gk-theme-btn" class="gk-btn" title="Toggle Light/Dark Theme">
              ${this.theme==="light"?"🌙 Dark":"☀️ Light"}
            </button>
          </div>
        </div>
      </header>
    `}renderNavSubbar(){return`
      <nav class="gk-nav-subbar">
        <div class="gk-nav-subbar-inner">
          <ul class="gk-nav-links">
            <li><a href="#panchang" class="${this.currentView==="panchang"?"active":""}">Panchangam</a></li>
            <li><a href="#stotras" class="${this.currentView==="stotras"?"active":""}">Stotras & 12 Deities</a></li>
            <li><a href="#japa" class="${this.currentView==="japa"?"active":""}">108 Japa Mala</a></li>
            <li><a href="#stories" class="${this.currentView==="stories"?"active":""}">Dharmic Stories</a></li>
          </ul>

          <div class="gk-location-pill">
            <span>Lat: ${this.selectedCity.lat.toFixed(2)}°, Lon: ${this.selectedCity.lon.toFixed(2)}° (${this.selectedCity.tz})</span>
          </div>
        </div>
      </nav>
    `}renderView(){switch(this.currentView){case"panchang":return this.renderPanchang();case"stotras":return this.renderStotras();case"japa":return this.renderJapa();case"stories":return this.renderStories();default:return this.renderPanchang()}}renderPanchang(){const a=Ya(this.selectedDate,this.selectedCity);return`
      <section>
        <!-- Traditional Vedic Almanac Header -->
        <div class="gk-almanac-header">
          <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
            <div>
              <div class="gk-almanac-title">
                ${m("दैनिक पञ्चाङ्गम्",this.selectedLang)} — ${a.date}
              </div>
              <div style="font-size:0.85rem; color:#FFE0B2;">
                📍 ${this.selectedCity.name}, ${this.selectedCity.country} • Lahiri Ayanamsa: ${a.ayanamsa&&a.ayanamsa.formatted?a.ayanamsa.formatted:a.ayanamsa&&a.ayanamsa.degrees!==void 0?`${a.ayanamsa.degrees}° ${a.ayanamsa.minutes}'`:a.ayanamsa}
              </div>
            </div>
            <div>
              <input type="date" id="gk-date-picker" class="gk-select" value="${a.date}" style="background:#FFF; color:#222; font-weight:700;">
            </div>
          </div>

          <div class="gk-samvat-grid">
            <div class="gk-samvat-item">
              Samvatsara
              <strong>Krodhi (क्रोधी)</strong>
            </div>
            <div class="gk-samvat-item">
              Ayana
              <strong>Dakshinayana (दक्षिणायन)</strong>
            </div>
            <div class="gk-samvat-item">
              Ritu
              <strong>Hemanta (हेमन्त ऋतु)</strong>
            </div>
            <div class="gk-samvat-item">
              Vedic Vaara
              <strong>${m(a.vaar.sanskrit,this.selectedLang)}</strong>
            </div>
          </div>
        </div>

        <div class="gk-tabs">
          <button class="gk-tab-btn ${this.panchangTab==="overview"?"active":""}" data-tab="overview">5 Daily Limbs</button>
          <button class="gk-tab-btn ${this.panchangTab==="gowri"?"active":""}" data-tab="gowri">Gowri Panchangam</button>
          <button class="gk-tab-btn ${this.panchangTab==="choghadiya"?"active":""}" data-tab="choghadiya">Choghadiya Muhurtas</button>
          <button class="gk-tab-btn ${this.panchangTab==="planets"?"active":""}" data-tab="planets">Planetary Longitudes</button>
        </div>

        ${this.panchangTab==="overview"?this.renderPanchangOverview(a):""}
        ${this.panchangTab==="gowri"?this.renderGowriTable(a.gowriPanchangam):""}
        ${this.panchangTab==="choghadiya"?this.renderChoghadiyaTable(a.choghadiya):""}
        ${this.panchangTab==="planets"?this.renderPlanetsTable(a.planets,a.ayanamsa):""}

        ${this.renderAdSlot("ad-panchang-inline","rectangle")}
      </section>
    `}renderPanchangOverview(a){return`
      <div class="gk-panchang-hero">
        <div class="gk-card">
          <div class="gk-card-title"><span>Sunrise / Sunset</span><span>☀️</span></div>
          <div class="gk-card-value">${a.sunrise} — ${a.sunset}</div>
          <div class="gk-card-meta">Solar Noon: ${a.solarNoon} (Day Duration: ${a.dayDuration})</div>
        </div>
        <div class="gk-card">
          <div class="gk-card-title"><span>Tithi (Lunar Day)</span><span>🌙</span></div>
          <div class="gk-card-value">${m(a.tithi.name,this.selectedLang)}</div>
          <div class="gk-card-meta">Paksha: ${a.tithi.paksha} • Progress: ${a.tithi.progress}% • Deity: ${a.tithi.deity}</div>
        </div>
        <div class="gk-card">
          <div class="gk-card-title"><span>Nakshatra (Lunar Mansion)</span><span>✨</span></div>
          <div class="gk-card-value">${m(a.nakshatra.name,this.selectedLang)} (Pada ${a.nakshatra.pada})</div>
          <div class="gk-card-meta">Lord: ${a.nakshatra.lord} • Deity: ${a.nakshatra.deity}</div>
        </div>
        <div class="gk-card">
          <div class="gk-card-title"><span>Yoga & Karana</span><span>🌀</span></div>
          <div class="gk-card-value">${m(a.yoga,this.selectedLang)} / ${m(a.karana,this.selectedLang)}</div>
          <div class="gk-card-meta">Vaar: ${m(a.vaar.sanskrit,this.selectedLang)} (${a.vaar.english} - Lord: ${a.vaar.lord})</div>
        </div>
        <div class="gk-card">
          <div class="gk-card-title"><span>Sun & Moon Rashi</span><span>♈</span></div>
          <div class="gk-card-value">${m(a.moonRashi,this.selectedLang)}</div>
          <div class="gk-card-meta">Sun: ${m(a.sunRashi,this.selectedLang)} (Chitrapaksha Lahiri Ayanamsa)</div>
        </div>
        <div class="gk-card">
          <div class="gk-card-title"><span>Auspicious Windows</span><span>🌟</span></div>
          <div class="gk-card-value" style="font-size:1rem; color:var(--color-good);">
            Abhijit: ${a.muhurtas.abhijitMuhurta}
          </div>
          <div class="gk-card-meta">Brahma Muhurta: ${a.muhurtas.brahmaMuhurta}</div>
        </div>
      </div>

      <!-- Inauspicious & Auspicious Timings Card -->
      <div class="gk-card" style="margin-top:20px;">
        <h3 style="color:var(--color-primary); margin-bottom:12px; font-size:1.15rem;">
          Daily Muhurta & Kaalam Schedule (${this.selectedCity.name})
        </h3>
        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(220px, 1fr)); gap:16px;">
          <div style="background:rgba(198,40,40,0.06); padding:12px; border-radius:6px; border-left:4px solid var(--color-inauspicious);">
            <div style="font-weight:700; color:var(--color-inauspicious); font-size:0.9rem;">
              ⚠️ Rahu Kalam (Inauspicious)
            </div>
            <div style="font-size:1.1rem; font-weight:700; margin:4px 0;">${a.muhurtas.rahuKalam}</div>
            <div style="font-size:0.75rem; color:var(--color-text-muted);">Avoid initiating travel or signing contracts</div>
          </div>

          <div style="background:rgba(230,81,0,0.06); padding:12px; border-radius:6px; border-left:4px solid var(--color-secondary);">
            <div style="font-weight:700; color:var(--color-secondary); font-size:0.9rem;">
              ⏳ Yamaganda Kalam
            </div>
            <div style="font-size:1.1rem; font-weight:700; margin:4px 0;">${a.muhurtas.yamaganda}</div>
            <div style="font-size:0.75rem; color:var(--color-text-muted);">Ruled by Yama; unsuitable for new investments</div>
          </div>

          <div style="background:rgba(212,175,55,0.08); padding:12px; border-radius:6px; border-left:4px solid var(--color-accent);">
            <div style="font-weight:700; color:var(--color-gold-dark); font-size:0.9rem;">
              ⏱️ Gulika Kalam
            </div>
            <div style="font-size:1.1rem; font-weight:700; margin:4px 0;">${a.muhurtas.gulikaKalam}</div>
            <div style="font-size:0.75rem; color:var(--color-text-muted);">Ruled by Saturn; deeds performed here repeat</div>
          </div>

          <div style="background:rgba(46,125,50,0.06); padding:12px; border-radius:6px; border-left:4px solid var(--color-good);">
            <div style="font-weight:700; color:var(--color-good); font-size:0.9rem;">
              ✨ Abhijit Muhurta (Most Auspicious)
            </div>
            <div style="font-size:1.1rem; font-weight:700; margin:4px 0;">${a.muhurtas.abhijitMuhurta}</div>
            <div style="font-size:0.75rem; color:var(--color-text-muted);">Midday victory window; destroys all doshas</div>
          </div>
        </div>
      </div>
    `}renderGowriTable(a){if(!a)return'<div class="gk-card"><p>Gowri Panchangam not available for current location.</p></div>';const e=a.day||(Array.isArray(a)?a:[]),i=a.night||[];return`
      <div class="gk-card">
        <h3 style="color:var(--color-primary); margin-bottom:12px;">Gowri Panchangam (Auspicious Horas)</h3>
        <p style="font-size:0.85rem; color:var(--color-text-muted); margin-bottom:14px;">
          Traditional South Indian division of Day and Night into 8 equal periods of ~1.5 hours each.
        </p>
        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(300px, 1fr)); gap:20px;">
          <div>
            <h4 style="color:var(--color-secondary); margin-bottom:8px;">☀️ Daytime Gowri (Suryodayam to Astamanam)</h4>
            <table class="gk-table">
              <thead><tr><th>Interval</th><th>Gowri Lord</th><th>Nature</th></tr></thead>
              <tbody>
                ${e.map(t=>`
                  <tr>
                    <td>${t.slot||`${t.start} – ${t.end}`}</td>
                    <td><strong>${m(t.name,this.selectedLang)}</strong></td>
                    <td><span class="${t.isGood||t.nature==="Good"?"gk-badge-good":"gk-badge-inauspicious"}">${t.nature||(t.isGood?"Good":"Inauspicious")}</span></td>
                  </tr>
                `).join("")}
              </tbody>
            </table>
          </div>
          <div>
            <h4 style="color:var(--color-primary); margin-bottom:8px;">🌙 Nighttime Gowri (Astamanam to Suryodayam)</h4>
            <table class="gk-table">
              <thead><tr><th>Interval</th><th>Gowri Lord</th><th>Nature</th></tr></thead>
              <tbody>
                ${i.length>0?i.map(t=>`
                  <tr>
                    <td>${t.slot||`${t.start} – ${t.end}`}</td>
                    <td><strong>${m(t.name,this.selectedLang)}</strong></td>
                    <td><span class="${t.isGood||t.nature==="Good"?"gk-badge-good":"gk-badge-inauspicious"}">${t.nature||(t.isGood?"Good":"Inauspicious")}</span></td>
                  </tr>
                `).join(""):`
                  <tr><td colspan="3" style="text-align:center; color:var(--color-text-muted); padding:12px;">Night slots active after sunset</td></tr>
                `}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `}renderChoghadiyaTable(a){if(!a)return'<div class="gk-card"><p>Choghadiya not available for current location.</p></div>';const e=a.day||(Array.isArray(a)?a:[]),i=a.night||[];return`
      <div class="gk-card">
        <h3 style="color:var(--color-primary); margin-bottom:12px;">Choghadiya Muhurta</h3>
        <p style="font-size:0.85rem; color:var(--color-text-muted); margin-bottom:14px;">
          Traditional Vedic division of 4 Ghadis (~1.5 hours) for determining auspicious windows for travel and new beginnings.
        </p>
        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(300px, 1fr)); gap:20px;">
          <div>
            <h4 style="color:var(--color-secondary); margin-bottom:8px;">☀️ Day Choghadiya</h4>
            <table class="gk-table">
              <thead><tr><th>Time</th><th>Choghadiya</th><th>Effect</th></tr></thead>
              <tbody>
                ${e.map(t=>`
                  <tr>
                    <td>${t.slot||`${t.start} – ${t.end}`}</td>
                    <td><strong>${m(t.name,this.selectedLang)}</strong></td>
                    <td><span class="${t.isGood||t.nature==="Auspicious"?"gk-badge-good":"gk-badge-inauspicious"}">${t.nature||(t.isGood?"Auspicious":"Inauspicious")}</span></td>
                  </tr>
                `).join("")}
              </tbody>
            </table>
          </div>
          <div>
            <h4 style="color:var(--color-primary); margin-bottom:8px;">🌙 Night Choghadiya</h4>
            <table class="gk-table">
              <thead><tr><th>Time</th><th>Choghadiya</th><th>Effect</th></tr></thead>
              <tbody>
                ${i.length>0?i.map(t=>`
                  <tr>
                    <td>${t.slot||`${t.start} – ${t.end}`}</td>
                    <td><strong>${m(t.name,this.selectedLang)}</strong></td>
                    <td><span class="${t.isGood||t.nature==="Auspicious"?"gk-badge-good":"gk-badge-inauspicious"}">${t.nature||(t.isGood?"Auspicious":"Inauspicious")}</span></td>
                  </tr>
                `).join(""):`
                  <tr><td colspan="3" style="text-align:center; color:var(--color-text-muted); padding:12px;">Night slots active after sunset</td></tr>
                `}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `}renderPlanetsTable(a,e){return!a||!Array.isArray(a)?'<div class="gk-card"><p>Planetary positions not available.</p></div>':`
      <div class="gk-card">
        <h3 style="color:var(--color-primary); margin-bottom:8px;">Real-Time Sidereal Planetary Longitudes (Nirayana)</h3>
        <p style="font-size:0.85rem; color:var(--color-text-muted); margin-bottom:14px;">
          Calculated using Jean Meeus high-precision solar system algorithms with Lahiri Chitrapaksha Ayanamsa (${e&&e.formatted?e.formatted:e&&e.degrees!==void 0?`${e.degrees}° ${e.minutes}' ${e.seconds||0}"`:typeof e=="number"||typeof e=="string"?`${e}°`:`24° 13' 52"`}).
        </p>
        <div style="overflow-x:auto;">
          <table class="gk-table">
            <thead>
              <tr>
                <th>Graha (Planet)</th>
                <th>Longitude in Rashi</th>
                <th>Rashi (Zodiac)</th>
                <th>Nakshatra</th>
                <th>Pada</th>
                <th>Speed / Status</th>
              </tr>
            </thead>
            <tbody>
              ${a.map(t=>{const r=t.deg!==void 0?t.deg:Math.floor((t.siderealLon||0)%30),n=t.min!==void 0?t.min:Math.floor((t.siderealLon||0)%1*60),l=t.sec!==void 0?t.sec:Math.round((t.siderealLon||0)%1*60%1*60),d=t.sanskrit?` (${m(t.sanskrit,this.selectedLang)})`:"",u=t.nakshatra?m(t.nakshatra,this.selectedLang):"—",c=t.pada!==void 0?t.pada:1,b=t.status||(t.isRetrograde?"Retrograde (Vakra)":"Direct (Marga)"),T=t.isRetrograde||b.includes("Retrograde");return`
                  <tr>
                    <td><strong>${t.name}${d}</strong></td>
                    <td>${r}° ${n}' ${l}"</td>
                    <td>${m(t.rashi||"",this.selectedLang)} (${t.rashiEnglish||""})</td>
                    <td>${u}</td>
                    <td>Pada ${c}</td>
                    <td><span class="${T?"gk-badge-inauspicious":"gk-badge-good"}">${b}</span></td>
                  </tr>
                `}).join("")}
            </tbody>
          </table>
        </div>
      </div>
    `}renderStotras(){const a=pa.filter(i=>{const t=this.selectedDeity==="all"||i.deityId===this.selectedDeity,r=this.selectedCategory==="all"||i.category===this.selectedCategory;return t&&r}),e=["all","Stotra","Mantra","Chalisa","Ashtakam","Suprabhatam","Prayer"];return`
      <section>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:12px;">
          <div>
            <h2 style="color:var(--color-primary); font-size:1.6rem;">
              ${m("स्तोत्राणि मन्त्राश्च",this.selectedLang)} (12 Deity Shrines & Stotras)
            </h2>
            <p style="font-size:0.85rem; color:var(--color-text-muted);">
              Select any Sacred Shrine or filter by Category. Instant 1-click script switching across 11 Indian scripts.
            </p>
          </div>
          <div style="display:flex; align-items:center; gap:8px;">
            <button id="gk-font-dec" class="gk-btn" title="Decrease Font">A-</button>
            <button id="gk-font-inc" class="gk-btn" title="Increase Font">A+</button>
            <button id="gk-toggle-sabdartha" class="gk-btn ${this.showSabdartha?"gk-btn-primary":""}">
              ${this.showSabdartha?"✓ Sabdartha":"+ Sabdartha"}
            </button>
          </div>
        </div>

        <!-- 12 Sacred Deity Hubs Shrines Bar -->
        <div class="gk-deity-hub-container">
          <div class="gk-deity-scroll-track">
            ${ee.map(i=>`
              <div class="gk-deity-card-chip ${this.selectedDeity===i.id?"active":""}" data-deity-id="${i.id}">
                <span class="gk-deity-icon">${i.icon}</span>
                <div class="gk-deity-meta">
                  <span class="gk-deity-name">${i.name}</span>
                  <span class="gk-deity-sanskrit">${m(i.sanskrit,this.selectedLang)}</span>
                </div>
              </div>
            `).join("")}
          </div>
        </div>

        <!-- Category Filter Pills -->
        <div class="gk-category-pills">
          ${e.map(i=>`
            <button class="gk-cat-pill ${this.selectedCategory===i?"active":""}" data-category="${i}">
              ${i==="all"?"All Types":i}
            </button>
          `).join("")}
        </div>

        <!-- Sloka Cards List -->
        ${a.length===0?`
          <div class="gk-card" style="text-align:center; padding:32px;">
            <p>No texts found for this shrine & category filter.</p>
            <button class="gk-btn gk-btn-primary" id="gk-reset-filters" style="margin-top:12px;">Reset Filters</button>
          </div>
        `:a.map((i,t)=>`
          <article class="gk-sloka-card" id="${i.id}">
            <div class="gk-sloka-header">
              <div>
                <div style="display:flex; align-items:center; gap:8px; margin-bottom:4px;">
                  <span class="gk-badge-good">${i.category}</span>
                  <span style="font-size:0.75rem; color:var(--color-text-muted);">Shrine: <strong>${i.deity}</strong></span>
                </div>
                <h3 class="gk-sloka-title">${m(i.title,this.selectedLang)}</h3>
                <span class="gk-sloka-source">${i.source} • Meter: ${i.meter}</span>
              </div>
              <div style="display:flex; gap:8px; align-items:center;">
                <button class="gk-share-card-btn" data-share-id="${i.id}" title="Generate Devotional WhatsApp Status Card">
                  🎨 Share Card
                </button>
              </div>
            </div>

            <!-- Chanting Audio Bar with Speed Selector -->
            <div class="gk-chant-player">
              <div class="gk-audio-controls-left">
                <button class="gk-audio-play-btn" data-play-id="${i.id}" title="Play Meditative Vedic Tanpura Chime">
                  ${this.playingSlokaId===i.id?"⏸":"▶"}
                </button>
                <span class="gk-audio-label">
                  ${this.playingSlokaId===i.id?"Chanting in progress (Tanpura resonance)...":"Vedic Chanting Chime"}
                </span>
              </div>
              <div class="gk-speed-selector">
                <span style="font-size:0.75rem; color:var(--color-text-muted); margin-right:4px;">Speed:</span>
                <button class="gk-speed-btn ${this.chantSpeed===.75?"active":""}" data-speed="0.75">0.75x</button>
                <button class="gk-speed-btn ${this.chantSpeed===1?"active":""}" data-speed="1.0">1.0x</button>
                <button class="gk-speed-btn ${this.chantSpeed===1.25?"active":""}" data-speed="1.25">1.25x</button>
              </div>
            </div>

            <!-- Sacred Verse (100% Clean Font Rendering - Zero Tofu Boxes) -->
            <div class="gk-sloka-text" style="font-size:${this.slokaFontSize}rem;">
              ${m(i.devanagari,this.selectedLang)}
            </div>

            <div class="gk-sloka-iast">${i.iast}</div>

            ${this.showSabdartha&&i.sabdartha?`
              <div class="gk-sabdartha-grid">
                ${i.sabdartha.map(r=>`
                  <div class="gk-sabdartha-item">
                    <span class="gk-sabdartha-word">${m(r.word,this.selectedLang)}:</span> ${r.meaning}
                  </div>
                `).join("")}
              </div>
            `:""}

            <div class="gk-sloka-translation">
              <strong>Translation:</strong> ${i.translation}
            </div>

            <div class="gk-sloka-purport">
              <strong>Purport & Spiritual Insight:</strong> ${i.purport}
            </div>

            ${t===1?this.renderAdSlot("ad-stotra-incontent","rectangle"):""}
          </article>
        `).join("")}
      </section>
    `}renderJapa(){return`
      <section>
        <div class="gk-japa-container">
          <h2 style="color:var(--color-primary); margin-bottom:6px;">
            ${m("जपमाला",this.selectedLang)} (108-Bead Japa Mala)
          </h2>
          <p style="font-size:0.85rem; color:var(--color-text-muted); margin-bottom:18px;">
            Tap the sacred bead circle or press <kbd style="background:#eee; padding:2px 6px; border-radius:4px;">Spacebar</kbd> / <kbd style="background:#eee; padding:2px 6px; border-radius:4px;">Enter</kbd> to count.
          </p>

          <div style="margin-bottom:14px;">
            <select id="gk-japa-mantra-select" class="gk-select" style="max-width:90%;">
              <option value="ॐ नमो भगवते वासुदेवाय">ॐ नमो भगवते वासुदेवाय (Om Namo Bhagavate Vasudevaya)</option>
              <option value="हरे कृष्ण हरे कृष्ण कृष्ण कृष्ण हरे हरे">हरे कृष्ण हरे कृष्ण कृष्ण कृष्ण हरे हरे (Maha-Mantra)</option>
              <option value="ॐ नमः शिवाय">ॐ नमः शिवाय (Om Namah Shivaya)</option>
              <option value="श्री राम जय राम जय जय राम">श्री राम जय राम जय जय राम (Sri Ram Jaya Ram)</option>
              <option value="ॐ गं गणपतये नमः">ॐ गं गणपतये नमः (Ganesha Mantra)</option>
            </select>
          </div>

          <div id="gk-japa-trigger" class="gk-japa-circle" title="Tap to Count">
            <div id="gk-bead-number" class="gk-bead-number">${this.japaEngine.bead}</div>
            <div class="gk-bead-max">of 108 Beads</div>
          </div>

          <div class="gk-japa-stats">
            <div>
              <div id="gk-stat-rounds" class="gk-japa-stat-num">${this.japaEngine.rounds}</div>
              <div class="gk-japa-stat-label">Mala Rounds</div>
            </div>
            <div>
              <div id="gk-stat-total" class="gk-japa-stat-num">${this.japaEngine.totalChants}</div>
              <div class="gk-japa-stat-label">Total Chants</div>
            </div>
            <div>
              <div class="gk-japa-stat-num">${this.japaEngine.dailyTargetRounds}</div>
              <div class="gk-japa-stat-label">Target Malas</div>
            </div>
          </div>

          <div style="display:flex; justify-content:center; gap:10px; margin-top:20px; flex-wrap:wrap;">
            <button id="gk-japa-sound-toggle" class="gk-btn">
              ${this.japaEngine.soundEnabled?"🔔 Sound: ON":"🔕 Sound: OFF"}
            </button>
            <button id="gk-japa-vib-toggle" class="gk-btn">
              ${this.japaEngine.vibrationEnabled?"📳 Haptics: ON":"📴 Haptics: OFF"}
            </button>
            <button id="gk-japa-meru-toggle" class="gk-btn">
              ${this.japaEngine.meruReversalMode?"🔄 Meru Reversal: ON":"🔁 Continuous Loop"}
            </button>
            <button id="gk-japa-reset" class="gk-btn" style="color:var(--color-inauspicious);">Reset Round</button>
          </div>

          <div style="margin-top:24px; border-top:1px solid var(--color-border); padding-top:16px;">
            <button id="gk-japa-export" class="gk-btn" style="font-size:0.75rem;">💾 Export Sadhana JSON</button>
          </div>
        </div>
      </section>
    `}renderStories(){return`
      <section>
        <div style="margin-bottom:24px;">
          <h2 style="color:var(--color-primary); font-size:1.6rem;">
            ${m("नीतिकथाः",this.selectedLang)} (Dharmic Wisdom & Moral Stories)
          </h2>
          <p style="font-size:0.85rem; color:var(--color-text-muted);">
            Timeless fables from the 5 Books of Panchatantra, Hitopadesha, Tenali Raman, and Upanishads with illuminated moral cards.
          </p>
        </div>

        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(320px, 1fr)); gap:20px;">
          ${ya.map(a=>`
            <article class="gk-story-card">
              <div>
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                  <span class="gk-badge-good">${a.collection}</span>
                  <span style="font-size:0.75rem; color:var(--color-text-muted);">Reading: 3 mins</span>
                </div>
                <h3 style="color:var(--color-primary); font-size:1.25rem; margin-bottom:8px;">${a.title}</h3>
                
                <div style="background:rgba(230,81,0,0.04); padding:10px 14px; border-radius:6px; margin-bottom:14px; font-style:italic; font-size:0.85rem; border-left:3px solid var(--color-secondary);">
                  "${a.epigraphTranslation}"
                </div>

                <p style="font-size:0.9rem; line-height:1.65; margin-bottom:14px; color:var(--color-text);">
                  ${a.summary}
                </p>

                <!-- Prominent Golden Moral Takeaway Card -->
                <div class="gk-moral-takeaway-card">
                  <div class="gk-moral-takeaway-label">✨ Sacred Moral Takeaway</div>
                  <div class="gk-moral-takeaway-text">${a.moral}</div>
                </div>

                <div style="margin-bottom:14px;">
                  <div style="font-size:0.75rem; text-transform:uppercase; color:var(--color-text-muted); margin-bottom:4px;">Sanskrit Vocabulary:</div>
                  <div style="display:flex; flex-wrap:wrap; gap:6px;">
                    ${a.vocabulary.map(e=>`
                      <span style="font-size:0.75rem; background:rgba(0,0,0,0.05); padding:2px 8px; border-radius:4px;" title="${e.meaning}">
                        ${e.term}
                      </span>
                    `).join("")}
                  </div>
                </div>
              </div>

              <!-- Interactive Ethical Dilemma Quiz -->
              <div style="border-top:1px solid var(--color-border); padding-top:12px; margin-top:12px;">
                <div style="font-size:0.85rem; font-weight:700; margin-bottom:6px;">Dharmic Reflection:</div>
                <p style="font-size:0.85rem; margin-bottom:10px;">${a.quiz.question}</p>
                <div class="gk-quiz-options" data-story="${a.id}">
                  ${a.quiz.options.map((e,i)=>`
                    <button class="gk-btn gk-quiz-btn" data-story="${a.id}" data-idx="${i}" style="width:100%; text-align:left; margin-bottom:6px; font-size:0.8rem;">
                      ${e}
                    </button>
                  `).join("")}
                </div>
                <div id="gk-quiz-result-${a.id}" style="display:none; padding:8px 12px; border-radius:6px; font-size:0.8rem; margin-top:6px;"></div>
              </div>
            </article>
          `).join("")}
        </div>
      </section>
    `}renderCityModal(){return`
      <div class="gk-modal-backdrop" id="gk-city-modal-backdrop">
        <div class="gk-modal">
          <div class="gk-modal-header">
            <h3 style="color:var(--color-primary);">Select Global City</h3>
            <button id="gk-modal-close" class="gk-btn" style="border:none; font-size:1.2rem;">✕</button>
          </div>
          <input type="text" id="gk-city-search" class="gk-search-input" placeholder="Search 100+ global cities (e.g. Chennai, London, New York)..." autofocus>
          <ul class="gk-city-list" id="gk-city-list">
            ${this.cities.map(a=>`
              <li class="gk-city-item ${a.id===this.selectedCity.id?"active":""}" data-city-id="${a.id}">
                <div>
                  <strong>${a.name}</strong>
                  <span style="font-size:0.75rem; color:var(--color-text-muted); display:block;">${a.state?a.state+", ":""}${a.country}</span>
                </div>
                <span style="font-size:0.75rem; color:var(--color-accent); font-weight:700;">${a.tz_offset>=0?"+"+a.tz_offset:a.tz_offset}h</span>
              </li>
            `).join("")}
          </ul>
        </div>
      </div>
    `}renderCardMakerModal(){return`
      <div class="gk-modal-backdrop" id="gk-card-modal-backdrop">
        <div class="gk-card-maker-modal">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
            <h3 style="color:var(--color-primary); font-size:1.3rem;">🎨 Devotional Share-Card Generator</h3>
            <button id="gk-card-maker-close" class="gk-btn" style="border:none; font-size:1.2rem;">✕</button>
          </div>

          <p style="font-size:0.85rem; color:var(--color-text-muted);">
            Pick a sacred theme below and download or share your customized status card directly to WhatsApp or Instagram!
          </p>

          <!-- Theme Swatches -->
          <div class="gk-theme-swatches">
            <div class="gk-theme-swatch gk-theme-saffron ${this.cardTheme==="saffron"?"active":""}" data-theme="saffron">
              Saffron Dawn
            </div>
            <div class="gk-theme-swatch gk-theme-maroon ${this.cardTheme==="maroon"?"active":""}" data-theme="maroon">
              Sacred Maroon
            </div>
            <div class="gk-theme-swatch gk-theme-sandal ${this.cardTheme==="sandal"?"active":""}" data-theme="sandal">
              Sandalwood
            </div>
            <div class="gk-theme-swatch gk-theme-indigo ${this.cardTheme==="indigo"?"active":""}" data-theme="indigo">
              Temple Indigo
            </div>
          </div>

          <!-- Live Canvas Preview -->
          <div class="gk-canvas-preview-wrapper">
            <canvas id="gk-share-canvas"></canvas>
          </div>

          <!-- Action Buttons -->
          <div style="display:flex; justify-content:space-between; gap:12px; flex-wrap:wrap;">
            <button id="gk-canvas-download" class="gk-btn gk-btn-primary" style="flex:1;">
              📥 Download Image (PNG)
            </button>
            <button id="gk-canvas-whatsapp" class="gk-btn" style="flex:1; background:#25D366; color:#FFF; border:none; font-weight:700;">
              📱 Share on WhatsApp
            </button>
          </div>
        </div>
      </div>
    `}renderAdSlot(a,e="banner"){return`
      <div class="gk-ad-container gk-ad-${e}" id="${a}" data-ad-slot="${a}">
        <span class="gk-ad-label">ADVERTISEMENT</span>
        <div class="gk-ad-placeholder">
          <!-- Google AdSense Ready Slot (Zero CLS Pre-allocated) -->
        </div>
      </div>
    `}renderConsentBanner(){return localStorage.getItem("gk_consent")?"":`
      <div class="gk-consent-banner" id="gk-consent-banner">
        <div class="gk-consent-text">
          GuruKripa operates with a <strong>Zero-Server, Zero-PII</strong> architecture. We store your preferred city, script, and sadhana counts strictly inside your browser's private local storage.
        </div>
        <div class="gk-consent-actions">
          <button id="gk-consent-accept" class="gk-btn gk-btn-primary" style="font-size:0.8rem;">Accept & Continue</button>
        </div>
      </div>
    `}renderFooter(){return`
      <footer class="gk-footer">
        <div class="gk-footer-inner">
          <div>
            <span style="font-weight:700; color:var(--color-primary); font-size:1.1rem; display:block; margin-bottom:4px;">GuruKripa</span>
            <p style="font-size:0.8rem; color:var(--color-text-muted); max-width:400px;">
              A zero-cost, enterprise-grade Vedic spiritual portal dedicated to preserving and celebrating Sanatana Dharma with scientific astronomical precision and authentic public-domain texts.
            </p>
          </div>
          <ul class="gk-footer-links">
            <li><a href="/privacy.html">Privacy Policy</a></li>
            <li><a href="/terms.html">Terms of Service</a></li>
            <li><a href="/disclaimer.html">Astronomical Disclaimer</a></li>
          </ul>
        </div>
      </footer>
    `}bindEvents(){const a=document.getElementById("gk-lang-select");a&&a.addEventListener("change",s=>{this.selectedLang=s.target.value,localStorage.setItem("gk_lang",this.selectedLang),document.documentElement.setAttribute("data-lang",this.selectedLang),this.render()});const e=document.getElementById("gk-city-btn");e&&e.addEventListener("click",()=>{this.cityModalOpen=!0,this.render()});const i=document.getElementById("gk-gps-btn");i&&i.addEventListener("click",()=>this.autoDetectLocation());const t=document.getElementById("gk-theme-btn");t&&t.addEventListener("click",()=>this.toggleTheme()),document.querySelectorAll(".gk-nav-links a").forEach(s=>{s.addEventListener("click",v=>{v.preventDefault();const C=s.getAttribute("href");if(C&&C.startsWith("#")){const k=C.replace("#","");this.currentView=k,window.location.hash=k,this.render(),window.scrollTo({top:0,behavior:"smooth"})}})}),document.querySelectorAll(".gk-tab-btn").forEach(s=>{s.addEventListener("click",v=>{this.panchangTab=s.getAttribute("data-tab"),this.render()})});const r=document.getElementById("gk-date-picker");r&&r.addEventListener("change",s=>{this.selectedDate=new Date(s.target.value),this.render()}),document.querySelectorAll(".gk-deity-card-chip").forEach(s=>{s.addEventListener("click",()=>{this.selectedDeity=s.getAttribute("data-deity-id"),this.render()})}),document.querySelectorAll(".gk-cat-pill").forEach(s=>{s.addEventListener("click",()=>{this.selectedCategory=s.getAttribute("data-category"),this.render()})});const n=document.getElementById("gk-reset-filters");n&&n.addEventListener("click",()=>{this.selectedDeity="all",this.selectedCategory="all",this.render()}),document.querySelectorAll(".gk-audio-play-btn").forEach(s=>{s.addEventListener("click",()=>{const v=s.getAttribute("data-play-id");this.playChantSound(v)})}),document.querySelectorAll(".gk-speed-btn").forEach(s=>{s.addEventListener("click",()=>{this.chantSpeed=parseFloat(s.getAttribute("data-speed")),this.render()})}),document.querySelectorAll(".gk-share-card-btn").forEach(s=>{s.addEventListener("click",()=>{const v=s.getAttribute("data-share-id");this.openCardMaker(v)})});const l=document.getElementById("gk-card-maker-close");l&&l.addEventListener("click",()=>this.closeCardMaker()),document.querySelectorAll(".gk-theme-swatch").forEach(s=>{s.addEventListener("click",()=>{this.cardTheme=s.getAttribute("data-theme"),document.querySelectorAll(".gk-theme-swatch").forEach(v=>v.classList.remove("active")),s.classList.add("active"),this.drawShareCanvas()})});const d=document.getElementById("gk-canvas-download");d&&d.addEventListener("click",()=>this.downloadCardImage());const u=document.getElementById("gk-canvas-whatsapp");u&&u.addEventListener("click",()=>this.shareCardToWhatsApp());const c=document.getElementById("gk-modal-close");c&&c.addEventListener("click",()=>{this.cityModalOpen=!1,this.render()});const b=document.getElementById("gk-city-search");b&&b.addEventListener("input",s=>{const v=s.target.value.toLowerCase();document.querySelectorAll(".gk-city-item").forEach(k=>{const w=k.innerText.toLowerCase();k.style.display=w.includes(v)?"flex":"none"})}),document.querySelectorAll(".gk-city-item").forEach(s=>{s.addEventListener("click",()=>{const v=s.getAttribute("data-city-id"),C=this.cities.find(k=>k.id===v);C&&(this.saveCity(C),this.cityModalOpen=!1,this.render())})});const T=document.getElementById("gk-font-inc");T&&T.addEventListener("click",()=>{this.slokaFontSize=Math.min(this.slokaFontSize+.15,2.2),this.render()});const S=document.getElementById("gk-font-dec");S&&S.addEventListener("click",()=>{this.slokaFontSize=Math.max(this.slokaFontSize-.15,.9),this.render()});const x=document.getElementById("gk-toggle-sabdartha");x&&x.addEventListener("click",()=>{this.showSabdartha=!this.showSabdartha,this.render()});const M=document.getElementById("gk-japa-trigger");M&&M.addEventListener("click",()=>this.handleJapaClick());const L=document.getElementById("gk-japa-sound-toggle");L&&L.addEventListener("click",()=>{this.japaEngine.soundEnabled=!this.japaEngine.soundEnabled,this.japaEngine.saveState(),this.render()});const R=document.getElementById("gk-japa-vib-toggle");R&&R.addEventListener("click",()=>{this.japaEngine.vibrationEnabled=!this.japaEngine.vibrationEnabled,this.japaEngine.saveState(),this.render()});const $=document.getElementById("gk-japa-meru-toggle");$&&$.addEventListener("click",()=>{this.japaEngine.meruReversalMode=!this.japaEngine.meruReversalMode,this.japaEngine.saveState(),this.render()});const j=document.getElementById("gk-japa-reset");j&&j.addEventListener("click",()=>{confirm("Reset current 108 bead counter to 0?")&&(this.japaEngine.resetCurrentMala(),this.render())});const B=document.getElementById("gk-japa-export");B&&B.addEventListener("click",()=>{const s=this.japaEngine.exportDataJSON(),v=new Blob([s],{type:"application/json"}),C=URL.createObjectURL(v),k=document.createElement("a");k.href=C,k.download=`GuruKripa_Japa_Backup_${new Date().toISOString().slice(0,10)}.json`,k.click()}),document.querySelectorAll(".gk-quiz-btn").forEach(s=>{s.addEventListener("click",()=>{const v=s.getAttribute("data-story"),C=parseInt(s.getAttribute("data-idx"),10),k=ya.find(K=>K.id===v),w=document.getElementById(`gk-quiz-result-${v}`);k&&w&&(w.style.display="block",C===k.quiz.correctIndex?(w.style.background="rgba(46, 125, 50, 0.1)",w.style.color="#2E7D32",w.innerHTML=`<strong>✓ Spot On!</strong> ${k.quiz.explanation}`):(w.style.background="rgba(198, 40, 40, 0.1)",w.style.color="#C62828",w.innerHTML="<strong>Reflect Again:</strong> Consider the spiritual principle of Buddhi and Satya."))})});const V=document.getElementById("gk-consent-accept");V&&V.addEventListener("click",()=>{localStorage.setItem("gk_consent","accepted");const s=document.getElementById("gk-consent-banner");s&&s.remove()})}}document.addEventListener("DOMContentLoaded",()=>{new ie});
